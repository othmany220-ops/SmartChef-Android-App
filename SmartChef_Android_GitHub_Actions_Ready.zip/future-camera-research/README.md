# Future Camera Research — Not Part of V21 Runtime

This directory preserves an earlier backend prototype and deployment file for possible future study. It is not referenced by the Android build, GitHub Actions, or the evaluated application. Do not present it as an implemented feature.
