# Experimental Image Classification Results

The SVM/CNN files in this directory are retained for Chapter 4 academic comparison only. They are not used by the current Android application. Results derived from a small number of original seed images and augmentation must not be described as production or real-world accuracy.
