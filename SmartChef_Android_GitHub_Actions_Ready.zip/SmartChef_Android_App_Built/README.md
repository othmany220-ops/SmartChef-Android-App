# SmartChef Android App - Complete System V2

Smart Chef is a bilingual Arabic/English Android recipe recommendation system. It includes:

- Text ingredient input
- Android voice recognition input
- Image upload prototype
- 16 ingredient image classes
- 12 recipe records with illustrated recipe images
- Local recommendation algorithm
- Recipe details screen
- Arabic/English language switch
- About and presentation explanation screens

## Build
Open the project in Android Studio or build it using GitHub Actions.

## Recommendation Algorithm
The app normalizes Arabic and English ingredient names into standard ingredient keys, compares them with every recipe, calculates matched ingredients, then ranks recipes by match score.

## Image Feature
The image feature is implemented as an educational prototype. The user uploads an image and selects the expected ingredient category. This can later be connected to a trained image-classification model.
