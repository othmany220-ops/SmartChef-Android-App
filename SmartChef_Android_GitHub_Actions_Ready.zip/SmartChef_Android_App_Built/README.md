# Smart Chef Android App

## Project Overview
Smart Chef is a native Android application designed as a Software Engineering academic project. The application helps users select suitable food recipes based on the ingredients available at home. Users can enter ingredients manually, use voice input, or upload an ingredient image prototype. The app then recommends recipes using a simple local recommendation algorithm.

## Arabic Overview
تطبيق **الشيف الذكي Smart Chef** هو تطبيق أندرويد لمشروع هندسة برمجيات يساعد المستخدم على اختيار وصفات مناسبة بناءً على المكونات المتوفرة لديه. يمكن إدخال المكونات بالكتابة أو بالصوت أو من خلال رفع صورة كمكوّن أولي قابل للتطوير. بعد ذلك يقوم التطبيق بمقارنة المكونات مع بيانات الوصفات المحلية ويقترح أنسب الوصفات.

---

## Main Features
- Native Android application.
- Built with Java and XML using Android Studio structure.
- Arabic and English interface.
- Language switch button.
- Text ingredient input.
- Voice input using Android `RecognizerIntent`.
- Image upload from gallery.
- Image ingredient recognition prototype through manual category selection.
- Local recipe dataset.
- Recommendation system based on ingredient matching.
- Recipe cards showing score, time, difficulty, and matched ingredients.
- Recipe details dialog.
- About/Dataset explanation screen.
- Presentation explanation screen in Arabic and English.

---

## Technologies Used
- Java
- Android Studio
- XML Layouts
- Android Speech Recognition
- Local in-app recipe dataset
- Simple rule-based recommendation system

---

## Project Structure
```text
SmartChef_Android_App_Built/
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/smartchef/app/
│       │   ├── MainActivity.java
│       │   ├── Recipe.java
│       │   ├── RecipeRepository.java
│       │   ├── RecommendationEngine.java
│       │   ├── RecommendationResult.java
│       │   └── LanguageManager.java
│       └── res/
│           ├── drawable/
│           ├── layout/activity_main.xml
│           ├── values/
│           └── values-ar/
├── build.gradle
├── settings.gradle
└── README.md
```

---

## How the Recommendation Algorithm Works
1. The user enters ingredients by text, voice, or image category selection.
2. The application normalizes the input and detects known ingredients.
3. Each recipe in the local dataset has a list of required ingredients.
4. The app compares user ingredients with recipe ingredients.
5. It calculates the recommendation score based on the number of matched ingredients.
6. Recipes are ranked from the highest score to the lowest score.

Example:
```text
User input: egg, tomato, onion
Matched recipe: Tomato Egg Skillet
Score: 3 matched ingredients
```

---

## Image Feature Note
The image feature is implemented as a working prototype. The user can upload an ingredient image and manually select the detected ingredient category from a list. This design is suitable for an academic prototype and can later be connected to a trained image classification model such as TensorFlow Lite.

## ملاحظة حول خاصية الصورة
خاصية الصورة منفذة كنموذج أولي عملي. يستطيع المستخدم رفع صورة ثم اختيار فئة المكوّن المتوقعة يدويًا. ويمكن تطوير هذه الخاصية لاحقًا وربطها بنموذج ذكاء اصطناعي مدرّب مثل TensorFlow Lite للتعرف التلقائي على الصور.

---

## How to Run the Project
1. Extract the ZIP file.
2. Open Android Studio.
3. Choose **Open**.
4. Select the folder `SmartChef_Android_App_Built`.
5. Wait until Gradle sync finishes.
6. Connect an Android device or start an emulator.
7. Press **Run**.

---

## How to Build APK
In Android Studio:

```text
Build > Build Bundle(s) / APK(s) > Build APK(s)
```

After the build finishes, Android Studio will show the APK location.

---

## Sample Inputs
English:
```text
egg, tomato, cheese
chicken, rice, onion
pasta, tomato, garlic
```

Arabic:
```text
بيض، طماطم، جبن
دجاج، أرز، بصل
معكرونة، طماطم، ثوم
```

---

## Presentation Script - English
Good morning. Our project is called Smart Chef. It is an Android recipe recommendation application designed to help users decide what to cook based on the ingredients they already have. The user can enter ingredients manually, use voice input, or upload an ingredient image. The main feature that distinguishes our project is voice input, because many similar recipe applications depend mainly on text search. After receiving the ingredients, the application compares them with a local recipe dataset, calculates the number of matched ingredients, and displays the recipes with the highest match first. The image input feature is implemented as a prototype and can later be connected to a trained image classification model. Overall, Smart Chef aims to make cooking easier, reduce food waste, and provide a fast and user-friendly cooking assistant.

## نص الشرح بالعربية
صباح الخير. مشروعنا اسمه الشيف الذكي Smart Chef، وهو تطبيق أندرويد يقترح وصفات طعام مناسبة بناءً على المكونات المتوفرة لدى المستخدم في المنزل. يمكن للمستخدم إدخال المكونات بالكتابة أو بالصوت أو من خلال رفع صورة. وتعد خاصية الإدخال الصوتي من أهم نقاط التميز في المشروع لأن كثيرًا من التطبيقات المشابهة تعتمد على البحث النصي فقط. بعد إدخال المكونات يقارن التطبيق هذه المكونات مع بيانات الوصفات المحلية، ثم يحسب عدد المكونات المتطابقة ويعرض الوصفات الأعلى تطابقًا أولًا. أما خاصية الصورة فهي منفذة كنموذج أولي ويمكن تطويرها لاحقًا باستخدام نموذج ذكاء اصطناعي للتعرف على الصور. يهدف التطبيق إلى تسهيل الطبخ وتقليل هدر الطعام وتقديم تجربة استخدام بسيطة وسريعة.
