# SmartChef Android App — Enhanced UI Version

Smart Chef is a native Android recipe recommendation application built in Java for a Software Engineering academic project.

## Main Features

- Arabic and English interface.
- Splash screen with Smart Chef branding.
- First-user welcome/onboarding guide.
- Modern orange/cream cooking-app interface inspired by real food apps.
- Text ingredient input.
- Voice ingredient input using Android Speech Recognition.
- Camera image input and multiple gallery image selection.
- Recommendation system based on matching user ingredients with recipe ingredients.
- Recommended recipes appear directly below the input area.
- Real recipe/ingredient images integrated from the project dataset.
- Favorites list.
- Recent searches list.
- Dark mode toggle.
- Light haptic feedback on button/ingredient actions.
- Share button for recipe name, ingredients and steps.
- Longer recipe preparation steps including spices and seasoning.
- Matched ingredients display is restricted to ingredients detected from the user's input and found in the recipe.

## Build APK with GitHub Actions

Upload this ZIP to the same repository and keep the file name:

`SmartChef_Android_GitHub_Actions_Ready.zip`

Then go to **Actions > Build Smart Chef APK** and run the workflow.

The APK will appear under **Artifacts** as:

`SmartChef-debug-apk`

Unzip it and install:

`app-debug.apk`
