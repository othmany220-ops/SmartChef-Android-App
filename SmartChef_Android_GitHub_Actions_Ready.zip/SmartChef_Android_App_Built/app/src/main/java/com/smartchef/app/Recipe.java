package com.smartchef.app;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Recipe {
    public final String nameEn;
    public final String nameAr;
    public final List<String> ingredients;
    public final String stepsEn;
    public final String stepsAr;
    public final String categoryEn;
    public final String categoryAr;
    public final String time;
    public final String difficultyEn;
    public final String difficultyAr;

    public Recipe(String nameEn,
                  String nameAr,
                  String[] ingredients,
                  String stepsEn,
                  String stepsAr,
                  String categoryEn,
                  String categoryAr,
                  String time,
                  String difficultyEn,
                  String difficultyAr) {
        this.nameEn = nameEn;
        this.nameAr = nameAr;
        this.ingredients = new ArrayList<>(Arrays.asList(ingredients));
        this.stepsEn = stepsEn;
        this.stepsAr = stepsAr;
        this.categoryEn = categoryEn;
        this.categoryAr = categoryAr;
        this.time = time;
        this.difficultyEn = difficultyEn;
        this.difficultyAr = difficultyAr;
    }
}
