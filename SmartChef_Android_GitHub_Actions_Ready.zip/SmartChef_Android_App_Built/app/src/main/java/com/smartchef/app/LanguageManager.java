package com.smartchef.app;

import android.content.Context;
import android.content.SharedPreferences;

public class LanguageManager {
    private static final String PREF_NAME = "smart_chef_language";
    private static final String KEY_ARABIC = "arabic";

    public static boolean isArabic(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return prefs.getBoolean(KEY_ARABIC, false);
    }

    public static void setArabic(Context context, boolean arabic) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_ARABIC, arabic).apply();
    }
}
