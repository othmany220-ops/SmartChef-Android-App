package com.smartchef.app;

public class AIIngredientResult {
    public final String ingredientKey;
    public final String ingredientNameEn;
    public final String ingredientNameAr;
    public final int confidence;
    public final String method;
    public final String rawLabels;

    public AIIngredientResult(String ingredientKey, String ingredientNameEn, String ingredientNameAr, int confidence, String method, String rawLabels) {
        this.ingredientKey = ingredientKey;
        this.ingredientNameEn = ingredientNameEn;
        this.ingredientNameAr = ingredientNameAr;
        this.confidence = confidence;
        this.method = method;
        this.rawLabels = rawLabels;
    }
}
