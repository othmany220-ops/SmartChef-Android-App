package com.smartchef.app;

import java.util.ArrayList;
import java.util.List;

public class RecipeRepository {
    public static List<Recipe> getRecipes() {
        List<Recipe> recipes = new ArrayList<>();

        recipes.add(new Recipe(
                "Cheese Omelette",
                "أومليت بالجبن",
                new String[]{"egg", "cheese", "milk", "salt", "pepper"},
                "Beat eggs with milk, add cheese, season with salt and pepper, then cook in a non-stick pan for 5 minutes.",
                "اخفق البيض مع الحليب، ثم أضف الجبن والملح والفلفل، واطهه في مقلاة غير لاصقة لمدة خمس دقائق.",
                "Breakfast", "فطور", "10 min", "Easy", "سهل"));

        recipes.add(new Recipe(
                "Tomato Egg Skillet",
                "بيض بالطماطم",
                new String[]{"egg", "tomato", "onion", "salt", "oil"},
                "Cook onion and tomato in a little oil, add eggs, season, and cook until the eggs are set.",
                "قلّب البصل والطماطم بقليل من الزيت، ثم أضف البيض والملح واتركه حتى ينضج.",
                "Breakfast", "فطور", "12 min", "Easy", "سهل"));

        recipes.add(new Recipe(
                "Chicken Salad",
                "سلطة الدجاج",
                new String[]{"chicken", "lettuce", "tomato", "cucumber", "lemon"},
                "Slice cooked chicken, mix with lettuce, tomato and cucumber, then add lemon dressing.",
                "قطّع الدجاج المطبوخ واخلطه مع الخس والطماطم والخيار، ثم أضف عصير الليمون.",
                "Healthy", "صحي", "15 min", "Easy", "سهل"));

        recipes.add(new Recipe(
                "Tomato Pasta",
                "معكرونة بالطماطم",
                new String[]{"pasta", "tomato", "garlic", "cheese", "oil"},
                "Boil pasta, prepare tomato and garlic sauce, mix together, then add cheese on top.",
                "اسلق المعكرونة، وحضّر صلصة الطماطم والثوم، ثم اخلطهما وأضف الجبن في النهاية.",
                "Lunch", "غداء", "25 min", "Medium", "متوسط"));

        recipes.add(new Recipe(
                "Vegetable Soup",
                "شوربة خضار",
                new String[]{"carrot", "potato", "onion", "tomato", "water", "salt"},
                "Cut vegetables, boil them with water and salt, then cook until soft. Blend if desired.",
                "قطّع الخضار واسلقها مع الماء والملح حتى تصبح طرية، ويمكن خلطها حسب الرغبة.",
                "Soup", "شوربة", "30 min", "Easy", "سهل"));

        recipes.add(new Recipe(
                "Chicken Rice Bowl",
                "أرز بالدجاج",
                new String[]{"chicken", "rice", "onion", "garlic", "salt", "pepper"},
                "Cook chicken with onion and garlic, add rice and water, then simmer until the rice is cooked.",
                "اطهِ الدجاج مع البصل والثوم، ثم أضف الأرز والماء واتركه حتى ينضج.",
                "Lunch", "غداء", "35 min", "Medium", "متوسط"));

        recipes.add(new Recipe(
                "Tuna Sandwich",
                "ساندويتش تونة",
                new String[]{"tuna", "bread", "lettuce", "tomato", "lemon"},
                "Mix tuna with lemon, place it inside bread with lettuce and tomato, then serve.",
                "اخلط التونة مع الليمون، وضعها داخل الخبز مع الخس والطماطم ثم قدّمها.",
                "Snack", "وجبة خفيفة", "8 min", "Easy", "سهل"));

        recipes.add(new Recipe(
                "Potato Cheese Bake",
                "بطاطا بالجبن",
                new String[]{"potato", "cheese", "milk", "salt", "pepper"},
                "Slice potatoes, add milk and cheese, season, then bake until golden.",
                "قطّع البطاطا، وأضف الحليب والجبن والبهارات، ثم اخبزها حتى تصبح ذهبية.",
                "Dinner", "عشاء", "40 min", "Medium", "متوسط"));

        recipes.add(new Recipe(
                "Banana Milk Smoothie",
                "سموذي الموز بالحليب",
                new String[]{"banana", "milk", "honey"},
                "Blend banana with milk and honey until smooth. Serve cold.",
                "اخلط الموز مع الحليب والعسل حتى يصبح ناعمًا، ثم قدّمه باردًا.",
                "Drink", "مشروب", "5 min", "Easy", "سهل"));

        recipes.add(new Recipe(
                "Apple Yogurt Bowl",
                "زبادي بالتفاح",
                new String[]{"apple", "yogurt", "honey", "banana"},
                "Cut fruits, add yogurt and honey, and mix gently.",
                "قطّع الفواكه، وأضف الزبادي والعسل، ثم اخلطها برفق.",
                "Healthy", "صحي", "7 min", "Easy", "سهل"));

        recipes.add(new Recipe(
                "Beef Potato Stew",
                "يخنة لحم بالبطاطا",
                new String[]{"beef", "potato", "tomato", "onion", "garlic", "salt"},
                "Cook beef with onion and garlic, add potato and tomato, then simmer until tender.",
                "اطهِ اللحم مع البصل والثوم، ثم أضف البطاطا والطماطم واتركه حتى ينضج.",
                "Dinner", "عشاء", "55 min", "Medium", "متوسط"));

        recipes.add(new Recipe(
                "Garlic Chicken Wrap",
                "راب الدجاج بالثوم",
                new String[]{"chicken", "bread", "garlic", "lettuce", "cucumber"},
                "Mix cooked chicken with garlic sauce, add vegetables, and wrap in bread.",
                "اخلط الدجاج المطبوخ مع صلصة الثوم، وأضف الخضار ثم لفّه داخل الخبز.",
                "Snack", "وجبة خفيفة", "15 min", "Easy", "سهل"));

        return recipes;
    }
}
