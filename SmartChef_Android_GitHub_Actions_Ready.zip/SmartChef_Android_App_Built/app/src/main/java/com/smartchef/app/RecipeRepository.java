package com.smartchef.app;

import java.util.ArrayList;
import java.util.List;

public class RecipeRepository {
    public static List<IngredientCategory> getIngredientCategories() {
        List<IngredientCategory> items = new ArrayList<>();
        items.add(new IngredientCategory("egg", "Egg", "بيض", R.drawable.ing_egg));
        items.add(new IngredientCategory("tomato", "Tomato", "طماطم", R.drawable.ing_tomato));
        items.add(new IngredientCategory("cheese", "Cheese", "جبن", R.drawable.ing_cheese));
        items.add(new IngredientCategory("chicken", "Chicken", "دجاج", R.drawable.ing_chicken));
        items.add(new IngredientCategory("rice", "Rice", "أرز", R.drawable.ing_rice));
        items.add(new IngredientCategory("pasta", "Macaroni", "معكرونة", R.drawable.ing_pasta));
        items.add(new IngredientCategory("onion", "Onion", "بصل", R.drawable.ing_onion));
        items.add(new IngredientCategory("garlic", "Garlic", "ثوم", R.drawable.ing_garlic));
        items.add(new IngredientCategory("potato", "Potato", "بطاطا", R.drawable.ing_potato));
        items.add(new IngredientCategory("carrot", "Carrot", "جزر", R.drawable.ing_carrot));
        items.add(new IngredientCategory("cucumber", "Cucumber", "خيار", R.drawable.ing_cucumber));
        items.add(new IngredientCategory("parsley", "Parsley", "بقدونس", R.drawable.ing_parsley));
        items.add(new IngredientCategory("tuna", "Tuna", "تونة", R.drawable.ing_tuna));
        items.add(new IngredientCategory("yogurt", "Yogurt", "زبادي", R.drawable.ing_yogurt));
        items.add(new IngredientCategory("red_lentils", "Red Lentils", "عدس أحمر", R.drawable.ing_red_lentils));
        items.add(new IngredientCategory("beef", "Meat", "لحم", R.drawable.ing_beef));
        items.add(new IngredientCategory("spices", "Spices", "بهارات", R.drawable.ing_parsley));
        items.add(new IngredientCategory("milk", "Milk", "حليب", R.drawable.ing_yogurt));
        return items;
    }

    public static List<Recipe> getRecipes() {
        List<Recipe> recipes = new ArrayList<>();

        recipes.add(0, new Recipe(
                "Jordanian Mansaf", "منسف أردني",
                new String[]{"beef", "rice", "yogurt"},
                "1. Boil the meat with onion, bay leaf, cardamom, black pepper and a little salt until tender.\n2. Prepare the yogurt sauce by mixing yogurt or jameed with a little meat broth, then simmer it gently while stirring.\n3. Cook the rice with turmeric, salt and a small spoon of oil until fluffy.\n4. Add the cooked meat to the yogurt sauce for a few minutes so the flavor combines.\n5. Serve rice on a large plate, add meat and yogurt sauce, then garnish with toasted nuts and parsley if available.",
                "١. اسلق اللحم مع البصل وورق الغار والهيل والفلفل الأسود وقليل من الملح حتى ينضج.\n٢. حضّر صلصة اللبن أو الجميد بإضافة قليل من مرق اللحم، ثم اتركها على نار هادئة مع التحريك.\n٣. اطبخ الأرز مع الكركم والملح وملعقة صغيرة من الزيت حتى يصبح مفلفلًا.\n٤. أضف اللحم المطبوخ إلى صلصة اللبن عدة دقائق حتى تتجانس النكهة.\n٥. قدّم الأرز في طبق واسع، ثم ضع اللحم وصلصة اللبن فوقه، وزيّنه بالمكسرات والبقدونس إن توفرا.",
                "Main Dish", "طبق رئيسي", "70 min", "Medium", "متوسط", R.drawable.recipe_mansaf));
        recipes.add(1, new Recipe(
                "Chicken Kabsa", "كبسة دجاج",
                new String[]{"chicken", "rice", "onion", "tomato", "garlic", "spices"},
                "1. Season the chicken with kabsa spices, black pepper, turmeric, cinnamon, cardamom and salt.\n2. Sauté onion and garlic in oil, then add tomato and cook until it becomes a rich sauce.\n3. Add the chicken and brown it lightly, then add water or broth and simmer until cooked.\n4. Add washed rice to the broth, adjust salt and cook on low heat until the rice absorbs the liquid.\n5. Serve the kabsa with the chicken on top and garnish with parsley or nuts if available.",
                "١. تبّل الدجاج ببهارات الكبسة والفلفل الأسود والكركم والقرفة والهيل والملح.\n٢. شوّح البصل والثوم بالزيت، ثم أضف الطماطم حتى تتكوّن صلصة غنية.\n٣. أضف الدجاج وقلّبه قليلًا، ثم أضف الماء أو المرق واتركه حتى ينضج.\n٤. أضف الأرز المغسول إلى المرق، واضبط الملح، ثم اطهه على نار هادئة حتى يتشرب السائل.\n٥. قدّم الكبسة مع الدجاج فوق الأرز وزيّنه بالبقدونس أو المكسرات إن توفرت.",
                "Main Dish", "طبق رئيسي", "60 min", "Medium", "متوسط", R.drawable.recipe_kabsa));
        recipes.add(new Recipe(
                "Cheese Omelette", "أومليت بالجبن",
                new String[]{"egg", "cheese", "tomato", "parsley"},
                "1. Beat the eggs with a pinch of salt, black pepper and a small amount of paprika.\n2. Add chopped tomato and grated cheese.\n3. Heat a lightly oiled pan, pour the mixture and cook on low heat.\n4. Fold the omelette, garnish with parsley, and serve warm.",
                "١. اخفق البيض مع رشة ملح وفلفل أسود وقليل من البابريكا.\n٢. أضف الطماطم المفرومة والجبن المبشور.\n٣. سخّن مقلاة مع قليل من الزيت، ثم اسكب الخليط واطهه على نار هادئة.\n٤. اطوِ الأومليت، زيّنه بالبقدونس، وقدّمه ساخنًا.",
                "Breakfast", "فطور", "12 min", "Easy", "سهل", R.drawable.recipe_omelette));
        recipes.add(new Recipe(
                "Tomato Shakshuka", "شكشوكة الطماطم",
                new String[]{"egg", "tomato", "onion", "garlic"},
                "1. Sauté onion and garlic in oil until fragrant.\n2. Add chopped tomatoes, salt, black pepper, cumin and paprika.\n3. Simmer until the sauce becomes thick.\n4. Add the eggs, cover the pan and cook until the eggs set.",
                "١. شوّح البصل والثوم في قليل من الزيت حتى تظهر الرائحة.\n٢. أضف الطماطم المفرومة مع الملح والفلفل الأسود والكمون والبابريكا.\n٣. اترك الصلصة حتى تتماسك.\n٤. أضف البيض، غطِّ المقلاة، واتركه حتى ينضج.",
                "Breakfast", "فطور", "18 min", "Easy", "سهل", R.drawable.recipe_shakshuka));
        recipes.add(new Recipe(
                "Chicken Salad", "سلطة الدجاج",
                new String[]{"chicken", "cucumber", "tomato", "parsley"},
                "1. Season chicken with salt, pepper, garlic powder and lemon if available.\n2. Grill or boil the chicken, then slice it.\n3. Mix cucumber, tomato and parsley in a bowl.\n4. Add the chicken and serve with yogurt or light dressing.",
                "١. تبّل الدجاج بالملح والفلفل وبودرة الثوم، ويمكن إضافة الليمون إن توفر.\n٢. اشوِ الدجاج أو اسلقه ثم قطّعه شرائح.\n٣. اخلط الخيار والطماطم والبقدونس في وعاء.\n٤. أضف الدجاج وقدّمه مع الزبادي أو صلصة خفيفة.",
                "Healthy", "صحي", "15 min", "Easy", "سهل", R.drawable.recipe_chicken_salad));
        recipes.add(new Recipe(
                "Tomato Macaroni", "معكرونة بالطماطم",
                new String[]{"pasta", "tomato", "garlic", "cheese"},
                "1. Boil macaroni with salt until soft.\n2. Sauté garlic in oil, then add tomato and a little black pepper, basil or oregano.\n3. Mix the cooked pasta with the sauce.\n4. Add cheese on top and let it melt before serving.",
                "١. اسلق المعكرونة في ماء مملح حتى تنضج.\n٢. شوّح الثوم بالزيت، ثم أضف الطماطم مع فلفل أسود وقليل من الريحان أو الأوريغانو.\n٣. اخلط المعكرونة مع الصلصة.\n٤. أضف الجبن فوقها واتركه يذوب قبل التقديم.",
                "Lunch", "غداء", "25 min", "Medium", "متوسط", R.drawable.recipe_pasta));
        recipes.add(new Recipe(
                "Red Lentil Soup", "شوربة العدس الأحمر",
                new String[]{"red_lentils", "carrot", "onion", "garlic"},
                "1. Wash the lentils well.\n2. Cook onion, garlic and carrot with a little oil.\n3. Add lentils, water, salt, cumin and black pepper.\n4. Simmer until soft, then blend for a smooth texture.",
                "١. اغسل العدس جيدًا.\n٢. شوّح البصل والثوم والجزر مع قليل من الزيت.\n٣. أضف العدس والماء والملح والكمون والفلفل الأسود.\n٤. اتركه حتى ينضج، ثم اخلطه للحصول على قوام ناعم.",
                "Soup", "شوربة", "30 min", "Easy", "سهل", R.drawable.recipe_soup));
        recipes.add(new Recipe(
                "Chicken Rice Bowl", "أرز بالدجاج",
                new String[]{"chicken", "rice", "onion", "garlic"},
                "1. Season chicken with salt, pepper, turmeric, paprika and a little cumin.\n2. Sauté onion and garlic, then add chicken until browned.\n3. Cook rice separately or with the chicken broth.\n4. Serve chicken over rice and garnish with parsley.",
                "١. تبّل الدجاج بالملح والفلفل والكركم والبابريكا وقليل من الكمون.\n٢. شوّح البصل والثوم، ثم أضف الدجاج حتى يتحمر.\n٣. اطهِ الأرز وحده أو مع مرق الدجاج.\n٤. قدّم الدجاج فوق الأرز وزيّنه بالبقدونس.",
                "Lunch", "غداء", "35 min", "Medium", "متوسط", R.drawable.recipe_rice_chicken));
        recipes.add(new Recipe(
                "Tuna Cucumber Salad", "سلطة التونة بالخيار",
                new String[]{"tuna", "cucumber", "tomato", "parsley"},
                "1. Drain the tuna.\n2. Chop cucumber, tomato and parsley.\n3. Mix everything with salt, pepper and a little lemon or yogurt.\n4. Serve cold as a light meal.",
                "١. صفِّ التونة من الزيت أو الماء.\n٢. قطّع الخيار والطماطم والبقدونس.\n٣. اخلط المكونات مع الملح والفلفل وقليل من الليمون أو الزبادي.\n٤. قدّمها باردة كوجبة خفيفة.",
                "Snack", "وجبة خفيفة", "10 min", "Easy", "سهل", R.drawable.recipe_tuna_sandwich));
        recipes.add(new Recipe(
                "Yogurt Cucumber Salad", "سلطة الزبادي بالخيار",
                new String[]{"yogurt", "cucumber", "garlic", "parsley"},
                "1. Grate or chop cucumber.\n2. Mix yogurt with garlic, salt, mint if available and black pepper.\n3. Add cucumber and parsley.\n4. Chill for 10 minutes before serving.",
                "١. ابشر الخيار أو قطّعه ناعمًا.\n٢. اخلط الزبادي مع الثوم والملح والنعناع إن توفر والفلفل الأسود.\n٣. أضف الخيار والبقدونس.\n٤. برّد السلطة ١٠ دقائق قبل التقديم.",
                "Healthy", "صحي", "7 min", "Easy", "سهل", R.drawable.recipe_banana_smoothie));
        recipes.add(new Recipe(
                "Potato Cheese Bake", "بطاطا بالجبن",
                new String[]{"potato", "cheese", "yogurt", "parsley"},
                "1. Slice potatoes and boil them slightly.\n2. Mix yogurt with salt, pepper, garlic powder and paprika.\n3. Layer potatoes with cheese and sauce.\n4. Bake until golden and garnish with parsley.",
                "١. قطّع البطاطا واسلقها قليلًا.\n٢. اخلط الزبادي مع الملح والفلفل وبودرة الثوم والبابريكا.\n٣. رتّب البطاطا مع الجبن والصلصة.\n٤. اخبزها حتى تصبح ذهبية وزيّنها بالبقدونس.",
                "Dinner", "عشاء", "40 min", "Medium", "متوسط", R.drawable.recipe_yogurt_bowl));
        recipes.add(new Recipe(
                "Beef Potato Stew", "يخنة لحم بالبطاطا",
                new String[]{"beef", "potato", "tomato", "onion", "garlic"},
                "1. Brown the beef with onion and garlic.\n2. Add tomato, salt, pepper, allspice and a little cumin.\n3. Add potato cubes and water or broth.\n4. Simmer until the meat and potatoes are tender.",
                "١. حمّر اللحم مع البصل والثوم.\n٢. أضف الطماطم والملح والفلفل والبهار المشكل وقليلًا من الكمون.\n٣. أضف مكعبات البطاطا والماء أو المرق.\n٤. اترك اليخنة حتى ينضج اللحم والبطاطا.",
                "Dinner", "عشاء", "55 min", "Medium", "متوسط", R.drawable.recipe_beef_stew));
        recipes.add(new Recipe(
                "Garlic Chicken Plate", "طبق الدجاج بالثوم",
                new String[]{"chicken", "garlic", "yogurt", "cucumber"},
                "1. Marinate chicken with yogurt, garlic, salt, pepper and paprika.\n2. Leave it for 10 minutes if possible.\n3. Cook the chicken in a pan or grill.\n4. Serve with cucumber yogurt salad.",
                "١. تبّل الدجاج بالزبادي والثوم والملح والفلفل والبابريكا.\n٢. اتركه ١٠ دقائق إن أمكن.\n٣. اطهه في مقلاة أو على الشواية.\n٤. قدّمه مع سلطة خيار بالزبادي.",
                "Dinner", "عشاء", "25 min", "Easy", "سهل", R.drawable.recipe_wrap));
        recipes.add(new Recipe(
                "Vegetable Macaroni", "معكرونة بالخضار",
                new String[]{"pasta", "tomato", "cheese", "carrot", "onion"},
                "1. Boil pasta with salt.\n2. Sauté onion and carrot, then add tomato sauce.\n3. Season with pepper, oregano and a small pinch of paprika.\n4. Mix with pasta and finish with cheese.",
                "١. اسلق المعكرونة مع الملح.\n٢. شوّح البصل والجزر، ثم أضف صلصة الطماطم.\n٣. تبّل بالفلفل والأوريغانو ورشة بابريكا خفيفة.\n٤. اخلطها مع المعكرونة وأضف الجبن في النهاية.",
                "Dinner", "عشاء", "20 min", "Easy", "سهل", R.drawable.recipe_pizza));
        recipes.add(new Recipe(
                "Banana Milk Smoothie", "سموثي الموز بالحليب",
                new String[]{"banana", "milk", "yogurt"},
                "1. Slice the banana.\n2. Blend banana with milk and yogurt.\n3. Add a small pinch of cinnamon or honey if available.\n4. Serve cold.",
                "١. قطّع الموز إلى شرائح.\n٢. اخلط الموز مع الحليب والزبادي.\n٣. أضف رشة قرفة أو عسلًا إن توفر.\n٤. قدّمه باردًا.",
                "Drink", "مشروب", "5 min", "Easy", "سهل", R.drawable.recipe_banana_smoothie));
        recipes.add(new Recipe(
                "Fresh Garden Salad", "سلطة خضار طازجة",
                new String[]{"cucumber", "tomato", "lettuce", "parsley"},
                "1. Wash and chop all vegetables.\n2. Mix cucumber, tomato, lettuce and parsley.\n3. Season with salt, pepper, lemon and a little olive oil if available.\n4. Serve immediately for the best texture.",
                "١. اغسل الخضار وقطّعها جيدًا.\n٢. اخلط الخيار والطماطم والخس والبقدونس.\n٣. تبّل بالملح والفلفل والليمون وقليل من زيت الزيتون إن توفر.\n٤. قدّمها مباشرة للحصول على أفضل قوام.",
                "Salad", "سلطة", "8 min", "Easy", "سهل", R.drawable.recipe_chicken_salad));
        return recipes;
    }
}
