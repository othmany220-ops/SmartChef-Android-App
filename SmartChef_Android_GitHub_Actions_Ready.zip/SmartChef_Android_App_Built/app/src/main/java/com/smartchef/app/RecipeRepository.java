package com.smartchef.app;

import java.util.ArrayList;
import java.util.List;

public class RecipeRepository {
    public static List<IngredientCategory> getIngredientCategories() {
        List<IngredientCategory> items = new ArrayList<>();
        items.add(new IngredientCategory("egg", "Egg", "بيض", R.drawable.ing_egg));
        items.add(new IngredientCategory("tomato", "Tomato", "طماطم", R.drawable.ing_tomato));
        items.add(new IngredientCategory("cheese", "Cheese", "جبن", R.drawable.ing_cheese));
        items.add(new IngredientCategory("chicken", "Chicken", "دجاج", R.drawable.ing_chicken));
        items.add(new IngredientCategory("onion", "Onion", "بصل", R.drawable.ing_onion));
        items.add(new IngredientCategory("potato", "Potato", "بطاطا", R.drawable.ing_potato));
        items.add(new IngredientCategory("rice", "Rice", "أرز", R.drawable.ing_rice));
        items.add(new IngredientCategory("pasta", "Pasta", "معكرونة", R.drawable.ing_pasta));
        items.add(new IngredientCategory("carrot", "Carrot", "جزر", R.drawable.ing_carrot));
        items.add(new IngredientCategory("lettuce", "Lettuce", "خس", R.drawable.ing_lettuce));
        items.add(new IngredientCategory("cucumber", "Cucumber", "خيار", R.drawable.ing_cucumber));
        items.add(new IngredientCategory("apple", "Apple", "تفاح", R.drawable.ing_apple));
        items.add(new IngredientCategory("banana", "Banana", "موز", R.drawable.ing_banana));
        items.add(new IngredientCategory("milk", "Milk", "حليب", R.drawable.ing_milk));
        items.add(new IngredientCategory("bread", "Bread", "خبز", R.drawable.ing_bread));
        items.add(new IngredientCategory("garlic", "Garlic", "ثوم", R.drawable.ing_garlic));
        return items;
    }

    public static List<Recipe> getRecipes() {
        List<Recipe> recipes = new ArrayList<>();
        recipes.add(new Recipe(
                "Cheese Omelette", "أومليت بالجبن",
                new String[]{"egg", "cheese", "milk", "tomato", "salt", "pepper"},
                "Beat eggs with milk, add cheese and tomato, season lightly, then cook in a non-stick pan until firm.",
                "اخفق البيض مع الحليب، ثم أضف الجبن والطماطم والبهارات، واطهه في مقلاة حتى يتماسك.",
                "Breakfast", "فطور", "12 min", "Easy", "سهل", R.drawable.recipe_omelette));
        recipes.add(new Recipe(
                "Tomato Shakshuka", "شكشوكة الطماطم",
                new String[]{"egg", "tomato", "onion", "garlic", "oil", "salt"},
                "Cook onion and garlic, add tomato sauce, then add eggs and simmer until cooked.",
                "اطهِ البصل والثوم، ثم أضف الطماطم، وبعدها أضف البيض واتركه حتى ينضج.",
                "Breakfast", "فطور", "18 min", "Easy", "سهل", R.drawable.recipe_shakshuka));
        recipes.add(new Recipe(
                "Chicken Salad", "سلطة الدجاج",
                new String[]{"chicken", "lettuce", "tomato", "cucumber", "lemon", "oil"},
                "Slice cooked chicken, mix with fresh vegetables, add lemon and a little oil, then serve cold.",
                "قطّع الدجاج المطبوخ واخلطه مع الخضار، ثم أضف الليمون والقليل من الزيت وقدّمه باردًا.",
                "Healthy", "صحي", "15 min", "Easy", "سهل", R.drawable.recipe_chicken_salad));
        recipes.add(new Recipe(
                "Tomato Pasta", "معكرونة بالطماطم",
                new String[]{"pasta", "tomato", "garlic", "cheese", "oil", "salt"},
                "Boil pasta, prepare tomato and garlic sauce, mix together, and finish with cheese.",
                "اسلق المعكرونة، وحضّر صلصة الطماطم والثوم، ثم اخلطها وأضف الجبن.",
                "Lunch", "غداء", "25 min", "Medium", "متوسط", R.drawable.recipe_pasta));
        recipes.add(new Recipe(
                "Vegetable Soup", "شوربة الخضار",
                new String[]{"potato", "carrot", "onion", "tomato", "water", "salt"},
                "Boil vegetables with water and seasoning until soft, then serve warm.",
                "اسلق الخضار مع الماء والبهارات حتى تصبح طرية، ثم قدّمها دافئة.",
                "Soup", "شوربة", "30 min", "Easy", "سهل", R.drawable.recipe_soup));
        recipes.add(new Recipe(
                "Chicken Rice Bowl", "أرز بالدجاج",
                new String[]{"chicken", "rice", "onion", "garlic", "oil", "salt"},
                "Cook rice separately, sauté chicken with onion and garlic, then serve chicken over rice.",
                "اطهِ الأرز، ثم شوّح الدجاج مع البصل والثوم وقدّمه فوق الأرز.",
                "Lunch", "غداء", "35 min", "Medium", "متوسط", R.drawable.recipe_rice_chicken));
        recipes.add(new Recipe(
                "Tuna Sandwich", "ساندويتش تونة",
                new String[]{"tuna", "bread", "lettuce", "cucumber", "lemon"},
                "Mix tuna with lemon, place it in bread, then add lettuce and cucumber.",
                "اخلط التونة مع الليمون، وضعها في الخبز ثم أضف الخس والخيار.",
                "Snack", "وجبة خفيفة", "10 min", "Easy", "سهل", R.drawable.recipe_tuna_sandwich));
        recipes.add(new Recipe(
                "Banana Milk Smoothie", "سموذي الموز بالحليب",
                new String[]{"banana", "milk", "honey"},
                "Blend banana with milk and honey until smooth, then serve cold.",
                "اخلط الموز مع الحليب والعسل حتى يصبح ناعمًا، ثم قدّمه باردًا.",
                "Drink", "مشروب", "5 min", "Easy", "سهل", R.drawable.recipe_banana_smoothie));
        recipes.add(new Recipe(
                "Apple Yogurt Bowl", "زبادي بالتفاح",
                new String[]{"apple", "banana", "yogurt", "honey"},
                "Cut fruits, add yogurt and honey, then mix gently.",
                "قطّع الفواكه وأضف الزبادي والعسل ثم اخلطها برفق.",
                "Healthy", "صحي", "7 min", "Easy", "سهل", R.drawable.recipe_yogurt_bowl));
        recipes.add(new Recipe(
                "Beef Potato Stew", "يخنة لحم بالبطاطا",
                new String[]{"beef", "potato", "tomato", "onion", "garlic", "water"},
                "Cook beef with onion and garlic, add potato and tomato, then simmer until tender.",
                "اطهِ اللحم مع البصل والثوم، ثم أضف البطاطا والطماطم واتركه حتى ينضج.",
                "Dinner", "عشاء", "55 min", "Medium", "متوسط", R.drawable.recipe_beef_stew));
        recipes.add(new Recipe(
                "Garlic Chicken Wrap", "راب الدجاج بالثوم",
                new String[]{"chicken", "bread", "garlic", "lettuce", "cucumber"},
                "Add garlic chicken and vegetables to bread, wrap tightly, and serve.",
                "ضع الدجاج بالثوم والخضار داخل الخبز، ثم لفّه وقدّمه.",
                "Snack", "وجبة خفيفة", "15 min", "Easy", "سهل", R.drawable.recipe_wrap));
        recipes.add(new Recipe(
                "Vegetable Pizza", "بيتزا الخضار",
                new String[]{"bread", "tomato", "cheese", "onion", "pepper"},
                "Spread tomato sauce over bread, add cheese and vegetables, then bake until melted.",
                "ضع صلصة الطماطم على الخبز، ثم أضف الجبن والخضار واخبزها حتى تذوب الجبنة.",
                "Dinner", "عشاء", "20 min", "Easy", "سهل", R.drawable.recipe_pizza));
        return recipes;
    }
}
