package com.smartchef.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.speech.RecognizerIntent;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int REQUEST_SPEECH = 101;
    private static final int REQUEST_GALLERY_IMAGES = 102;
    private static final int REQUEST_RECORD_AUDIO_PERMISSION = 103;
    private static final int REQUEST_CAMERA_IMAGE = 104;

    private LinearLayout rootLayout, topBar, heroCard, inputCard, quickIngredientsContainer, recentSearchContainer, resultsContainer, bottomBar;
    private TextView logoTitle, menuIcon, darkButton, appTitle, appSubtitle, inputTitle, quickTitle, recentTitle, resultsTitle, imagePrototypeNote;
    private EditText ingredientsInput;
    private Button languageButton, aboutButton, welcomeButton, recommendButton, voiceButton, imageButton, addImageIngredientButton, favoritesButton, homeNavButton;
    private ImageView imagePreview;
    private Spinner ingredientSpinner;

    private boolean isArabic;
    private boolean darkMode;
    private final List<Recipe> recipes = RecipeRepository.getRecipes();
    private final List<IngredientCategory> ingredientCategories = RecipeRepository.getIngredientCategories();
    private final String PREFS = "smart_chef_v3";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bindViews();
        isArabic = LanguageManager.isArabic(this);
        darkMode = getPrefs().getBoolean("dark_mode", false);
        setupActions();
        setupSpinner();
        applyLanguage();
        applyTheme();
        buildQuickIngredients();
        buildRecentSearches();
        showFeaturedRecipes();
        showWelcomeIfNeeded();
    }

    private SharedPreferences getPrefs() {
        return getSharedPreferences(PREFS, MODE_PRIVATE);
    }

    private void bindViews() {
        rootLayout = findViewById(R.id.rootLayout);
        topBar = findViewById(R.id.topBar);
        heroCard = findViewById(R.id.heroCard);
        inputCard = findViewById(R.id.inputCard);
        quickIngredientsContainer = findViewById(R.id.quickIngredientsContainer);
        recentSearchContainer = findViewById(R.id.recentSearchContainer);
        resultsContainer = findViewById(R.id.resultsContainer);
        bottomBar = findViewById(R.id.bottomBar);
        logoTitle = findViewById(R.id.logoTitle);
        menuIcon = findViewById(R.id.menuIcon);
        darkButton = findViewById(R.id.darkButton);
        appTitle = findViewById(R.id.appTitle);
        appSubtitle = findViewById(R.id.appSubtitle);
        inputTitle = findViewById(R.id.inputTitle);
        quickTitle = findViewById(R.id.quickTitle);
        recentTitle = findViewById(R.id.recentTitle);
        resultsTitle = findViewById(R.id.resultsTitle);
        imagePrototypeNote = findViewById(R.id.imagePrototypeNote);
        ingredientsInput = findViewById(R.id.ingredientsInput);
        languageButton = findViewById(R.id.languageButton);
        aboutButton = findViewById(R.id.aboutButton);
        welcomeButton = findViewById(R.id.welcomeButton);
        recommendButton = findViewById(R.id.recommendButton);
        voiceButton = findViewById(R.id.voiceButton);
        imageButton = findViewById(R.id.imageButton);
        addImageIngredientButton = findViewById(R.id.addImageIngredientButton);
        favoritesButton = findViewById(R.id.favoritesButton);
        homeNavButton = findViewById(R.id.homeNavButton);
        imagePreview = findViewById(R.id.imagePreview);
        ingredientSpinner = findViewById(R.id.ingredientSpinner);
    }

    private void setupActions() {
        languageButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                vibrate(v);
                isArabic = !isArabic;
                LanguageManager.setArabic(MainActivity.this, isArabic);
                setupSpinner();
                applyLanguage();
                buildQuickIngredients();
                buildRecentSearches();
                showFeaturedRecipes();
            }
        });
        darkButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                vibrate(v);
                darkMode = !darkMode;
                getPrefs().edit().putBoolean("dark_mode", darkMode).apply();
                applyTheme();
            }
        });
        recommendButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { vibrate(v); recommendRecipes(); }
        });
        voiceButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { vibrate(v); requestVoiceInput(); }
        });
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { vibrate(v); chooseImageSource(); }
        });
        addImageIngredientButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { vibrate(v); addSelectedImageIngredient(); }
        });
        aboutButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { vibrate(v); showAboutDialog(); }
        });
        welcomeButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { vibrate(v); showWelcomeDialog(); }
        });
        menuIcon.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { vibrate(v); showWelcomeDialog(); }
        });
        favoritesButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { vibrate(v); showFavorites(); }
        });
        homeNavButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { vibrate(v); showFeaturedRecipes(); }
        });
    }

    private void vibrate(View v) {
        if (v != null) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
    }

    private void setupSpinner() {
        List<String> labels = new ArrayList<>();
        for (IngredientCategory item : ingredientCategories) labels.add(isArabic ? item.nameAr : item.nameEn);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, labels);
        ingredientSpinner.setAdapter(adapter);
    }

    private void applyLanguage() {
        int direction = isArabic ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR;
        rootLayout.setLayoutDirection(direction);
        ingredientsInput.setTextDirection(isArabic ? View.TEXT_DIRECTION_RTL : View.TEXT_DIRECTION_LTR);
        ingredientsInput.setGravity(isArabic ? Gravity.RIGHT | Gravity.TOP : Gravity.LEFT | Gravity.TOP);

        if (isArabic) {
            logoTitle.setText("Smart Chef");
            appTitle.setText("مرحبًا بك في\nSmart Chef");
            appSubtitle.setText("اكتشف وصفات لذيذة من المكونات المتوفرة لديك واطبخ كالمحترفين.");
            welcomeButton.setText("ابدأ الطبخ");
            languageButton.setText("EN");
            aboutButton.setText("حول");
            favoritesButton.setText("المفضلة");
            homeNavButton.setText("الرئيسية");
            inputTitle.setText("أدخل المكونات المتوفرة لديك");
            ingredientsInput.setHint("مثال: بيض، طماطم، جبن، دجاج...");
            quickTitle.setText("مكونات سريعة");
            recentTitle.setText("بحث مؤخرًا");
            recommendButton.setText("اقتراح الوصفات ✨");
            voiceButton.setText("إدخال صوتي");
            imageButton.setText("كاميرا / صور");
            imagePrototypeNote.setText("تم اختيار الصورة. يمكنك إضافة أكثر من صورة، ثم اختيار المكوّن المتوقع لإدخاله في نظام التوصية.");
            addImageIngredientButton.setText("إضافة المكوّن المختار");
            resultsTitle.setText("الوصفات المقترحة");
            darkButton.setText(darkMode ? "☀" : "🌙");
        } else {
            logoTitle.setText("Smart Chef");
            appTitle.setText("Welcome to\nSmart Chef");
            appSubtitle.setText("Discover tasty recipes from your available ingredients and cook like a pro.");
            welcomeButton.setText("Start Cooking");
            languageButton.setText("AR");
            aboutButton.setText("About");
            favoritesButton.setText("Favorites");
            homeNavButton.setText("Home");
            inputTitle.setText("Enter Your Available Ingredients");
            ingredientsInput.setHint("Example: egg, tomato, cheese, chicken...");
            quickTitle.setText("Quick Ingredients");
            recentTitle.setText("Recent Searches");
            recommendButton.setText("Recommend Recipes ✨");
            voiceButton.setText("Voice Input");
            imageButton.setText("Camera / Images");
            imagePrototypeNote.setText("Image selected. You can add multiple images, then choose the expected ingredient to include it in recommendations.");
            addImageIngredientButton.setText("Add Selected Ingredient");
            resultsTitle.setText("Recommended Recipes");
            darkButton.setText(darkMode ? "☀" : "🌙");
        }
    }

    private void applyTheme() {
        int bg = darkMode ? Color.rgb(18,18,18) : getResources().getColor(R.color.cream_bg);
        int cardText = darkMode ? Color.WHITE : getResources().getColor(R.color.text_dark);
        int muted = darkMode ? Color.rgb(200,200,200) : getResources().getColor(R.color.text_muted);
        rootLayout.setBackgroundColor(bg);
        inputCard.setBackgroundResource(darkMode ? R.drawable.bg_dark_panel : R.drawable.bg_card);
        bottomBar.setBackgroundResource(darkMode ? R.drawable.bg_bottom_bar_dark : R.drawable.bg_bottom_bar);
        logoTitle.setTextColor(darkMode ? Color.WHITE : Color.rgb(59,31,13));
        menuIcon.setTextColor(darkMode ? Color.WHITE : getResources().getColor(R.color.text_dark));
        appTitle.setTextColor(cardText);
        appSubtitle.setTextColor(muted);
        inputTitle.setTextColor(cardText);
        quickTitle.setTextColor(cardText);
        recentTitle.setTextColor(cardText);
        resultsTitle.setTextColor(cardText);
        ingredientsInput.setTextColor(cardText);
        ingredientsInput.setHintTextColor(muted);
        darkButton.setText(darkMode ? "☀" : "🌙");
    }

    private void showWelcomeIfNeeded() {
        if (!getPrefs().getBoolean("welcome_seen", false)) {
            getPrefs().edit().putBoolean("welcome_seen", true).apply();
            showWelcomeDialog();
        }
    }

    private void showWelcomeDialog() {
        String text = isArabic ?
                "مرحبًا بك في Smart Chef.\n\nطريقة الاستخدام:\n1. اكتب المكونات الموجودة لديك أو اختر مكونات سريعة.\n2. يمكنك استخدام الإدخال الصوتي أو رفع صورة من الكاميرا أو المعرض.\n3. اضغط على اقتراح الوصفات لتظهر الوصفات المناسبة تحت منطقة الإدخال مباشرة.\n4. افتح التفاصيل لمعرفة المكونات والخطوات والبهارات.\n5. يمكنك حفظ الوصفة في المفضلة أو مشاركتها." :
                "Welcome to Smart Chef.\n\nHow to use:\n1. Type your available ingredients or use quick ingredients.\n2. You can use voice input or add images from camera/gallery.\n3. Press Recommend Recipes to show suggestions directly below the input area.\n4. Open details to see ingredients, steps and spices.\n5. Save recipes to favorites or share them.";
        new AlertDialog.Builder(this)
                .setTitle(isArabic ? "كيف تستخدم التطبيق؟" : "How to Use the App")
                .setMessage(text)
                .setPositiveButton(isArabic ? "ابدأ" : "Start", null)
                .show();
    }

    private void buildQuickIngredients() {
        quickIngredientsContainer.removeAllViews();
        int limit = Math.min(10, ingredientCategories.size());
        for (int i = 0; i < limit; i++) {
            final IngredientCategory ingredient = ingredientCategories.get(i);
            Button chip = chipButton((isArabic ? ingredient.nameAr : ingredient.nameEn) + " +");
            chip.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { vibrate(v); appendIngredient(ingredient.key); }
            });
            quickIngredientsContainer.addView(chip, chipParams());
        }
    }

    private Button chipButton(String text) {
        Button chip = new Button(this);
        chip.setText(text);
        chip.setTextColor(getResources().getColor(R.color.green_dark));
        chip.setTextSize(13);
        chip.setAllCaps(false);
        chip.setBackgroundResource(R.drawable.bg_chip);
        chip.setPadding(dp(10), 0, dp(10), 0);
        return chip;
    }

    private LinearLayout.LayoutParams chipParams() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(42));
        params.setMargins(0, 0, dp(8), 0);
        return params;
    }

    private void buildRecentSearches() {
        recentSearchContainer.removeAllViews();
        List<String> recent = getRecentSearches();
        if (recent.isEmpty()) {
            Button empty = chipButton(isArabic ? "لا يوجد بحث بعد" : "No recent searches");
            empty.setEnabled(false);
            recentSearchContainer.addView(empty, chipParams());
            return;
        }
        for (final String item : recent) {
            Button chip = chipButton(item);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { vibrate(v); ingredientsInput.setText(item); ingredientsInput.setSelection(ingredientsInput.getText().length()); recommendRecipes(); }
            });
            recentSearchContainer.addView(chip, chipParams());
        }
    }

    private void appendIngredient(String key) {
        String current = ingredientsInput.getText().toString().trim();
        String value = getIngredientLabel(key);
        if (!current.isEmpty() && !current.endsWith("،") && !current.endsWith(",")) current += isArabic ? "، " : ", ";
        ingredientsInput.setText(current + value);
        ingredientsInput.setSelection(ingredientsInput.getText().length());
    }

    private void addSelectedImageIngredient() {
        int index = ingredientSpinner.getSelectedItemPosition();
        if (index >= 0 && index < ingredientCategories.size()) appendIngredient(ingredientCategories.get(index).key);
    }

    private void recommendRecipes() {
        String input = ingredientsInput.getText().toString().trim();
        resultsContainer.removeAllViews();
        if (input.isEmpty()) {
            addMessageCard(isArabic ? "اكتب مكوّنًا واحدًا على الأقل أو استخدم الصوت أو الصورة، ثم اضغط على اقتراح الوصفات." : "Enter at least one ingredient, use voice, or add an image, then press Recommend Recipes.");
            return;
        }
        saveRecentSearch(input);
        buildRecentSearches();
        List<RecommendationResult> results = RecommendationEngine.recommend(input, recipes);
        if (results.isEmpty()) {
            addMessageCard(isArabic ? "لم يتم العثور على تطابق واضح. جرّب مثلًا: بيض، طماطم، جبن أو دجاج، أرز، بصل." : "No clear match was found. Try: egg, tomato, cheese or chicken, rice, onion.");
            return;
        }
        for (RecommendationResult result : results) addRecipeCard(result, true);
    }

    private void showFeaturedRecipes() {
        resultsContainer.removeAllViews();
        addMessageCard(isArabic ? "ابدأ بكتابة المكونات أو استخدم الإدخال الصوتي والصورة. ستظهر الوصفات المقترحة هنا مباشرة مع نسبة التطابق والمفضلة والمشاركة." : "Start by typing ingredients or using voice/image input. Recommendations will appear here with matching score, favorite and share options.");
        int limit = Math.min(5, recipes.size());
        for (int i = 0; i < limit; i++) addRecipeCard(new RecommendationResult(recipes.get(i), new ArrayList<String>()), false);
    }

    private void addMessageCard(String message) {
        TextView card = new TextView(this);
        card.setBackgroundResource(darkMode ? R.drawable.bg_dark_panel : R.drawable.bg_card);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setText(message);
        card.setTextColor(darkMode ? Color.rgb(220,220,220) : getResources().getColor(R.color.text_muted));
        card.setTextSize(15);
        card.setLineSpacing(0, 1.18f);
        card.setTextDirection(isArabic ? View.TEXT_DIRECTION_RTL : View.TEXT_DIRECTION_LTR);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 0, 0, dp(12));
        resultsContainer.addView(card, params);
    }

    private void addRecipeCard(final RecommendationResult result, boolean recommendationMode) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(darkMode ? R.drawable.bg_dark_panel : R.drawable.bg_card);
        card.setPadding(dp(12), dp(12), dp(12), dp(12));
        card.setLayoutDirection(isArabic ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cardParams.setMargins(0, 0, 0, dp(14));

        ImageView recipeImage = new ImageView(this);
        recipeImage.setImageResource(result.recipe.imageResId);
        recipeImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
        card.addView(recipeImage, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(170)));

        TextView title = new TextView(this);
        title.setText(isArabic ? result.recipe.nameAr : result.recipe.nameEn);
        title.setTextColor(darkMode ? Color.WHITE : getResources().getColor(R.color.text_dark));
        title.setTextSize(20);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setPadding(0, dp(10), 0, 0);
        title.setTextDirection(isArabic ? View.TEXT_DIRECTION_RTL : View.TEXT_DIRECTION_LTR);
        card.addView(title);

        TextView info = new TextView(this);
        info.setText(isArabic ? result.recipe.categoryAr + "  |  " + result.recipe.time + "  |  " + result.recipe.difficultyAr : result.recipe.categoryEn + "  |  " + result.recipe.time + "  |  " + result.recipe.difficultyEn);
        info.setTextColor(darkMode ? Color.rgb(200,200,200) : getResources().getColor(R.color.text_muted));
        info.setTextSize(13);
        info.setPadding(0, dp(6), 0, 0);
        card.addView(info);

        if (recommendationMode) {
            TextView score = new TextView(this);
            score.setText(isArabic ? "تطابق المكونات: " + result.percentage + "%" : "Ingredient Match: " + result.percentage + "%");
            score.setTextColor(getResources().getColor(R.color.green_dark));
            score.setTextSize(14);
            score.setTypeface(null, android.graphics.Typeface.BOLD);
            score.setPadding(dp(10), dp(8), dp(10), dp(8));
            score.setBackgroundResource(R.drawable.bg_score);
            LinearLayout.LayoutParams scoreParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            scoreParams.setMargins(0, dp(10), 0, 0);
            card.addView(score, scoreParams);

            TextView matched = new TextView(this);
            matched.setText(isArabic ? "المكونات المتطابقة من إدخالك: " + displayIngredients(result.matchedIngredients) : "Matched from your input: " + displayIngredients(result.matchedIngredients));
            matched.setTextColor(darkMode ? Color.WHITE : getResources().getColor(R.color.text_dark));
            matched.setTextSize(14);
            matched.setPadding(0, dp(8), 0, 0);
            card.addView(matched);
        }

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER);
        actions.setPadding(0, dp(12), 0, 0);

        Button detailsButton = smallActionButton(isArabic ? "التفاصيل" : "Details");
        detailsButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { vibrate(v); showRecipeDetails(result); }
        });
        actions.addView(detailsButton, actionParams());

        Button favButton = smallActionButton(isFavorite(result.recipe) ? (isArabic ? "★ محفوظ" : "★ Saved") : (isArabic ? "☆ المفضلة" : "☆ Favorite"));
        favButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { vibrate(v); toggleFavorite(result.recipe); Toast.makeText(MainActivity.this, isArabic ? "تم تحديث المفضلة" : "Favorites updated", Toast.LENGTH_SHORT).show(); }
        });
        actions.addView(favButton, actionParams());

        Button shareButton = smallActionButton(isArabic ? "مشاركة" : "Share");
        shareButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { vibrate(v); shareRecipe(result.recipe); }
        });
        actions.addView(shareButton, actionParams());

        card.addView(actions);
        resultsContainer.addView(card, cardParams);
    }

    private Button smallActionButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setTextColor(getResources().getColor(R.color.green_primary));
        b.setBackgroundResource(R.drawable.bg_button_outline);
        return b;
    }

    private LinearLayout.LayoutParams actionParams() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(46), 1);
        params.setMargins(dp(3), 0, dp(3), 0);
        return params;
    }

    private void showRecipeDetails(final RecommendationResult result) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(12), dp(12), dp(4));
        box.setLayoutDirection(isArabic ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);

        ImageView image = new ImageView(this);
        image.setImageResource(result.recipe.imageResId);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        box.addView(image, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(210)));

        TextView details = new TextView(this);
        details.setTextColor(getResources().getColor(R.color.text_dark));
        details.setTextSize(15);
        details.setLineSpacing(0, 1.18f);
        details.setPadding(0, dp(10), 0, 0);
        details.setTextDirection(isArabic ? View.TEXT_DIRECTION_RTL : View.TEXT_DIRECTION_LTR);
        if (isArabic) {
            details.setText("الوقت: " + result.recipe.time + "\n" +
                    "الصعوبة: " + result.recipe.difficultyAr + "\n\n" +
                    "المكونات المطلوبة:\n" + displayIngredients(result.recipe.ingredients) + "\n\n" +
                    "طريقة التحضير المفصلة:\n" + result.recipe.stepsAr);
        } else {
            details.setText("Time: " + result.recipe.time + "\n" +
                    "Difficulty: " + result.recipe.difficultyEn + "\n\n" +
                    "Required Ingredients:\n" + displayIngredients(result.recipe.ingredients) + "\n\n" +
                    "Detailed Preparation:\n" + result.recipe.stepsEn);
        }
        box.addView(details);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(box);
        new AlertDialog.Builder(this)
                .setTitle(isArabic ? result.recipe.nameAr : result.recipe.nameEn)
                .setView(scroll)
                .setPositiveButton(isArabic ? "إغلاق" : "Close", null)
                .setNeutralButton(isArabic ? "مشاركة" : "Share", (dialog, which) -> shareRecipe(result.recipe))
                .show();
    }

    private void requestVoiceInput() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_RECORD_AUDIO_PERMISSION);
        } else launchVoiceRecognition();
    }

    private void launchVoiceRecognition() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, isArabic ? "ar-SA" : "en-US");
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, isArabic ? "اذكر المكونات المتوفرة لديك" : "Say your available ingredients");
        try { startActivityForResult(intent, REQUEST_SPEECH); }
        catch (ActivityNotFoundException e) { Toast.makeText(this, isArabic ? "ميزة التعرف الصوتي غير متاحة على هذا الجهاز." : "Speech recognition is not available on this device.", Toast.LENGTH_LONG).show(); }
    }

    private void chooseImageSource() {
        String[] options = isArabic ? new String[]{"فتح الكاميرا", "اختيار صورة أو أكثر من المعرض"} : new String[]{"Open Camera", "Choose one or more images"};
        new AlertDialog.Builder(this)
                .setTitle(isArabic ? "إضافة صورة" : "Add Image")
                .setItems(options, (dialog, which) -> {
                    if (which == 0) openCamera(); else openGalleryMultiple();
                }).show();
    }

    private void openCamera() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        try { startActivityForResult(intent, REQUEST_CAMERA_IMAGE); }
        catch (ActivityNotFoundException e) { Toast.makeText(this, isArabic ? "لا يمكن فتح الكاميرا." : "Camera is not available.", Toast.LENGTH_LONG).show(); }
    }

    private void openGalleryMultiple() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        try { startActivityForResult(Intent.createChooser(intent, isArabic ? "اختر الصور" : "Choose images"), REQUEST_GALLERY_IMAGES); }
        catch (ActivityNotFoundException e) { Toast.makeText(this, isArabic ? "لا يوجد تطبيق مناسب لاختيار الصور." : "No suitable app was found to select images.", Toast.LENGTH_LONG).show(); }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_RECORD_AUDIO_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) launchVoiceRecognition();
            else Toast.makeText(this, isArabic ? "لا يمكن استخدام الإدخال الصوتي دون السماح بالميكروفون." : "Voice input requires microphone permission.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> matches = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (matches != null && !matches.isEmpty()) {
                ingredientsInput.setText(matches.get(0));
                ingredientsInput.setSelection(ingredientsInput.getText().length());
                recommendRecipes();
            }
        } else if (requestCode == REQUEST_GALLERY_IMAGES && resultCode == RESULT_OK && data != null) {
            int count = 1;
            Uri imageUri = data.getData();
            ClipData clipData = data.getClipData();
            if (clipData != null && clipData.getItemCount() > 0) {
                count = clipData.getItemCount();
                imageUri = clipData.getItemAt(0).getUri();
            }
            if (imageUri != null) {
                imagePreview.setImageURI(imageUri);
                showImageControls(count);
            }
        } else if (requestCode == REQUEST_CAMERA_IMAGE && resultCode == RESULT_OK && data != null) {
            Bundle extras = data.getExtras();
            if (extras != null && extras.get("data") instanceof Bitmap) {
                imagePreview.setImageBitmap((Bitmap) extras.get("data"));
                showImageControls(1);
            }
        }
    }

    private void showImageControls(int count) {
        imagePreview.setVisibility(View.VISIBLE);
        imagePrototypeNote.setVisibility(View.VISIBLE);
        ingredientSpinner.setVisibility(View.VISIBLE);
        addImageIngredientButton.setVisibility(View.VISIBLE);
        imagePrototypeNote.setText(isArabic ? "تمت إضافة " + count + " صورة. اختر المكوّن المتوقع ثم اضغط إضافة المكوّن المختار." : count + " image(s) added. Select the expected ingredient then press Add Selected Ingredient.");
    }

    private void showAboutDialog() {
        String text = isArabic ? getAboutTextAr() : getAboutTextEn();
        new AlertDialog.Builder(this)
                .setTitle(isArabic ? "عن Smart Chef" : "About Smart Chef")
                .setMessage(text)
                .setPositiveButton(isArabic ? "إغلاق" : "Close", null)
                .show();
    }

    private String getAboutTextAr() {
        return "Smart Chef هو تطبيق أندرويد لتوصية الوصفات بناءً على المكونات المتوفرة. يدعم الإدخال النصي والصوتي ورفع الصور من الكاميرا أو المعرض. يعتمد النظام على قاعدة وصفات محلية وخوارزمية مطابقة بسيطة ترتب النتائج حسب المكونات المتطابقة.\n\nتم تحسين هذه النسخة بإضافة شاشة تحميل، شاشة ترحيب، وضع داكن، مفضلة، بحث مؤخرًا، مشاركة الوصفة، وإظهار النتائج مباشرة بعد الإدخال.";
    }

    private String getAboutTextEn() {
        return "Smart Chef is an Android recipe recommendation app based on available ingredients. It supports text input, voice input, and image input from camera or gallery. The system uses a local recipe dataset and a simple matching algorithm to rank recipes.\n\nThis version includes a splash screen, onboarding guide, dark mode, favorites, recent searches, recipe sharing, and direct recommendations below the input area.";
    }

    private void shareRecipe(Recipe recipe) {
        String text = (isArabic ? recipe.nameAr : recipe.nameEn) + "\n\n" +
                (isArabic ? "المكونات: " : "Ingredients: ") + displayIngredients(recipe.ingredients) + "\n\n" +
                (isArabic ? "طريقة التحضير:\n" + recipe.stepsAr : "Preparation:\n" + recipe.stepsEn);
        Intent sendIntent = new Intent(Intent.ACTION_SEND);
        sendIntent.setType("text/plain");
        sendIntent.putExtra(Intent.EXTRA_TEXT, text);
        startActivity(Intent.createChooser(sendIntent, isArabic ? "مشاركة الوصفة" : "Share recipe"));
    }

    private void toggleFavorite(Recipe recipe) {
        Set<String> fav = new LinkedHashSet<>(getFavorites());
        if (fav.contains(recipe.nameEn)) fav.remove(recipe.nameEn); else fav.add(recipe.nameEn);
        getPrefs().edit().putString("favorites", join(fav)).apply();
        showFavorites();
    }

    private boolean isFavorite(Recipe recipe) {
        return getFavorites().contains(recipe.nameEn);
    }

    private List<String> getFavorites() {
        return splitStored(getPrefs().getString("favorites", ""));
    }

    private void showFavorites() {
        resultsContainer.removeAllViews();
        resultsTitle.setText(isArabic ? "الوصفات المفضلة" : "Favorite Recipes");
        List<String> fav = getFavorites();
        if (fav.isEmpty()) {
            addMessageCard(isArabic ? "لا توجد وصفات في المفضلة حتى الآن. افتح أي وصفة واضغط المفضلة." : "No favorite recipes yet. Add recipes using the Favorite button.");
            return;
        }
        for (Recipe recipe : recipes) if (fav.contains(recipe.nameEn)) addRecipeCard(new RecommendationResult(recipe, new ArrayList<String>()), false);
    }

    private void saveRecentSearch(String input) {
        List<String> recent = getRecentSearches();
        recent.remove(input);
        recent.add(0, input);
        while (recent.size() > 5) recent.remove(recent.size() - 1);
        getPrefs().edit().putString("recent", join(recent)).apply();
    }

    private List<String> getRecentSearches() {
        return splitStored(getPrefs().getString("recent", ""));
    }

    private List<String> splitStored(String raw) {
        List<String> list = new ArrayList<>();
        if (raw == null || raw.trim().isEmpty()) return list;
        String[] parts = raw.split("\\|\\|", -1);
        for (String p : parts) if (!p.trim().isEmpty()) list.add(p.trim());
        return list;
    }

    private String join(Iterable<String> values) {
        StringBuilder b = new StringBuilder();
        for (String v : values) {
            if (b.length() > 0) b.append("||");
            b.append(v);
        }
        return b.toString();
    }

    private String displayIngredients(List<String> ingredients) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < ingredients.size(); i++) {
            if (i > 0) builder.append(isArabic ? "، " : ", ");
            builder.append(getIngredientLabel(ingredients.get(i)));
        }
        return builder.toString();
    }

    private String displayIngredients(String[] ingredients) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < ingredients.length; i++) {
            if (i > 0) builder.append(isArabic ? "، " : ", ");
            builder.append(getIngredientLabel(ingredients[i]));
        }
        return builder.toString();
    }

    private String getIngredientLabel(String key) {
        for (IngredientCategory item : ingredientCategories) if (item.key.equals(key)) return isArabic ? item.nameAr : item.nameEn;
        if (key.equals("banana")) return isArabic ? "موز" : "Banana";
        if (key.equals("milk")) return isArabic ? "حليب" : "Milk";
        if (key.equals("lettuce")) return isArabic ? "خس" : "Lettuce";
        if (key.equals("lemon")) return isArabic ? "ليمون" : "Lemon";
        if (key.equals("oil")) return isArabic ? "زيت" : "Oil";
        if (key.equals("salt")) return isArabic ? "ملح" : "Salt";
        if (key.equals("pepper")) return isArabic ? "فلفل" : "Pepper";
        if (key.equals("water")) return isArabic ? "ماء" : "Water";
        return key;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
