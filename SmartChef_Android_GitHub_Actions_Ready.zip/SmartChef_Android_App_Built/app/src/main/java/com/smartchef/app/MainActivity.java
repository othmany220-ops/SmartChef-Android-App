package com.smartchef.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.speech.RecognizerIntent;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQUEST_SPEECH = 101;
    private static final int REQUEST_IMAGE = 102;
    private static final int REQUEST_RECORD_AUDIO_PERMISSION = 103;

    private LinearLayout rootLayout;
    private TextView appTitle;
    private TextView appSubtitle;
    private TextView inputTitle;
    private TextView inputHintText;
    private TextView resultsTitle;
    private TextView aboutText;
    private TextView presentationText;
    private TextView imagePrototypeNote;
    private EditText ingredientsInput;
    private Button languageButton;
    private Button aboutButton;
    private Button presentationButton;
    private Button recommendButton;
    private Button voiceButton;
    private Button imageButton;
    private Button addImageIngredientButton;
    private ImageView imagePreview;
    private Spinner ingredientSpinner;
    private LinearLayout resultsContainer;

    private boolean isArabic;
    private final List<Recipe> recipes = RecipeRepository.getRecipes();
    private final List<String> ingredientCategories = RecommendationEngine.getIngredientCategories();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bindViews();
        isArabic = LanguageManager.isArabic(this);
        setupSpinner();
        setupActions();
        applyLanguage();
        showWelcomeMessage();
    }

    private void bindViews() {
        rootLayout = findViewById(R.id.rootLayout);
        appTitle = findViewById(R.id.appTitle);
        appSubtitle = findViewById(R.id.appSubtitle);
        inputTitle = findViewById(R.id.inputTitle);
        inputHintText = findViewById(R.id.inputHintText);
        resultsTitle = findViewById(R.id.resultsTitle);
        aboutText = findViewById(R.id.aboutText);
        presentationText = findViewById(R.id.presentationText);
        ingredientsInput = findViewById(R.id.ingredientsInput);
        languageButton = findViewById(R.id.languageButton);
        aboutButton = findViewById(R.id.aboutButton);
        presentationButton = findViewById(R.id.presentationButton);
        recommendButton = findViewById(R.id.recommendButton);
        voiceButton = findViewById(R.id.voiceButton);
        imageButton = findViewById(R.id.imageButton);
        addImageIngredientButton = findViewById(R.id.addImageIngredientButton);
        imagePrototypeNote = findViewById(R.id.imagePrototypeNote);
        imagePreview = findViewById(R.id.imagePreview);
        ingredientSpinner = findViewById(R.id.ingredientSpinner);
        resultsContainer = findViewById(R.id.resultsContainer);
    }

    private void setupSpinner() {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                getIngredientDisplayList()
        );
        ingredientSpinner.setAdapter(adapter);
    }

    private void setupActions() {
        languageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isArabic = !isArabic;
                LanguageManager.setArabic(MainActivity.this, isArabic);
                applyLanguage();
                setupSpinner();
                clearResultsForLanguageSwitch();
            }
        });

        recommendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recommendRecipes();
            }
        });

        voiceButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestVoiceInput();
            }
        });

        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openImagePicker();
            }
        });

        addImageIngredientButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addSelectedImageIngredient();
            }
        });

        aboutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleAbout();
            }
        });

        presentationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                togglePresentation();
            }
        });
    }

    private void applyLanguage() {
        int direction = isArabic ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR;
        rootLayout.setLayoutDirection(direction);
        ingredientsInput.setTextDirection(direction);
        aboutText.setTextDirection(direction);
        presentationText.setTextDirection(direction);

        if (isArabic) {
            appTitle.setText("الشيف الذكي Smart Chef");
            appSubtitle.setText("تطبيق أندرويد يقترح وصفات مناسبة اعتمادًا على المكونات المتوفرة باستخدام النص، الصوت، والصورة.");
            languageButton.setText("English");
            aboutButton.setText("عن المشروع");
            presentationButton.setText("شرح العرض");
            inputTitle.setText("أدخل المكونات المتوفرة");
            inputHintText.setText("اكتب المكونات أو أدخلها بالصوت. مثال: بيض، طماطم، جبن");
            ingredientsInput.setHint("بيض، طماطم، دجاج");
            recommendButton.setText("اقتراح الوصفات");
            voiceButton.setText("إدخال صوتي");
            imageButton.setText("رفع صورة");
            imagePrototypeNote.setText("نموذج أولي للصورة: بعد رفع الصورة اختر فئة المكوّن المتوقعة لإضافتها إلى البحث.");
            addImageIngredientButton.setText("إضافة المكوّن المختار");
            resultsTitle.setText("الوصفات المقترحة");
            aboutText.setText(getAboutTextAr());
            presentationText.setText(getPresentationTextAr());
        } else {
            appTitle.setText("Smart Chef");
            appSubtitle.setText("An Android recipe recommendation app using text, voice, and image input.");
            languageButton.setText("العربية");
            aboutButton.setText("About");
            presentationButton.setText("Explain");
            inputTitle.setText("Enter Available Ingredients");
            inputHintText.setText("Write or speak ingredients separated by commas. Example: egg, tomato, cheese");
            ingredientsInput.setHint("egg, tomato, chicken");
            recommendButton.setText("Recommend Recipes");
            voiceButton.setText("Voice Input");
            imageButton.setText("Upload Image");
            imagePrototypeNote.setText("Image prototype: after uploading, choose the expected ingredient category to add it to the search.");
            addImageIngredientButton.setText("Add Selected Ingredient");
            resultsTitle.setText("Recommended Recipes");
            aboutText.setText(getAboutTextEn());
            presentationText.setText(getPresentationTextEn());
        }
    }

    private void showWelcomeMessage() {
        resultsContainer.removeAllViews();
        TextView welcome = new TextView(this);
        welcome.setBackgroundResource(R.drawable.bg_card);
        welcome.setPadding(dp(16), dp(16), dp(16), dp(16));
        welcome.setTextColor(getResources().getColor(R.color.text_muted));
        welcome.setTextSize(15);
        welcome.setLineSpacing(0, 1.15f);
        welcome.setText(isArabic
                ? "ابدأ بكتابة المكونات المتوفرة لديك أو استخدم الإدخال الصوتي، ثم اضغط على زر اقتراح الوصفات."
                : "Start by typing your available ingredients or use voice input, then press Recommend Recipes.");
        resultsContainer.addView(welcome);
    }

    private void clearResultsForLanguageSwitch() {
        showWelcomeMessage();
        if (aboutText.getVisibility() == View.VISIBLE) aboutText.setText(isArabic ? getAboutTextAr() : getAboutTextEn());
        if (presentationText.getVisibility() == View.VISIBLE) presentationText.setText(isArabic ? getPresentationTextAr() : getPresentationTextEn());
    }

    private void recommendRecipes() {
        String input = ingredientsInput.getText().toString().trim();
        resultsContainer.removeAllViews();

        if (input.isEmpty()) {
            addMessageCard(isArabic ? "الرجاء إدخال مكوّن واحد على الأقل قبل طلب التوصية." : "Please enter at least one ingredient before requesting recommendations.");
            return;
        }

        List<RecommendationResult> results = RecommendationEngine.recommend(input, recipes);
        if (results.isEmpty()) {
            addMessageCard(isArabic
                    ? "لم يتم العثور على وصفة مناسبة. جرّب إدخال مكونات أكثر مثل: بيض، طماطم، دجاج، جبن."
                    : "No suitable recipe was found. Try entering more ingredients such as egg, tomato, chicken, or cheese.");
            return;
        }

        for (RecommendationResult result : results) {
            addRecipeCard(result);
        }
    }

    private void addMessageCard(String message) {
        TextView card = new TextView(this);
        card.setBackgroundResource(R.drawable.bg_card);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setText(message);
        card.setTextColor(getResources().getColor(R.color.text_muted));
        card.setTextSize(15);
        card.setLineSpacing(0, 1.15f);
        card.setTextDirection(isArabic ? View.TEXT_DIRECTION_RTL : View.TEXT_DIRECTION_LTR);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, 0, 0, dp(12));
        resultsContainer.addView(card, params);
    }

    private void addRecipeCard(final RecommendationResult result) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.bg_card);
        card.setPadding(dp(18), dp(16), dp(18), dp(16));
        card.setLayoutDirection(isArabic ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);

        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        cardParams.setMargins(0, 0, 0, dp(14));

        TextView title = new TextView(this);
        title.setText(isArabic ? result.recipe.nameAr : result.recipe.nameEn);
        title.setTextColor(getResources().getColor(R.color.green_dark));
        title.setTextSize(19);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setTextDirection(isArabic ? View.TEXT_DIRECTION_RTL : View.TEXT_DIRECTION_LTR);
        card.addView(title);

        TextView info = new TextView(this);
        info.setText(isArabic
                ? "النوع: " + result.recipe.categoryAr + "  |  الوقت: " + result.recipe.time + "  |  الصعوبة: " + result.recipe.difficultyAr
                : "Category: " + result.recipe.categoryEn + "  |  Time: " + result.recipe.time + "  |  Difficulty: " + result.recipe.difficultyEn);
        info.setTextColor(getResources().getColor(R.color.text_muted));
        info.setTextSize(13);
        info.setPadding(0, dp(6), 0, 0);
        card.addView(info);

        TextView score = new TextView(this);
        score.setText(isArabic
                ? "درجة التوصية: " + result.score + " مكونات متطابقة — " + result.percentage + "%"
                : "Recommendation Score: " + result.score + " matched ingredients — " + result.percentage + "%");
        score.setTextColor(getResources().getColor(R.color.green_dark));
        score.setTextSize(14);
        score.setTypeface(null, android.graphics.Typeface.BOLD);
        score.setPadding(0, dp(10), 0, 0);
        card.addView(score);

        TextView matched = new TextView(this);
        matched.setText(isArabic
                ? "المكونات المتطابقة: " + displayIngredients(result.matchedIngredients)
                : "Matched Ingredients: " + displayIngredients(result.matchedIngredients));
        matched.setTextColor(getResources().getColor(R.color.text_dark));
        matched.setTextSize(14);
        matched.setPadding(0, dp(8), 0, 0);
        card.addView(matched);

        Button detailsButton = new Button(this);
        detailsButton.setText(isArabic ? "عرض التفاصيل" : "View Details");
        detailsButton.setTextColor(getResources().getColor(R.color.green_primary));
        detailsButton.setTypeface(null, android.graphics.Typeface.BOLD);
        detailsButton.setBackgroundResource(R.drawable.bg_button_outline);
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(48)
        );
        buttonParams.setMargins(0, dp(12), 0, 0);
        detailsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showRecipeDetails(result);
            }
        });
        card.addView(detailsButton, buttonParams);

        resultsContainer.addView(card, cardParams);
    }

    private void showRecipeDetails(RecommendationResult result) {
        String title = isArabic ? result.recipe.nameAr : result.recipe.nameEn;
        String message;
        if (isArabic) {
            message = "النوع: " + result.recipe.categoryAr + "\n"
                    + "الوقت: " + result.recipe.time + "\n"
                    + "الصعوبة: " + result.recipe.difficultyAr + "\n\n"
                    + "المكونات المطلوبة:\n" + displayIngredients(result.recipe.ingredients) + "\n\n"
                    + "المكونات المتطابقة:\n" + displayIngredients(result.matchedIngredients) + "\n\n"
                    + "طريقة التحضير:\n" + result.recipe.stepsAr;
        } else {
            message = "Category: " + result.recipe.categoryEn + "\n"
                    + "Time: " + result.recipe.time + "\n"
                    + "Difficulty: " + result.recipe.difficultyEn + "\n\n"
                    + "Required Ingredients:\n" + displayIngredients(result.recipe.ingredients) + "\n\n"
                    + "Matched Ingredients:\n" + displayIngredients(result.matchedIngredients) + "\n\n"
                    + "Preparation Steps:\n" + result.recipe.stepsEn;
        }

        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(isArabic ? "إغلاق" : "Close", null)
                .show();
    }

    private void requestVoiceInput() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_RECORD_AUDIO_PERMISSION);
        } else {
            launchVoiceRecognition();
        }
    }

    private void launchVoiceRecognition() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, isArabic ? "ar-SA" : "en-US");
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, isArabic ? "قل المكونات المتوفرة لديك" : "Say your available ingredients");

        try {
            startActivityForResult(intent, REQUEST_SPEECH);
        } catch (ActivityNotFoundException exception) {
            Toast.makeText(this,
                    isArabic ? "ميزة التعرف الصوتي غير متاحة على هذا الجهاز." : "Speech recognition is not available on this device.",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void openImagePicker() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");
        try {
            startActivityForResult(intent, REQUEST_IMAGE);
        } catch (ActivityNotFoundException exception) {
            Toast.makeText(this,
                    isArabic ? "لا يوجد تطبيق مناسب لاختيار الصور." : "No suitable app was found to select images.",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void addSelectedImageIngredient() {
        int index = ingredientSpinner.getSelectedItemPosition();
        if (index < 0 || index >= ingredientCategories.size()) return;
        String ingredient = ingredientCategories.get(index);
        String current = ingredientsInput.getText().toString().trim();
        if (!current.isEmpty() && !current.endsWith(",")) current += ", ";
        ingredientsInput.setText(current + ingredient);
        ingredientsInput.setSelection(ingredientsInput.getText().length());
        Toast.makeText(this,
                isArabic ? "تمت إضافة المكوّن المختار إلى مربع الإدخال." : "Selected ingredient added to the input field.",
                Toast.LENGTH_SHORT).show();
    }

    private void toggleAbout() {
        if (aboutText.getVisibility() == View.VISIBLE) {
            aboutText.setVisibility(View.GONE);
        } else {
            aboutText.setText(isArabic ? getAboutTextAr() : getAboutTextEn());
            aboutText.setVisibility(View.VISIBLE);
            presentationText.setVisibility(View.GONE);
        }
    }

    private void togglePresentation() {
        if (presentationText.getVisibility() == View.VISIBLE) {
            presentationText.setVisibility(View.GONE);
        } else {
            presentationText.setText(isArabic ? getPresentationTextAr() : getPresentationTextEn());
            presentationText.setVisibility(View.VISIBLE);
            aboutText.setVisibility(View.GONE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_RECORD_AUDIO_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                launchVoiceRecognition();
            } else {
                Toast.makeText(this,
                        isArabic ? "لا يمكن استخدام الإدخال الصوتي دون السماح بالميكروفون." : "Voice input requires microphone permission.",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> matches = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (matches != null && !matches.isEmpty()) {
                ingredientsInput.setText(matches.get(0));
                ingredientsInput.setSelection(ingredientsInput.getText().length());
            }
        }

        if (requestCode == REQUEST_IMAGE && resultCode == RESULT_OK && data != null) {
            Uri imageUri = data.getData();
            if (imageUri != null) {
                imagePreview.setImageURI(imageUri);
                imagePreview.setVisibility(View.VISIBLE);
                imagePrototypeNote.setVisibility(View.VISIBLE);
                ingredientSpinner.setVisibility(View.VISIBLE);
                addImageIngredientButton.setVisibility(View.VISIBLE);
            }
        }
    }

    private List<String> getIngredientDisplayList() {
        List<String> display = new ArrayList<>();
        for (String ingredient : ingredientCategories) {
            display.add(ingredientDisplay(ingredient));
        }
        return display;
    }

    private String displayIngredients(List<String> ingredients) {
        List<String> display = new ArrayList<>();
        for (String ingredient : ingredients) {
            display.add(ingredientDisplay(ingredient));
        }
        return join(display, ", ");
    }

    private String ingredientDisplay(String ingredient) {
        if (!isArabic) return ingredient;
        switch (ingredient) {
            case "egg": return "بيض";
            case "tomato": return "طماطم";
            case "cheese": return "جبن";
            case "milk": return "حليب";
            case "chicken": return "دجاج";
            case "lettuce": return "خس";
            case "cucumber": return "خيار";
            case "lemon": return "ليمون";
            case "pasta": return "معكرونة";
            case "garlic": return "ثوم";
            case "carrot": return "جزر";
            case "potato": return "بطاطا";
            case "onion": return "بصل";
            case "rice": return "أرز";
            case "bread": return "خبز";
            case "tuna": return "تونة";
            case "banana": return "موز";
            case "apple": return "تفاح";
            case "yogurt": return "زبادي";
            case "honey": return "عسل";
            case "beef": return "لحم";
            case "oil": return "زيت";
            case "salt": return "ملح";
            case "pepper": return "فلفل";
            case "water": return "ماء";
            default: return ingredient;
        }
    }

    private String join(List<String> values, String separator) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < values.size(); i++) {
            if (i > 0) builder.append(separator);
            builder.append(values.get(i));
        }
        return builder.toString();
    }

    private String getAboutTextEn() {
        return "About the Project\n\n"
                + "Smart Chef is an Android application developed for a Software Engineering academic project. The application helps users choose suitable recipes according to the ingredients available at home.\n\n"
                + "Input Methods\n"
                + "1. Text input: the user writes ingredients manually.\n"
                + "2. Voice input: the user speaks the ingredients and Android speech recognition converts the speech into text.\n"
                + "3. Image input: the user uploads an ingredient image. In this version, the image feature is implemented as a working prototype where the user selects the expected ingredient category. This can later be connected to a trained image classification model.\n\n"
                + "Recommendation Algorithm\n"
                + "The system stores a local recipe dataset. Each recipe contains a name, ingredients, preparation steps, category, time, and difficulty level. The app extracts ingredients from the user input, compares them with every recipe, counts the matched ingredients, and ranks recipes from the highest score to the lowest score.\n\n"
                + "Objective\n"
                + "The goal is to make cooking easier, reduce food waste, and provide a simple user experience using text, voice, and image-based interaction.";
    }

    private String getAboutTextAr() {
        return "عن المشروع\n\n"
                + "الشيف الذكي هو تطبيق أندرويد تم تطويره كمشروع أكاديمي في هندسة البرمجيات. يساعد التطبيق المستخدم على اختيار وصفات مناسبة بناءً على المكونات المتوفرة في المنزل.\n\n"
                + "طرق الإدخال\n"
                + "1. الإدخال النصي: يكتب المستخدم المكونات يدويًا.\n"
                + "2. الإدخال الصوتي: ينطق المستخدم المكونات ويحوّل نظام أندرويد الصوت إلى نص.\n"
                + "3. إدخال الصورة: يرفع المستخدم صورة لمكوّن غذائي. في هذه النسخة تم تنفيذها كنموذج أولي عملي يسمح باختيار فئة المكوّن بعد رفع الصورة، ويمكن تطويرها لاحقًا وربطها بنموذج تصنيف صور مدرّب.\n\n"
                + "خوارزمية التوصية\n"
                + "يعتمد التطبيق على بيانات وصفات محلية. تحتوي كل وصفة على الاسم والمكونات وخطوات التحضير والتصنيف والوقت والصعوبة. يستخرج التطبيق المكونات من إدخال المستخدم، ثم يقارنها مع مكونات كل وصفة، ويحسب عدد المكونات المتطابقة، ثم يرتب الوصفات من الأعلى تطابقًا إلى الأقل.\n\n"
                + "الهدف\n"
                + "يهدف التطبيق إلى تسهيل عملية الطبخ، وتقليل هدر الطعام، وتقديم تجربة استخدام سهلة وسريعة بالاعتماد على النص والصوت والصورة.";
    }

    private String getPresentationTextEn() {
        return "Presentation Script\n\n"
                + "Good morning. Our project is called Smart Chef. It is an Android recipe recommendation application designed to help users decide what to cook based on the ingredients they already have.\n\n"
                + "The user can enter ingredients manually, use voice input, or upload an ingredient image. The main feature that distinguishes our project is voice input, because many similar recipe applications depend mainly on text search.\n\n"
                + "After receiving the ingredients, the application uses a simple recommendation algorithm. It compares the user's ingredients with a local recipe dataset, calculates the number of matched ingredients, and displays the recipes with the highest match first.\n\n"
                + "The image input feature is implemented as a prototype. The user can upload an image and select the detected ingredient category. In future work, this part can be connected to a trained image classification model.\n\n"
                + "Overall, Smart Chef aims to make cooking easier, reduce food waste, and provide a fast and user-friendly cooking assistant.";
    }

    private String getPresentationTextAr() {
        return "نص الشرح أثناء المناقشة\n\n"
                + "صباح الخير. مشروعنا اسمه الشيف الذكي Smart Chef، وهو تطبيق أندرويد يقترح وصفات طعام مناسبة بناءً على المكونات المتوفرة لدى المستخدم في المنزل.\n\n"
                + "يمكن للمستخدم إدخال المكونات بثلاث طرق: الكتابة اليدوية، أو الإدخال الصوتي، أو رفع صورة لمكوّن غذائي. وتعد خاصية الإدخال الصوتي من أهم نقاط التميز في المشروع، لأن كثيرًا من التطبيقات المشابهة تعتمد فقط على البحث النصي.\n\n"
                + "بعد إدخال المكونات، يستخدم التطبيق خوارزمية توصية بسيطة. حيث تتم مقارنة مكونات المستخدم مع بيانات الوصفات المخزنة محليًا، ثم يتم حساب عدد المكونات المتطابقة، وبعد ذلك تُعرض الوصفات الأعلى تطابقًا أولًا.\n\n"
                + "أما خاصية الصورة فهي منفذة في هذه النسخة كنموذج أولي عملي، بحيث يرفع المستخدم الصورة ثم يختار فئة المكوّن المتوقعة. ويمكن في التطوير المستقبلي ربط هذه الخاصية بنموذج ذكاء اصطناعي مدرب للتعرف التلقائي على الصور.\n\n"
                + "بشكل عام، يهدف تطبيق الشيف الذكي إلى تسهيل عملية الطبخ، وتقليل هدر الطعام، وتقديم تجربة استخدام بسيطة وسريعة ومناسبة للمستخدم.";
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(value * density);
    }
}
