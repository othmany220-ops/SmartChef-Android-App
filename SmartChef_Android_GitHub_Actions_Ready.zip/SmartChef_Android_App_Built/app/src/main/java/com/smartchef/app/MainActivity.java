package com.smartchef.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.speech.RecognizerIntent;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQUEST_SPEECH = 101;
    private static final int REQUEST_IMAGE = 102;
    private static final int REQUEST_RECORD_AUDIO_PERMISSION = 103;

    private LinearLayout rootLayout;
    private TextView appTitle, appSubtitle, inputTitle, inputHintText, quickTitle, galleryTitle, resultsTitle, imagePrototypeNote;
    private EditText ingredientsInput;
    private Button languageButton, aboutButton, presentationButton, recommendButton, voiceButton, imageButton, addImageIngredientButton;
    private ImageView imagePreview;
    private Spinner ingredientSpinner;
    private LinearLayout quickIngredientsContainer, resultsContainer;
    private GridLayout ingredientGalleryContainer;

    private boolean isArabic;
    private final List<Recipe> recipes = RecipeRepository.getRecipes();
    private final List<IngredientCategory> ingredientCategories = RecipeRepository.getIngredientCategories();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bindViews();
        isArabic = LanguageManager.isArabic(this);
        setupActions();
        setupSpinner();
        applyLanguage();
        showFeaturedRecipes();
    }

    private void bindViews() {
        rootLayout = findViewById(R.id.rootLayout);
        appTitle = findViewById(R.id.appTitle);
        appSubtitle = findViewById(R.id.appSubtitle);
        inputTitle = findViewById(R.id.inputTitle);
        inputHintText = findViewById(R.id.inputHintText);
        quickTitle = findViewById(R.id.quickTitle);
        galleryTitle = findViewById(R.id.galleryTitle);
        resultsTitle = findViewById(R.id.resultsTitle);
        imagePrototypeNote = findViewById(R.id.imagePrototypeNote);
        ingredientsInput = findViewById(R.id.ingredientsInput);
        languageButton = findViewById(R.id.languageButton);
        aboutButton = findViewById(R.id.aboutButton);
        presentationButton = findViewById(R.id.presentationButton);
        recommendButton = findViewById(R.id.recommendButton);
        voiceButton = findViewById(R.id.voiceButton);
        imageButton = findViewById(R.id.imageButton);
        addImageIngredientButton = findViewById(R.id.addImageIngredientButton);
        imagePreview = findViewById(R.id.imagePreview);
        ingredientSpinner = findViewById(R.id.ingredientSpinner);
        quickIngredientsContainer = findViewById(R.id.quickIngredientsContainer);
        ingredientGalleryContainer = findViewById(R.id.ingredientGalleryContainer);
        resultsContainer = findViewById(R.id.resultsContainer);
    }

    private void setupActions() {
        languageButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                isArabic = !isArabic;
                LanguageManager.setArabic(MainActivity.this, isArabic);
                setupSpinner();
                applyLanguage();
                showFeaturedRecipes();
            }
        });
        recommendButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { recommendRecipes(); }
        });
        voiceButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { requestVoiceInput(); }
        });
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openImagePicker(); }
        });
        addImageIngredientButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { addSelectedImageIngredient(); }
        });
        aboutButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showAboutDialog(); }
        });
        presentationButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showPresentationDialog(); }
        });
    }

    private void setupSpinner() {
        List<String> labels = new ArrayList<>();
        for (IngredientCategory item : ingredientCategories) labels.add(isArabic ? item.nameAr : item.nameEn);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, labels);
        ingredientSpinner.setAdapter(adapter);
    }

    private void applyLanguage() {
        int direction = isArabic ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR;
        rootLayout.setLayoutDirection(direction);
        ingredientsInput.setTextDirection(isArabic ? View.TEXT_DIRECTION_RTL : View.TEXT_DIRECTION_LTR);
        ingredientsInput.setGravity(isArabic ? Gravity.RIGHT | Gravity.TOP : Gravity.LEFT | Gravity.TOP);

        if (isArabic) {
            appTitle.setText("Smart Chef\nالشيف الذكي");
            appSubtitle.setText("نظام أندرويد كامل يقترح وصفات بالاعتماد على النص، الصوت، والصورة، مع صور للوصفات والمكونات.");
            languageButton.setText("ENGLISH");
            aboutButton.setText("عن النظام");
            presentationButton.setText("شرح العرض");
            inputTitle.setText("أدخل المكونات المتوفرة");
            inputHintText.setText("اكتب المكونات أو استخدم الصوت أو اختر صورة. مثال: بيض، طماطم، دجاج");
            ingredientsInput.setHint("بيض، طماطم، دجاج");
            quickTitle.setText("مكونات سريعة");
            recommendButton.setText("اقتراح الوصفات");
            voiceButton.setText("إدخال صوتي");
            imageButton.setText("رفع صورة");
            imagePrototypeNote.setText("تم رفع الصورة. اختر فئة المكوّن المتوقعة لإضافتها إلى البحث. هذه نسخة تعليمية قابلة للربط لاحقًا بنموذج ذكاء اصطناعي.");
            addImageIngredientButton.setText("إضافة المكوّن المختار");
            galleryTitle.setText("صور فئات المكونات");
            resultsTitle.setText("الوصفات المقترحة");
        } else {
            appTitle.setText("Smart Chef");
            appSubtitle.setText("A complete Android recipe recommendation system using text, voice, and image input with recipe and ingredient images.");
            languageButton.setText("العربية");
            aboutButton.setText("About");
            presentationButton.setText("Explain");
            inputTitle.setText("Enter Available Ingredients");
            inputHintText.setText("Type ingredients, use voice, or upload an image. Example: egg, tomato, chicken");
            ingredientsInput.setHint("egg, tomato, chicken");
            quickTitle.setText("Quick Ingredients");
            recommendButton.setText("Recommend Recipes");
            voiceButton.setText("Voice Input");
            imageButton.setText("Upload Image");
            imagePrototypeNote.setText("Image uploaded. Choose the expected ingredient category to add it to the search. This educational version can later be connected to an AI image model.");
            addImageIngredientButton.setText("Add Selected Ingredient");
            galleryTitle.setText("Ingredient Image Classes");
            resultsTitle.setText("Recommended Recipes");
        }
        buildQuickIngredients();
        buildIngredientGallery();
    }

    private void buildQuickIngredients() {
        quickIngredientsContainer.removeAllViews();
        for (final IngredientCategory ingredient : ingredientCategories) {
            Button chip = new Button(this);
            chip.setText((isArabic ? ingredient.nameAr : ingredient.nameEn) + " +");
            chip.setTextColor(getResources().getColor(R.color.green_dark));
            chip.setTextSize(13);
            chip.setAllCaps(false);
            chip.setBackgroundResource(R.drawable.bg_chip);
            chip.setPadding(dp(10), 0, dp(10), 0);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(42));
            params.setMargins(0, 0, dp(8), 0);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { appendIngredient(ingredient); }
            });
            quickIngredientsContainer.addView(chip, params);
        }
    }

    private void buildIngredientGallery() {
        ingredientGalleryContainer.removeAllViews();
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int itemWidth = (screenWidth - dp(48)) / 2;
        for (final IngredientCategory ingredient : ingredientCategories) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(Gravity.CENTER);
            card.setBackgroundResource(R.drawable.bg_card);
            card.setPadding(dp(8), dp(8), dp(8), dp(8));
            card.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { appendIngredient(ingredient); }
            });

            ImageView img = new ImageView(this);
            img.setImageResource(ingredient.imageResId);
            img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            card.addView(img, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(95)));

            TextView label = new TextView(this);
            label.setText(isArabic ? ingredient.nameAr : ingredient.nameEn);
            label.setTextColor(getResources().getColor(R.color.green_dark));
            label.setTextSize(14);
            label.setGravity(Gravity.CENTER);
            label.setTypeface(null, android.graphics.Typeface.BOLD);
            label.setPadding(0, dp(6), 0, 0);
            card.addView(label);

            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.width = itemWidth;
            params.height = GridLayout.LayoutParams.WRAP_CONTENT;
            params.setMargins(dp(4), dp(4), dp(4), dp(8));
            ingredientGalleryContainer.addView(card, params);
        }
    }

    private void appendIngredient(IngredientCategory ingredient) {
        String current = ingredientsInput.getText().toString().trim();
        String value = isArabic ? ingredient.nameAr : ingredient.key;
        if (!current.isEmpty() && !current.endsWith("،") && !current.endsWith(",")) current += isArabic ? "، " : ", ";
        ingredientsInput.setText(current + value);
        ingredientsInput.setSelection(ingredientsInput.getText().length());
    }

    private void addSelectedImageIngredient() {
        int index = ingredientSpinner.getSelectedItemPosition();
        if (index >= 0 && index < ingredientCategories.size()) appendIngredient(ingredientCategories.get(index));
    }

    private void recommendRecipes() {
        String input = ingredientsInput.getText().toString().trim();
        resultsContainer.removeAllViews();
        if (input.isEmpty()) {
            addMessageCard(isArabic ? "أدخل مكوّنًا واحدًا على الأقل أو اختر من صور المكونات، ثم اضغط على اقتراح الوصفات." : "Enter at least one ingredient or choose from the ingredient images, then press Recommend Recipes.");
            showFeaturedRecipesAppend();
            return;
        }
        List<RecommendationResult> results = RecommendationEngine.recommend(input, recipes);
        if (results.isEmpty()) {
            addMessageCard(isArabic ? "لم يتم العثور على تطابق واضح. جرّب مكونات مثل: بيض، طماطم، دجاج، جبن، أرز." : "No clear match was found. Try ingredients such as egg, tomato, chicken, cheese, or rice.");
            showFeaturedRecipesAppend();
            return;
        }
        for (RecommendationResult result : results) addRecipeCard(result, true);
    }

    private void showFeaturedRecipes() {
        resultsContainer.removeAllViews();
        addMessageCard(isArabic ? "النظام يحتوي على قاعدة وصفات محلية، صور للوصفات، صور لفئات المكونات، إدخال نصي، إدخال صوتي، ورفع صورة. أدخل المكونات لتظهر التوصيات مرتبة حسب التطابق." : "The system includes a local recipe dataset, recipe images, ingredient image classes, text input, voice input, and image upload. Enter ingredients to see ranked recommendations.");
        showFeaturedRecipesAppend();
    }

    private void showFeaturedRecipesAppend() {
        int limit = Math.min(6, recipes.size());
        for (int i = 0; i < limit; i++) addRecipeCard(new RecommendationResult(recipes.get(i), new ArrayList<String>()), false);
    }

    private void addMessageCard(String message) {
        TextView card = new TextView(this);
        card.setBackgroundResource(R.drawable.bg_card);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setText(message);
        card.setTextColor(getResources().getColor(R.color.text_muted));
        card.setTextSize(15);
        card.setLineSpacing(0, 1.18f);
        card.setTextDirection(isArabic ? View.TEXT_DIRECTION_RTL : View.TEXT_DIRECTION_LTR);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 0, 0, dp(12));
        resultsContainer.addView(card, params);
    }

    private void addRecipeCard(final RecommendationResult result, boolean recommendationMode) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.bg_card);
        card.setPadding(dp(12), dp(12), dp(12), dp(12));
        card.setLayoutDirection(isArabic ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cardParams.setMargins(0, 0, 0, dp(14));

        ImageView recipeImage = new ImageView(this);
        recipeImage.setImageResource(result.recipe.imageResId);
        recipeImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
        card.addView(recipeImage, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(185)));

        TextView title = new TextView(this);
        title.setText(isArabic ? result.recipe.nameAr : result.recipe.nameEn);
        title.setTextColor(getResources().getColor(R.color.green_dark));
        title.setTextSize(20);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setPadding(0, dp(10), 0, 0);
        title.setTextDirection(isArabic ? View.TEXT_DIRECTION_RTL : View.TEXT_DIRECTION_LTR);
        card.addView(title);

        TextView info = new TextView(this);
        info.setText(isArabic ? "النوع: " + result.recipe.categoryAr + "  |  الوقت: " + result.recipe.time + "  |  الصعوبة: " + result.recipe.difficultyAr : "Category: " + result.recipe.categoryEn + "  |  Time: " + result.recipe.time + "  |  Difficulty: " + result.recipe.difficultyEn);
        info.setTextColor(getResources().getColor(R.color.text_muted));
        info.setTextSize(13);
        info.setPadding(0, dp(6), 0, 0);
        card.addView(info);

        if (recommendationMode) {
            TextView score = new TextView(this);
            score.setText(isArabic ? "درجة التوصية: " + result.score + " مكونات متطابقة — " + result.percentage + "%" : "Recommendation Score: " + result.score + " matched ingredients — " + result.percentage + "%");
            score.setTextColor(getResources().getColor(R.color.green_dark));
            score.setTextSize(14);
            score.setTypeface(null, android.graphics.Typeface.BOLD);
            score.setPadding(dp(10), dp(8), dp(10), dp(8));
            score.setBackgroundResource(R.drawable.bg_score);
            LinearLayout.LayoutParams scoreParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            scoreParams.setMargins(0, dp(10), 0, 0);
            card.addView(score, scoreParams);

            TextView matched = new TextView(this);
            matched.setText(isArabic ? "المكونات المتطابقة: " + displayIngredients(result.matchedIngredients) : "Matched Ingredients: " + displayIngredients(result.matchedIngredients));
            matched.setTextColor(getResources().getColor(R.color.text_dark));
            matched.setTextSize(14);
            matched.setPadding(0, dp(8), 0, 0);
            card.addView(matched);
        } else {
            TextView sample = new TextView(this);
            sample.setText(isArabic ? "وصفة موجودة ضمن قاعدة البيانات المحلية للتطبيق." : "Sample recipe included in the local app dataset.");
            sample.setTextColor(getResources().getColor(R.color.text_muted));
            sample.setTextSize(13);
            sample.setPadding(0, dp(8), 0, 0);
            card.addView(sample);
        }

        Button detailsButton = new Button(this);
        detailsButton.setText(isArabic ? "عرض التفاصيل" : "View Details");
        detailsButton.setTextColor(getResources().getColor(R.color.green_primary));
        detailsButton.setTypeface(null, android.graphics.Typeface.BOLD);
        detailsButton.setAllCaps(false);
        detailsButton.setBackgroundResource(R.drawable.bg_button_outline);
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48));
        buttonParams.setMargins(0, dp(12), 0, 0);
        detailsButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showRecipeDetails(result); }
        });
        card.addView(detailsButton, buttonParams);
        resultsContainer.addView(card, cardParams);
    }

    private void showRecipeDetails(RecommendationResult result) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(12), dp(12), dp(4));
        box.setLayoutDirection(isArabic ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);

        ImageView image = new ImageView(this);
        image.setImageResource(result.recipe.imageResId);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        box.addView(image, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(210)));

        TextView details = new TextView(this);
        details.setTextColor(getResources().getColor(R.color.text_dark));
        details.setTextSize(15);
        details.setLineSpacing(0, 1.18f);
        details.setPadding(0, dp(10), 0, 0);
        details.setTextDirection(isArabic ? View.TEXT_DIRECTION_RTL : View.TEXT_DIRECTION_LTR);
        if (isArabic) {
            details.setText("النوع: " + result.recipe.categoryAr + "\n" +
                    "الوقت: " + result.recipe.time + "\n" +
                    "الصعوبة: " + result.recipe.difficultyAr + "\n\n" +
                    "المكونات المطلوبة:\n" + displayIngredients(result.recipe.ingredients) + "\n\n" +
                    "طريقة التحضير:\n" + result.recipe.stepsAr);
        } else {
            details.setText("Category: " + result.recipe.categoryEn + "\n" +
                    "Time: " + result.recipe.time + "\n" +
                    "Difficulty: " + result.recipe.difficultyEn + "\n\n" +
                    "Required Ingredients:\n" + displayIngredients(result.recipe.ingredients) + "\n\n" +
                    "Preparation Steps:\n" + result.recipe.stepsEn);
        }
        box.addView(details);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(box);
        new AlertDialog.Builder(this)
                .setTitle(isArabic ? result.recipe.nameAr : result.recipe.nameEn)
                .setView(scroll)
                .setPositiveButton(isArabic ? "إغلاق" : "Close", null)
                .show();
    }

    private void requestVoiceInput() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_RECORD_AUDIO_PERMISSION);
        } else launchVoiceRecognition();
    }

    private void launchVoiceRecognition() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, isArabic ? "ar-SA" : "en-US");
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, isArabic ? "قل المكونات المتوفرة لديك" : "Say your available ingredients");
        try { startActivityForResult(intent, REQUEST_SPEECH); }
        catch (ActivityNotFoundException e) { Toast.makeText(this, isArabic ? "ميزة التعرف الصوتي غير متاحة على هذا الجهاز." : "Speech recognition is not available on this device.", Toast.LENGTH_LONG).show(); }
    }

    private void openImagePicker() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");
        try { startActivityForResult(intent, REQUEST_IMAGE); }
        catch (ActivityNotFoundException e) { Toast.makeText(this, isArabic ? "لا يوجد تطبيق مناسب لاختيار الصور." : "No suitable app was found to select images.", Toast.LENGTH_LONG).show(); }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_RECORD_AUDIO_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) launchVoiceRecognition();
            else Toast.makeText(this, isArabic ? "لا يمكن استخدام الإدخال الصوتي دون السماح بالميكروفون." : "Voice input requires microphone permission.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> matches = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (matches != null && !matches.isEmpty()) {
                ingredientsInput.setText(matches.get(0));
                ingredientsInput.setSelection(ingredientsInput.getText().length());
            }
        }
        if (requestCode == REQUEST_IMAGE && resultCode == RESULT_OK && data != null) {
            Uri imageUri = data.getData();
            if (imageUri != null) {
                imagePreview.setImageURI(imageUri);
                imagePreview.setVisibility(View.VISIBLE);
                imagePrototypeNote.setVisibility(View.VISIBLE);
                ingredientSpinner.setVisibility(View.VISIBLE);
                addImageIngredientButton.setVisibility(View.VISIBLE);
            }
        }
    }

    private void showAboutDialog() {
        String text = isArabic ? getAboutTextAr() : getAboutTextEn();
        new AlertDialog.Builder(this)
                .setTitle(isArabic ? "عن نظام Smart Chef" : "About Smart Chef")
                .setMessage(text)
                .setPositiveButton(isArabic ? "إغلاق" : "Close", null)
                .show();
    }

    private void showPresentationDialog() {
        String text = isArabic ? getPresentationTextAr() : getPresentationTextEn();
        new AlertDialog.Builder(this)
                .setTitle(isArabic ? "نص شرح العرض" : "Presentation Script")
                .setMessage(text)
                .setPositiveButton(isArabic ? "إغلاق" : "Close", null)
                .show();
    }

    private String getAboutTextAr() {
        return "Smart Chef هو نظام توصية وصفات يعمل كتطبيق أندرويد. يتكون النظام من واجهة مستخدم، قاعدة وصفات محلية، صور للوصفات، صور لفئات المكونات، إدخال نصي، إدخال صوتي، وميزة رفع صورة.\n\n" +
                "آلية العمل: يكتب المستخدم المكونات أو يدخلها بالصوت أو يختارها من الصور. بعد ذلك يحلل النظام النص ويحوّل الكلمات العربية أو الإنجليزية إلى مكونات معيارية، ثم يقارنها مع مكونات كل وصفة ويعرض الوصفات الأعلى تطابقًا أولًا.\n\n" +
                "ميزة الصورة في هذه النسخة تعمل كنموذج أولي تعليمي: يرفع المستخدم صورة ثم يختار فئة المكوّن المتوقعة. ويمكن لاحقًا ربط هذا الجزء بنموذج تصنيف صور مدرب.";
    }

    private String getAboutTextEn() {
        return "Smart Chef is a recipe recommendation system implemented as an Android application. The system includes a user interface, local recipe dataset, recipe images, ingredient image classes, text input, voice input, and image upload.\n\n" +
                "Workflow: the user types ingredients, speaks them, or selects them from images. The system normalizes Arabic and English words into standard ingredient keys, compares them with every recipe, and ranks recipes according to the number of matched ingredients.\n\n" +
                "The image feature is implemented as an educational prototype: the user uploads an image and selects the expected ingredient class. This part can later be connected to a trained image classification model.";
    }

    private String getPresentationTextAr() {
        return "هذا التطبيق يسمى Smart Chef. فكرته مساعدة المستخدم على اختيار وصفات مناسبة اعتمادًا على المكونات الموجودة لديه في المنزل. يستطيع المستخدم إدخال المكونات بالكتابة أو بالصوت أو من خلال رفع صورة. بعد ذلك يقوم النظام بتحليل المكونات ومقارنتها مع قاعدة وصفات محلية، ثم يعرض أفضل الوصفات حسب درجة التطابق. يتميز التطبيق بوجود واجهة عربية وإنجليزية، صور للوصفات، صور لفئات المكونات، ونظام توصية بسيط يمكن شرحه وتجربته أمام الدكتور.";
    }

    private String getPresentationTextEn() {
        return "This application is called Smart Chef. It helps users choose suitable recipes based on the ingredients they already have at home. Users can enter ingredients by typing, voice input, or image upload. The system analyzes the ingredients, compares them with a local recipe dataset, and ranks the most suitable recipes according to the matching score. The app supports Arabic and English, includes recipe images and ingredient image classes, and provides a simple recommendation algorithm that can be clearly demonstrated during the academic discussion.";
    }

    private String displayIngredients(List<String> ingredients) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < ingredients.size(); i++) {
            if (i > 0) builder.append(isArabic ? "، " : ", ");
            builder.append(getIngredientLabel(ingredients.get(i)));
        }
        return builder.toString();
    }

    private String displayIngredients(String[] ingredients) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < ingredients.length; i++) {
            if (i > 0) builder.append(isArabic ? "، " : ", ");
            builder.append(getIngredientLabel(ingredients[i]));
        }
        return builder.toString();
    }

    private String getIngredientLabel(String key) {
        for (IngredientCategory item : ingredientCategories) if (item.key.equals(key)) return isArabic ? item.nameAr : item.nameEn;
        if (key.equals("tuna")) return isArabic ? "تونة" : "Tuna";
        if (key.equals("lemon")) return isArabic ? "ليمون" : "Lemon";
        if (key.equals("yogurt")) return isArabic ? "زبادي" : "Yogurt";
        if (key.equals("honey")) return isArabic ? "عسل" : "Honey";
        if (key.equals("beef")) return isArabic ? "لحم" : "Beef";
        if (key.equals("oil")) return isArabic ? "زيت" : "Oil";
        if (key.equals("salt")) return isArabic ? "ملح" : "Salt";
        if (key.equals("pepper")) return isArabic ? "فلفل" : "Pepper";
        if (key.equals("water")) return isArabic ? "ماء" : "Water";
        return key;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
