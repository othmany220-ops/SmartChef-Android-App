package com.smartchef.app;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class RecommendationEngine {
    private static final Map<String, List<String>> SYNONYMS = new LinkedHashMap<>();

    static {
        SYNONYMS.put("egg", java.util.Arrays.asList("egg", "eggs", "بيض", "بيضة", "البيض"));
        SYNONYMS.put("tomato", java.util.Arrays.asList("tomato", "tomatoes", "طماطم", "بندورة", "بندوره"));
        SYNONYMS.put("cheese", java.util.Arrays.asList("cheese", "جبن", "جبنة", "جبنه"));
        SYNONYMS.put("chicken", java.util.Arrays.asList("chicken", "دجاج", "فراخ"));
        SYNONYMS.put("rice", java.util.Arrays.asList("rice", "basmati", "أرز", "ارز", "رز"));
        SYNONYMS.put("pasta", java.util.Arrays.asList("pasta", "macaroni", "معكرونة", "مكرونة", "باستا"));
        SYNONYMS.put("onion", java.util.Arrays.asList("onion", "onions", "بصل"));
        SYNONYMS.put("garlic", java.util.Arrays.asList("garlic", "ثوم"));
        SYNONYMS.put("potato", java.util.Arrays.asList("potato", "potatoes", "بطاطا", "بطاطس"));
        SYNONYMS.put("carrot", java.util.Arrays.asList("carrot", "carrots", "جزر"));
        SYNONYMS.put("cucumber", java.util.Arrays.asList("cucumber", "cucumbers", "خيار"));
        SYNONYMS.put("parsley", java.util.Arrays.asList("parsley", "بقدونس", "معدنوس"));
        SYNONYMS.put("tuna", java.util.Arrays.asList("tuna", "تونة", "تونه"));
        SYNONYMS.put("yogurt", java.util.Arrays.asList("yogurt", "yoghurt", "زبادي", "لبن", "جميد", "jameed", "لبن جميد"));
        SYNONYMS.put("red_lentils", java.util.Arrays.asList("red lentils", "lentils", "عدس", "عدس احمر", "عدس أحمر"));
        SYNONYMS.put("beef", java.util.Arrays.asList("beef", "meat", "lamb", "لحم", "لحمة", "لحمه", "خاروف", "غنم"));
        SYNONYMS.put("spices", java.util.Arrays.asList("spices", "kabsa spices", "بهارات", "بهارات كبسة", "كبسة", "كبسه", "توابل"));
        SYNONYMS.put("oil", java.util.Arrays.asList("oil", "زيت"));
        SYNONYMS.put("salt", java.util.Arrays.asList("salt", "ملح"));
        SYNONYMS.put("pepper", java.util.Arrays.asList("pepper", "فلفل"));
        SYNONYMS.put("water", java.util.Arrays.asList("water", "ماء", "مي"));
        SYNONYMS.put("banana", java.util.Arrays.asList("banana", "bananas", "موز", "الموز"));
        SYNONYMS.put("milk", java.util.Arrays.asList("milk", "حليب", "لبن حليب"));
        SYNONYMS.put("lettuce", java.util.Arrays.asList("lettuce", "خس"));
        SYNONYMS.put("lemon", java.util.Arrays.asList("lemon", "ليمون", "حامض"));
    }

    public static List<RecommendationResult> recommend(String rawInput, List<Recipe> recipes) {
        List<String> userIngredients = extractIngredients(rawInput);
        List<RecommendationResult> results = new ArrayList<>();

        String normalizedInput = normalize(rawInput);
        for (Recipe recipe : recipes) {
            List<String> matched = new ArrayList<>();
            for (String ingredient : recipe.ingredients) {
                if (userIngredients.contains(ingredient)) matched.add(ingredient);
            }
            // Dish-name support for common local recipes. This helps when the user writes "منسف" or "كبسة" directly.
            if ((normalizedInput.contains("منسف") || normalizedInput.contains("mansaf")) && recipe.nameEn.toLowerCase(Locale.ROOT).contains("mansaf")) {
                for (String ingredient : recipe.ingredients) if (!matched.contains(ingredient)) matched.add(ingredient);
            }
            if ((normalizedInput.contains("كبسة") || normalizedInput.contains("كبسه") || normalizedInput.contains("kabsa")) && recipe.nameEn.toLowerCase(Locale.ROOT).contains("kabsa")) {
                for (String ingredient : recipe.ingredients) if (!matched.contains(ingredient)) matched.add(ingredient);
            }
            if (!matched.isEmpty()) results.add(new RecommendationResult(recipe, matched));
        }

        Collections.sort(results, new Comparator<RecommendationResult>() {
            @Override
            public int compare(RecommendationResult a, RecommendationResult b) {
                if (b.score != a.score) return b.score - a.score;
                return b.percentage - a.percentage;
            }
        });
        return results;
    }

    public static List<String> extractIngredients(String rawInput) {
        String input = normalize(rawInput);
        List<String> found = new ArrayList<>();
        for (Map.Entry<String, List<String>> entry : SYNONYMS.entrySet()) {
            for (String synonym : entry.getValue()) {
                if (containsIngredient(input, normalize(synonym))) {
                    found.add(entry.getKey());
                    break;
                }
            }
        }
        return found;
    }

    private static boolean containsIngredient(String input, String ingredient) {
        if (input == null || input.trim().isEmpty()) return false;
        String paddedInput = " " + input + " ";
        String paddedIngredient = " " + ingredient + " ";
        if (paddedInput.contains(paddedIngredient)) return true;
        // Arabic users may type attached words such as "والطماطم"; keep a controlled fallback only for Arabic text.
        if (ingredient.matches(".*[\\u0600-\\u06FF].*")) {
            return input.contains(ingredient);
        }
        return false;
    }

    public static String normalize(String text) {
        if (text == null) return "";
        String value = text.toLowerCase(Locale.ROOT)
                .replace("،", " ")
                .replace(",", " ")
                .replace(".", " ")
                .replace(";", " ")
                .replace(":", " ")
                .replace("/", " ")
                .replace(" and ", " ")
                .replace(" with ", " ")
                .replace(" و", " ")
                .trim();
        value = Normalizer.normalize(value, Normalizer.Form.NFKD).replaceAll("\\p{M}", "");
        return value.replaceAll("\\s+", " ");
    }
}
