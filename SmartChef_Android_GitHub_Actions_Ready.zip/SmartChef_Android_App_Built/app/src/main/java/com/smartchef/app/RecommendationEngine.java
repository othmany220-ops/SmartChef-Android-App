package com.smartchef.app;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class RecommendationEngine {
    private static final Map<String, List<String>> SYNONYMS = new LinkedHashMap<>();

    static {
        SYNONYMS.put("egg", Arrays.asList("egg", "eggs", "بيض", "بيضة"));
        SYNONYMS.put("tomato", Arrays.asList("tomato", "tomatoes", "طماطم", "بندورة", "بندوره"));
        SYNONYMS.put("cheese", Arrays.asList("cheese", "جبن", "جبنة", "جبنه"));
        SYNONYMS.put("milk", Arrays.asList("milk", "حليب", "لبن"));
        SYNONYMS.put("chicken", Arrays.asList("chicken", "دجاج", "فراخ"));
        SYNONYMS.put("lettuce", Arrays.asList("lettuce", "خس"));
        SYNONYMS.put("cucumber", Arrays.asList("cucumber", "خيار"));
        SYNONYMS.put("lemon", Arrays.asList("lemon", "ليمون"));
        SYNONYMS.put("pasta", Arrays.asList("pasta", "macaroni", "معكرونة", "مكرونة", "باستا"));
        SYNONYMS.put("garlic", Arrays.asList("garlic", "ثوم"));
        SYNONYMS.put("carrot", Arrays.asList("carrot", "جزر"));
        SYNONYMS.put("potato", Arrays.asList("potato", "potatoes", "بطاطا", "بطاطس"));
        SYNONYMS.put("onion", Arrays.asList("onion", "onions", "بصل"));
        SYNONYMS.put("rice", Arrays.asList("rice", "أرز", "ارز", "رز"));
        SYNONYMS.put("bread", Arrays.asList("bread", "خبز"));
        SYNONYMS.put("tuna", Arrays.asList("tuna", "تونة", "تونه"));
        SYNONYMS.put("banana", Arrays.asList("banana", "bananas", "موز"));
        SYNONYMS.put("apple", Arrays.asList("apple", "apples", "تفاح"));
        SYNONYMS.put("yogurt", Arrays.asList("yogurt", "yoghurt", "زبادي", "لبن"));
        SYNONYMS.put("honey", Arrays.asList("honey", "عسل"));
        SYNONYMS.put("beef", Arrays.asList("beef", "meat", "لحم", "لحمة", "لحمه"));
        SYNONYMS.put("oil", Arrays.asList("oil", "زيت"));
        SYNONYMS.put("salt", Arrays.asList("salt", "ملح"));
        SYNONYMS.put("pepper", Arrays.asList("pepper", "فلفل"));
        SYNONYMS.put("water", Arrays.asList("water", "ماء", "مي"));
    }

    public static List<String> getIngredientCategories() {
        return new ArrayList<>(SYNONYMS.keySet());
    }

    public static List<RecommendationResult> recommend(String rawInput, List<Recipe> recipes) {
        List<String> userIngredients = extractIngredients(rawInput);
        List<RecommendationResult> results = new ArrayList<>();

        for (Recipe recipe : recipes) {
            List<String> matched = new ArrayList<>();
            for (String ingredient : recipe.ingredients) {
                if (userIngredients.contains(ingredient)) {
                    matched.add(ingredient);
                }
            }
            if (!matched.isEmpty()) {
                results.add(new RecommendationResult(recipe, matched));
            }
        }

        Collections.sort(results, new Comparator<RecommendationResult>() {
            @Override
            public int compare(RecommendationResult a, RecommendationResult b) {
                if (b.score != a.score) return b.score - a.score;
                return b.percentage - a.percentage;
            }
        });

        return results;
    }

    public static List<String> extractIngredients(String rawInput) {
        String input = normalize(rawInput);
        List<String> found = new ArrayList<>();

        for (Map.Entry<String, List<String>> entry : SYNONYMS.entrySet()) {
            for (String synonym : entry.getValue()) {
                String normalizedSynonym = normalize(synonym);
                if (containsIngredient(input, normalizedSynonym)) {
                    found.add(entry.getKey());
                    break;
                }
            }
        }
        return found;
    }

    private static boolean containsIngredient(String input, String ingredient) {
        if (input == null || input.trim().isEmpty()) return false;
        if (ingredient.length() <= 2) return input.contains(ingredient);
        return (" " + input + " ").contains(" " + ingredient + " ") || input.contains(ingredient);
    }

    public static String normalize(String text) {
        if (text == null) return "";
        String value = text.toLowerCase(Locale.ROOT)
                .replace("،", ",")
                .replace(" and ", " ")
                .replace(" with ", " ")
                .replace(" و", " ")
                .replace(",", " ")
                .replace(".", " ")
                .replace(";", " ")
                .replace(":", " ")
                .trim();
        value = Normalizer.normalize(value, Normalizer.Form.NFKD).replaceAll("\\p{M}", "");
        return value.replaceAll("\\s+", " ");
    }
}
