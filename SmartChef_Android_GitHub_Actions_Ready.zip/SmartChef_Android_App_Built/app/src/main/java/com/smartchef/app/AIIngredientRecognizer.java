package com.smartchef.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeler;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * AI ingredient recognition module.
 *
 * This module uses ML Kit on-device image labeling. The detected labels are mapped
 * to Smart Chef ingredient keys. If labels are too general, a small visual fallback
 * analyzes the dominant colors to produce a prototype prediction. A trained TFLite
 * model can replace this class later without changing the app workflow.
 */
public class AIIngredientRecognizer {
    public interface Callback {
        void onResult(AIIngredientResult result);
    }

    private static final Map<String, String> LABEL_TO_INGREDIENT = new HashMap<>();

    static {
        map("tomato", "tomato"); map("tomatoes", "tomato");
        map("egg", "egg"); map("eggs", "egg"); map("omelette", "egg");
        map("chicken", "chicken"); map("poultry", "chicken");
        map("beef", "beef"); map("meat", "beef"); map("steak", "beef"); map("lamb", "beef");
        map("rice", "rice"); map("grain", "rice");
        map("pasta", "pasta"); map("macaroni", "pasta"); map("noodle", "pasta"); map("spaghetti", "pasta");
        map("onion", "onion"); map("garlic", "garlic");
        map("potato", "potato"); map("carrot", "carrot"); map("cucumber", "cucumber");
        map("parsley", "parsley"); map("herb", "parsley");
        map("tuna", "tuna"); map("fish", "fish");
        map("yogurt", "yogurt"); map("milk", "milk"); map("dairy", "yogurt"); map("cheese", "cheese");
        map("lentil", "red_lentils"); map("lentils", "red_lentils");
        map("bread", "bread"); map("banana", "banana"); map("spinach", "spinach");
        map("zucchini", "zucchini"); map("pepper", "bell_pepper");
    }

    private static void map(String label, String key) { LABEL_TO_INGREDIENT.put(label.toLowerCase(Locale.ROOT), key); }

    public static void analyze(Context context, Bitmap bitmap, Callback callback) {
        if (bitmap == null) {
            callback.onResult(new AIIngredientResult("", "Unknown", "غير معروف", 0, "No image", ""));
            return;
        }
        InputImage image = InputImage.fromBitmap(bitmap, 0);
        ImageLabeler labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS);
        labeler.process(image)
                .addOnSuccessListener(labels -> callback.onResult(buildResultFromLabels(labels, bitmap)))
                .addOnFailureListener(e -> callback.onResult(fallbackFromImage(bitmap, "Visual fallback", e.getMessage())));
    }

    private static AIIngredientResult buildResultFromLabels(List<ImageLabel> labels, Bitmap bitmap) {
        StringBuilder raw = new StringBuilder();
        String bestKey = "";
        int bestConfidence = 0;
        for (ImageLabel label : labels) {
            String labelText = label.getText() == null ? "" : label.getText().toLowerCase(Locale.ROOT);
            int confidence = Math.round(label.getConfidence() * 100f);
            if (raw.length() > 0) raw.append(", ");
            raw.append(label.getText()).append(" ").append(confidence).append("%");
            for (Map.Entry<String, String> entry : LABEL_TO_INGREDIENT.entrySet()) {
                if (labelText.contains(entry.getKey()) && confidence > bestConfidence) {
                    bestKey = entry.getValue();
                    bestConfidence = confidence;
                }
            }
        }
        if (bestKey.isEmpty() || bestConfidence < 50) return fallbackFromImage(bitmap, "Visual fallback after ML labels", raw.toString());
        return createResult(bestKey, bestConfidence, "ML Kit Image Labeling", raw.toString());
    }

    private static AIIngredientResult fallbackFromImage(Bitmap bitmap, String method, String rawLabels) {
        Bitmap scaled = Bitmap.createScaledBitmap(bitmap, 32, 32, true);
        float hueSum = 0f, satSum = 0f, valSum = 0f;
        int count = 0;
        float[] hsv = new float[3];
        for (int y = 0; y < scaled.getHeight(); y++) {
            for (int x = 0; x < scaled.getWidth(); x++) {
                int color = scaled.getPixel(x, y);
                int r = Color.red(color), g = Color.green(color), b = Color.blue(color);
                if ((r > 235 && g > 235 && b > 235) || (r < 20 && g < 20 && b < 20)) continue;
                Color.RGBToHSV(r, g, b, hsv);
                hueSum += hsv[0]; satSum += hsv[1]; valSum += hsv[2]; count++;
            }
        }
        if (count == 0) return createResult("tomato", 45, method, rawLabels);
        float hue = hueSum / count, saturation = satSum / count, value = valSum / count;
        String key; int confidence = 55;
        if (hue < 20 || hue > 340) { key = saturation > 0.35f ? "tomato" : "beef"; confidence = 68; }
        else if (hue >= 20 && hue < 50) { key = value > 0.65f ? "carrot" : "onion"; confidence = 64; }
        else if (hue >= 50 && hue < 85) { key = saturation > 0.30f ? "cheese" : "rice"; confidence = 60; }
        else if (hue >= 85 && hue < 170) { key = saturation > 0.25f ? "parsley" : "cucumber"; confidence = 62; }
        else if (hue >= 170 && hue < 260) { key = "fish"; confidence = 50; }
        else { key = "onion"; confidence = 55; }
        return createResult(key, confidence, method, rawLabels);
    }

    private static AIIngredientResult createResult(String key, int confidence, String method, String rawLabels) {
        switch (key) {
            case "egg": return new AIIngredientResult(key, "Egg", "بيض", confidence, method, rawLabels);
            case "tomato": return new AIIngredientResult(key, "Tomato", "طماطم", confidence, method, rawLabels);
            case "cheese": return new AIIngredientResult(key, "Cheese", "جبن", confidence, method, rawLabels);
            case "chicken": return new AIIngredientResult(key, "Chicken", "دجاج", confidence, method, rawLabels);
            case "rice": return new AIIngredientResult(key, "Rice", "أرز", confidence, method, rawLabels);
            case "pasta": return new AIIngredientResult(key, "Macaroni", "معكرونة", confidence, method, rawLabels);
            case "onion": return new AIIngredientResult(key, "Onion", "بصل", confidence, method, rawLabels);
            case "garlic": return new AIIngredientResult(key, "Garlic", "ثوم", confidence, method, rawLabels);
            case "potato": return new AIIngredientResult(key, "Potato", "بطاطا", confidence, method, rawLabels);
            case "carrot": return new AIIngredientResult(key, "Carrot", "جزر", confidence, method, rawLabels);
            case "cucumber": return new AIIngredientResult(key, "Cucumber", "خيار", confidence, method, rawLabels);
            case "parsley": return new AIIngredientResult(key, "Parsley", "بقدونس", confidence, method, rawLabels);
            case "tuna": return new AIIngredientResult(key, "Tuna", "تونة", confidence, method, rawLabels);
            case "yogurt": return new AIIngredientResult(key, "Yogurt", "زبادي", confidence, method, rawLabels);
            case "red_lentils": return new AIIngredientResult(key, "Red Lentils", "عدس أحمر", confidence, method, rawLabels);
            case "beef": return new AIIngredientResult(key, "Meat", "لحم", confidence, method, rawLabels);
            case "milk": return new AIIngredientResult(key, "Milk", "حليب", confidence, method, rawLabels);
            case "fish": return new AIIngredientResult(key, "Fish", "سمك", confidence, method, rawLabels);
            case "bread": return new AIIngredientResult(key, "Bread", "خبز", confidence, method, rawLabels);
            case "banana": return new AIIngredientResult(key, "Banana", "موز", confidence, method, rawLabels);
            case "spinach": return new AIIngredientResult(key, "Spinach", "سبانخ", confidence, method, rawLabels);
            case "zucchini": return new AIIngredientResult(key, "Zucchini", "كوسا", confidence, method, rawLabels);
            case "bell_pepper": return new AIIngredientResult(key, "Bell Pepper", "فليفلة", confidence, method, rawLabels);
            default: return new AIIngredientResult("", "Unknown", "غير معروف", 0, method, rawLabels);
        }
    }
}
