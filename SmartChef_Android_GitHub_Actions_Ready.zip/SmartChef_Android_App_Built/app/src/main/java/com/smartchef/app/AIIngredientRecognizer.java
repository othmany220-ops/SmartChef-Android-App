package com.smartchef.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;

import java.util.Locale;

/**
 * Offline AI ingredient recognition prototype.
 *
 * This class provides an AI-style image recognition workflow without requiring
 * an internet connection or external cloud services. It analyzes the selected
 * image using visual features such as dominant color, brightness, saturation,
 * and simple food-color rules, then maps the result to one of the ingredient
 * classes used by Smart Chef.
 *
 * In a production version, this class can be replaced by a trained TensorFlow
 * Lite model. The app workflow will remain the same: image -> detected
 * ingredient -> confidence score -> add ingredient -> recommend recipes.
 */
public class AIIngredientRecognizer {
    public interface Callback {
        void onResult(AIIngredientResult result);
    }

    public static void analyze(Context context, Bitmap bitmap, Callback callback) {
        if (bitmap == null) {
            callback.onResult(new AIIngredientResult("", "Unknown", "غير معروف", 0, "No image", ""));
            return;
        }
        callback.onResult(analyzeVisualFeatures(bitmap));
    }

    private static AIIngredientResult analyzeVisualFeatures(Bitmap bitmap) {
        Bitmap scaled = Bitmap.createScaledBitmap(bitmap, 64, 64, true);
        float[] hsv = new float[3];
        float hueSum = 0f, satSum = 0f, valSum = 0f;
        int count = 0;
        int redCount = 0, orangeCount = 0, yellowCount = 0, greenCount = 0, whiteCount = 0, brownCount = 0, darkCount = 0;

        for (int y = 0; y < scaled.getHeight(); y++) {
            for (int x = 0; x < scaled.getWidth(); x++) {
                int color = scaled.getPixel(x, y);
                int r = Color.red(color), g = Color.green(color), b = Color.blue(color);

                // Ignore very bright background and very dark shadows.
                boolean isWhite = r > 225 && g > 225 && b > 215;
                boolean isDark = r < 35 && g < 35 && b < 35;
                if (isWhite) { whiteCount++; continue; }
                if (isDark) { darkCount++; continue; }

                Color.RGBToHSV(r, g, b, hsv);
                float h = hsv[0], s = hsv[1], v = hsv[2];
                hueSum += h; satSum += s; valSum += v; count++;

                if ((h < 18 || h > 345) && s > 0.25f) redCount++;
                else if (h >= 18 && h < 45 && s > 0.25f) orangeCount++;
                else if (h >= 45 && h < 75 && s > 0.18f) yellowCount++;
                else if (h >= 75 && h < 170 && s > 0.18f) greenCount++;
                else if (h >= 18 && h < 55 && s < 0.45f && v < 0.65f) brownCount++;
            }
        }

        if (count == 0) {
            return createResult("rice", 45, "Offline AI visual analysis", "Mostly plain/white image");
        }

        float hue = hueSum / count;
        float saturation = satSum / count;
        float value = valSum / count;
        int total = Math.max(1, count + whiteCount + darkCount);

        String key;
        int confidence;
        String reason = String.format(Locale.ROOT,
                "hue=%.1f saturation=%.2f brightness=%.2f red=%d orange=%d yellow=%d green=%d white=%d brown=%d",
                hue, saturation, value, redCount, orangeCount, yellowCount, greenCount, whiteCount, brownCount);

        // Heuristic rules trained manually on common ingredient appearances.
        if (redCount > total * 0.16 && greenCount < total * 0.18) {
            key = "tomato"; confidence = 72;
        } else if (orangeCount > total * 0.18) {
            key = "carrot"; confidence = 70;
        } else if (yellowCount > total * 0.16 && whiteCount > total * 0.08) {
            key = "cheese"; confidence = 66;
        } else if (greenCount > total * 0.20 && value > 0.35f) {
            key = "parsley"; confidence = 68;
        } else if (whiteCount > total * 0.28 && saturation < 0.28f) {
            key = "rice"; confidence = 62;
        } else if (brownCount > total * 0.08 || (hue >= 15 && hue < 50 && value < 0.55f)) {
            key = "meat"; confidence = 61;
        } else if (hue >= 45 && hue < 80 && saturation < 0.35f) {
            key = "pasta"; confidence = 59;
        } else if (hue >= 20 && hue < 60 && saturation < 0.25f) {
            key = "onion"; confidence = 58;
        } else if (hue >= 75 && hue < 150 && saturation < 0.25f) {
            key = "cucumber"; confidence = 56;
        } else {
            key = "tomato"; confidence = 50;
        }
        return createResult(key, confidence, "Offline AI visual analysis", reason);
    }

    private static AIIngredientResult createResult(String key, int confidence, String method, String rawLabels) {
        switch (key) {
            case "egg": return new AIIngredientResult(key, "Egg", "بيض", confidence, method, rawLabels);
            case "tomato": return new AIIngredientResult(key, "Tomato", "طماطم", confidence, method, rawLabels);
            case "cheese": return new AIIngredientResult(key, "Cheese", "جبن", confidence, method, rawLabels);
            case "chicken": return new AIIngredientResult(key, "Chicken", "دجاج", confidence, method, rawLabels);
            case "rice": return new AIIngredientResult(key, "Rice", "أرز", confidence, method, rawLabels);
            case "pasta": return new AIIngredientResult(key, "Macaroni", "معكرونة", confidence, method, rawLabels);
            case "onion": return new AIIngredientResult(key, "Onion", "بصل", confidence, method, rawLabels);
            case "garlic": return new AIIngredientResult(key, "Garlic", "ثوم", confidence, method, rawLabels);
            case "potato": return new AIIngredientResult(key, "Potato", "بطاطا", confidence, method, rawLabels);
            case "carrot": return new AIIngredientResult(key, "Carrot", "جزر", confidence, method, rawLabels);
            case "cucumber": return new AIIngredientResult(key, "Cucumber", "خيار", confidence, method, rawLabels);
            case "parsley": return new AIIngredientResult(key, "Parsley", "بقدونس", confidence, method, rawLabels);
            case "tuna": return new AIIngredientResult(key, "Tuna", "تونة", confidence, method, rawLabels);
            case "yogurt": return new AIIngredientResult(key, "Yogurt", "زبادي", confidence, method, rawLabels);
            case "red_lentils": return new AIIngredientResult(key, "Red Lentils", "عدس أحمر", confidence, method, rawLabels);
            case "meat": return new AIIngredientResult(key, "Meat", "لحم", confidence, method, rawLabels);
            case "milk": return new AIIngredientResult(key, "Milk", "حليب", confidence, method, rawLabels);
            case "fish": return new AIIngredientResult(key, "Fish", "سمك", confidence, method, rawLabels);
            case "bread": return new AIIngredientResult(key, "Bread", "خبز", confidence, method, rawLabels);
            case "banana": return new AIIngredientResult(key, "Banana", "موز", confidence, method, rawLabels);
            case "spinach": return new AIIngredientResult(key, "Spinach", "سبانخ", confidence, method, rawLabels);
            case "zucchini": return new AIIngredientResult(key, "Zucchini", "كوسا", confidence, method, rawLabels);
            case "bell_pepper": return new AIIngredientResult(key, "Bell Pepper", "فليفلة", confidence, method, rawLabels);
            default: return new AIIngredientResult("", "Unknown", "غير معروف", 0, method, rawLabels);
        }
    }
}
