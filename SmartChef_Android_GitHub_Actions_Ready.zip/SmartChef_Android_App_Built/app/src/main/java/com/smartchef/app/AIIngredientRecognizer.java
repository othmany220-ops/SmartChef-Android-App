package com.smartchef.app;

import android.content.Context;
import android.graphics.Bitmap;

import org.pytorch.IValue;
import org.pytorch.LiteModuleLoader;
import org.pytorch.Module;
import org.pytorch.Tensor;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Real on-device AI ingredient classifier.
 *
 * The model is a trained 16-class CNN exported as a PyTorch Mobile Lite model.
 * Images are resized to 96x96 RGB and normalized to [-1, 1], matching training.
 * Inference runs locally on the Android device and returns the predicted class
 * with a confidence score. Low-confidence predictions are not auto-added.
 */
public final class AIIngredientRecognizer {
    public interface Callback {
        void onResult(AIIngredientResult result);
    }

    private static final String MODEL_ASSET = "smartchef_ingredient_cnn_mobile.ptl";
    private static final int IMAGE_SIZE = 96;
    private static final Object MODEL_LOCK = new Object();
    private static Module module;

    // Order must exactly match the training labels.txt file.
    private static final String[] INGREDIENT_KEYS = {
            "rice", "onion", "potato", "parsley", "egg", "tuna", "garlic", "cheese",
            "carrot", "cucumber", "chicken", "yogurt", "tomato", "red_lentils", "beef", "pasta"
    };

    private AIIngredientRecognizer() { }

    public static void analyze(Context context, Bitmap bitmap, Callback callback) {
        if (bitmap == null) {
            callback.onResult(new AIIngredientResult("", "Unknown", "غير معروف", 0,
                    "CNN model", "No image was provided"));
            return;
        }

        new Thread(() -> {
            try {
                AIIngredientResult result = predict(context.getApplicationContext(), bitmap);
                callback.onResult(result);
            } catch (Exception e) {
                callback.onResult(new AIIngredientResult("", "Unknown", "غير معروف", 0,
                        "CNN model error", e.getMessage() == null ? e.toString() : e.getMessage()));
            }
        }).start();
    }

    private static AIIngredientResult predict(Context context, Bitmap source) throws IOException {
        Module localModule = getModule(context);
        Bitmap bitmap = Bitmap.createScaledBitmap(source, IMAGE_SIZE, IMAGE_SIZE, true);

        final int pixels = IMAGE_SIZE * IMAGE_SIZE;
        float[] input = new float[3 * pixels];
        int[] row = new int[IMAGE_SIZE];

        for (int y = 0; y < IMAGE_SIZE; y++) {
            bitmap.getPixels(row, 0, IMAGE_SIZE, 0, y, IMAGE_SIZE, 1);
            for (int x = 0; x < IMAGE_SIZE; x++) {
                int color = row[x];
                int index = y * IMAGE_SIZE + x;
                // Training normalization: (pixel / 255 - 0.5) / 0.5 == pixel / 127.5 - 1
                input[index] = (((color >> 16) & 0xFF) / 127.5f) - 1f;
                input[pixels + index] = (((color >> 8) & 0xFF) / 127.5f) - 1f;
                input[2 * pixels + index] = ((color & 0xFF) / 127.5f) - 1f;
            }
        }

        Tensor inputTensor = Tensor.fromBlob(input, new long[]{1, 3, IMAGE_SIZE, IMAGE_SIZE});
        Tensor outputTensor = localModule.forward(IValue.from(inputTensor)).toTensor();
        float[] logits = outputTensor.getDataAsFloatArray();
        if (logits.length != INGREDIENT_KEYS.length) {
            throw new IllegalStateException("Unexpected model output size: " + logits.length);
        }

        float[] probabilities = softmax(logits);
        int bestIndex = 0;
        for (int i = 1; i < probabilities.length; i++) {
            if (probabilities[i] > probabilities[bestIndex]) bestIndex = i;
        }

        int confidence = Math.round(probabilities[bestIndex] * 100f);
        String key = INGREDIENT_KEYS[bestIndex];
        return createResult(key, confidence, "Trained CNN / PyTorch Mobile Lite",
                "class_index=" + bestIndex + ", probability=" + probabilities[bestIndex]);
    }

    private static Module getModule(Context context) throws IOException {
        synchronized (MODEL_LOCK) {
            if (module == null) module = LiteModuleLoader.load(assetFilePath(context, MODEL_ASSET));
            return module;
        }
    }

    private static String assetFilePath(Context context, String assetName) throws IOException {
        File file = new File(context.getFilesDir(), assetName);
        if (file.exists() && file.length() > 0) return file.getAbsolutePath();
        try (InputStream inputStream = context.getAssets().open(assetName);
             FileOutputStream outputStream = new FileOutputStream(file)) {
            byte[] buffer = new byte[8192];
            int read;
            while ((read = inputStream.read(buffer)) != -1) outputStream.write(buffer, 0, read);
            outputStream.flush();
        }
        return file.getAbsolutePath();
    }

    private static float[] softmax(float[] logits) {
        float max = logits[0];
        for (float v : logits) if (v > max) max = v;
        float sum = 0f;
        float[] output = new float[logits.length];
        for (int i = 0; i < logits.length; i++) {
            output[i] = (float) Math.exp(logits[i] - max);
            sum += output[i];
        }
        for (int i = 0; i < output.length; i++) output[i] /= Math.max(sum, 1e-12f);
        return output;
    }

    private static AIIngredientResult createResult(String key, int confidence, String method, String raw) {
        switch (key) {
            case "rice": return new AIIngredientResult(key, "Basmati Rice", "أرز بسمتي", confidence, method, raw);
            case "onion": return new AIIngredientResult(key, "Onion", "بصل", confidence, method, raw);
            case "potato": return new AIIngredientResult(key, "Potato", "بطاطا", confidence, method, raw);
            case "parsley": return new AIIngredientResult(key, "Parsley", "بقدونس", confidence, method, raw);
            case "egg": return new AIIngredientResult(key, "Eggs", "بيض", confidence, method, raw);
            case "tuna": return new AIIngredientResult(key, "Tuna", "تونة", confidence, method, raw);
            case "garlic": return new AIIngredientResult(key, "Garlic", "ثوم", confidence, method, raw);
            case "cheese": return new AIIngredientResult(key, "Cheese", "جبن", confidence, method, raw);
            case "carrot": return new AIIngredientResult(key, "Carrot", "جزر", confidence, method, raw);
            case "cucumber": return new AIIngredientResult(key, "Cucumber", "خيار", confidence, method, raw);
            case "chicken": return new AIIngredientResult(key, "Chicken", "دجاج", confidence, method, raw);
            case "yogurt": return new AIIngredientResult(key, "Yogurt", "لبن / زبادي", confidence, method, raw);
            case "tomato": return new AIIngredientResult(key, "Tomato", "طماطم", confidence, method, raw);
            case "red_lentils": return new AIIngredientResult(key, "Red Lentils", "عدس أحمر", confidence, method, raw);
            case "beef": return new AIIngredientResult(key, "Meat", "لحم", confidence, method, raw);
            case "pasta": return new AIIngredientResult(key, "Pasta / Macaroni", "معكرونة", confidence, method, raw);
            default: return new AIIngredientResult("", "Unknown", "غير معروف", 0, method, raw);
        }
    }
}
