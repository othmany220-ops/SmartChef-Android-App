package com.smartchef.app;

import java.util.List;

public class RecommendationResult {
    public final Recipe recipe;
    public final List<String> matchedIngredients;
    public final int score;
    public final int percentage;

    public RecommendationResult(Recipe recipe, List<String> matchedIngredients) {
        this.recipe = recipe;
        this.matchedIngredients = matchedIngredients;
        this.score = matchedIngredients.size();
        this.percentage = recipe.ingredients.isEmpty() ? 0 : Math.round((score * 100f) / recipe.ingredients.size());
    }
}
