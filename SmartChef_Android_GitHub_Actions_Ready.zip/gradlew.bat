@echo off
REM SmartChef GitHub Actions build uses gradlew on Linux. This file is included for Android Studio compatibility.
