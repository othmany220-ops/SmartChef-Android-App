# Archive

This directory contains historical iterations and setup notes from earlier AI/camera experiments. They are retained for traceability and are not part of the evaluated V21 runtime.
