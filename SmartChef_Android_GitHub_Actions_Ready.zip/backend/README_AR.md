# SmartChef Verified OpenAI Vision Backend V20

هذه النسخة تستخدم **OpenAI Responses API** مع إدخال صور كاملة الدقة وStructured Outputs بصيغة JSON Schema.

المعمارية:

```text
Android App → Secure Backend → OpenAI Vision → Verification Pass → JSON → User Confirmation
```

## تحسينات الدقة

- تصوير الكاميرا بدقة كاملة بدل صورة Thumbnail صغيرة.
- إرسال الصورة حتى 2048px مع جودة JPEG 90%.
- استخدام مستوى تفاصيل `original` مع النماذج الداعمة.
- Structured Outputs لمنع JSON غير صالح.
- فحص ثانٍ مستقل عندما تكون النتيجة غير واضحة أو منخفضة الثقة.
- عند اختلاف الفحصين تُعرض النتيجة للمراجعة بدل اعتماد تخمين خاطئ.
- لا يضيف التطبيق أي مكوّن قبل تأكيد المستخدم.

## متغيرات البيئة

```text
OPENAI_API_KEY=ضع مفتاح OpenAI هنا
OPENAI_MODEL=gpt-5.5
OPENAI_FALLBACK_MODEL=gpt-5-mini
VISION_VERIFY=true
REQUEST_TIMEOUT_MS=90000
```

لا تضع `OPENAI_API_KEY` داخل تطبيق Android أو GitHub العام.

## التشغيل

```bash
cd backend
npm install
npm run check
npm start
```

اختبار الصحة:

```text
GET /health
```

تحليل صورة:

```text
POST /api/v1/vision/analyze
Content-Type: application/json
```

الجسم:

```json
{
  "imageBase64": "...",
  "mimeType": "image/jpeg"
}
```

## ربط التطبيق

أضف في GitHub Actions Secret:

```text
VISION_BACKEND_URL=https://your-backend.example.com
```

ثم أعد بناء APK.

## ملاحظة علمية

لا يمكن ضمان دقة 100% لأي نظام رؤية حاسوبية. هذه النسخة تقلل الأخطاء عبر جودة الصورة والتحقق المزدوج، لكن تبقى مراجعة المستخدم ضرورية خصوصًا للصور المظلمة أو المكونات المتشابهة أو الأطباق المطبوخة المختلطة.
