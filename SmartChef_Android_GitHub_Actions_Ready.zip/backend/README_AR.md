# SmartChef OpenAI Vision Backend

هذه النسخة تربط تطبيق Android بخادم آمن، ثم يستخدم الخادم **OpenAI Vision عبر Responses API** لتحليل صورة المكونات.

المعمارية:

```text
Android App → Secure Backend → OpenAI Vision → JSON → User Confirmation
```

## لماذا يوجد Backend؟

لا يجب وضع `OPENAI_API_KEY` داخل تطبيق Android أو داخل APK. المفتاح يبقى في الخادم فقط، بينما التطبيق يحتفظ فقط بعنوان الخادم.

## التشغيل المحلي

```bash
cd backend
npm install
export OPENAI_API_KEY="ضع_مفتاح_OpenAI_هنا"
export OPENAI_MODEL="gpt-4.1-mini"
npm start
```

اختبار الصحة:

```text
http://localhost:3000/health
```

النتيجة المتوقعة:

```json
{
  "ok": true,
  "service": "smartchef-openai-vision-backend",
  "aiConfigured": true,
  "model": "gpt-4.1-mini"
}
```

## النشر على Render أو Railway

1. اختر مجلد `backend` كـ Root Directory.
2. Build Command:

```bash
npm install
```

3. Start Command:

```bash
npm start
```

4. أضف Environment Variable:

```text
OPENAI_API_KEY=ضع_مفتاح_OpenAI_هنا
```

5. اختياريًا:

```text
OPENAI_MODEL=gpt-4.1-mini
```

## ربط التطبيق بالخادم

في GitHub Repository أضف Secret داخل Actions:

```text
Name: VISION_BACKEND_URL
Value: https://your-service.example.com
```

ثم أعد تشغيل GitHub Actions حتى يتم بناء APK بالرابط الجديد.

## نقطة مهمة

التطبيق لا يضيف نتيجة الذكاء الاصطناعي تلقائيًا. يعرض أفضل النتائج، ثم يطلب من المستخدم تأكيد المكوّن الصحيح.
