# SmartChef Vision Backend

هذا الخادم هو الطريقة الاحترافية لتشغيل التعرف على المكونات بدقة أعلى.
الفكرة:

Android App → Vision Backend → Gemini Vision → JSON → App

## لماذا Backend؟

لا نضع Gemini API Key داخل تطبيق Android، لأن أي مفتاح داخل APK يمكن استخراجه. المفتاح يبقى داخل الخادم فقط.

## طريقة التشغيل محليًا

```bash
cd backend
npm install
export GEMINI_API_KEY="ضع_مفتاح_Gemini_هنا"
npm start
```

اختبار سريع:

```text
http://localhost:3000/health
```

## النشر على Render أو Railway

1. ارفع مجلد `backend` إلى GitHub أو داخل نفس المستودع.
2. أنشئ Web Service جديد.
3. Root Directory = `backend`.
4. Start Command = `npm start`.
5. أضف Environment Variable:

```text
GEMINI_API_KEY=ضع_مفتاح_Gemini_هنا
```

6. بعد النشر سيظهر لك رابط مثل:

```text
https://smartchef-vision-backend.onrender.com
```

## ربط التطبيق بالـ Backend

في مستودع تطبيق Android على GitHub افتح:

```text
Settings → Secrets and variables → Actions → New repository secret
```

أضف:

```text
Name: VISION_BACKEND_URL
Value: https://smartchef-vision-backend.onrender.com
```

ثم شغّل GitHub Actions من جديد.

## ملاحظة مهمة

إذا لم تضف `VISION_BACKEND_URL`، التطبيق لن يعطي تخمينًا خاطئًا من النموذج المحلي؛ سيطلب اختيار المكوّن يدويًا.
