import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { pathToFileURL } from 'node:url';
import {
  SUPPORTED_KEYS,
  clampNumber,
  createRequestId,
  extractOutputText,
  isLikelyBase64,
  reconcileAnalyses,
  safeError,
  sanitizeBase64,
  sanitizeCandidates,
  sanitizeMimeType,
  shouldVerify
} from './vision-core.js';

const app = express();
const PORT = Number(process.env.PORT || 3000);
const OPENAI_API_KEY = String(process.env.OPENAI_API_KEY || '').trim();
const OPENAI_MODEL = String(process.env.OPENAI_MODEL || 'gpt-5.5').trim();
const REQUEST_TIMEOUT_MS = clampNumber(process.env.REQUEST_TIMEOUT_MS, 15000, 120000, 90000);
const VERIFY_RESULTS = String(process.env.VISION_VERIFY ?? 'true').toLowerCase() !== 'false';
const MAX_BASE64_CHARS = clampNumber(process.env.MAX_BASE64_CHARS, 100000, 16000000, 12000000);

const responseSchema = {
  type: 'object',
  properties: {
    food_present: { type: 'boolean' },
    image_quality: { type: 'string', enum: ['good', 'usable', 'poor'] },
    candidates: {
      type: 'array', minItems: 0, maxItems: 3,
      items: {
        type: 'object',
        properties: {
          key: { type: 'string', enum: SUPPORTED_KEYS },
          certainty: { type: 'string', enum: ['high', 'medium', 'low'] },
          visual_reason: { type: 'string', minLength: 1, maxLength: 240 }
        },
        required: ['key', 'certainty', 'visual_reason'],
        additionalProperties: false
      }
    },
    needs_review: { type: 'boolean' },
    overall_reason: { type: 'string', minLength: 1, maxLength: 320 }
  },
  required: ['food_present', 'image_quality', 'candidates', 'needs_review', 'overall_reason'],
  additionalProperties: false
};

app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(helmet({ crossOriginResourcePolicy: false }));
app.use(express.json({ limit: '13mb', strict: true }));
app.use(rateLimit({
  windowMs: 60_000,
  max: 15,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests. Please try again shortly.' }
}));

app.get('/', (_req, res) => res.json({
  ok: true,
  service: 'SmartChef OpenAI Vision Backend',
  endpoint: '/api/v1/vision/analyze',
  health: '/health',
  verification: VERIFY_RESULTS
}));

app.get('/health', (_req, res) => res.json({
  ok: true,
  service: 'smartchef-openai-vision-backend',
  aiConfigured: Boolean(OPENAI_API_KEY),
  model: OPENAI_MODEL,
  verification: VERIFY_RESULTS
}));

app.post(['/api/v1/vision/analyze', '/analyze-ingredient'], async (req, res) => {
  const requestId = createRequestId();
  try {
    if (!OPENAI_API_KEY) return res.status(503).json({ error: 'OPENAI_API_KEY is not configured.', requestId });

    const imageBase64 = sanitizeBase64(req.body?.imageBase64);
    const mimeType = sanitizeMimeType(req.body?.mimeType);
    if (!imageBase64 || imageBase64.length < 100) return res.status(400).json({ error: 'imageBase64 is missing or invalid.', requestId });
    if (imageBase64.length > MAX_BASE64_CHARS) return res.status(413).json({ error: 'Image is too large.', requestId });
    if (!isLikelyBase64(imageBase64)) return res.status(400).json({ error: 'Image data is not valid Base64.', requestId });

    const first = await callOpenAI(imageBase64, mimeType, buildPrimaryInstruction());
    let finalResult = first;
    let verificationUsed = false;
    if (VERIFY_RESULTS && shouldVerify(first)) {
      verificationUsed = true;
      const second = await callOpenAI(imageBase64, mimeType, buildVerificationInstruction());
      finalResult = reconcileAnalyses(first, second);
    }

    const candidates = sanitizeCandidates(finalResult.candidates);
    const top = candidates[0];
    const reliable = Boolean(
      finalResult.food_present && finalResult.image_quality === 'good' &&
      top && top.key !== 'unknown' && top.certainty === 'high' && !finalResult.needs_review
    );

    return res.json({
      success: true,
      requestId,
      method: `OpenAI Vision secure backend (${OPENAI_MODEL})${verificationUsed ? ' + independent verification' : ''}`,
      food_present: Boolean(finalResult.food_present),
      image_quality: finalResult.image_quality,
      candidates,
      visual_reason: String(finalResult.overall_reason || '').trim(),
      needs_review: !reliable,
      reliable
    });
  } catch (error) {
    const timedOut = error?.name === 'AbortError';
    console.error(`[${requestId}] Vision error:`, safeError(error));
    return res.status(timedOut ? 504 : 500).json({
      error: timedOut ? 'OpenAI request timed out.' : 'Backend analysis failed.',
      requestId
    });
  }
});

app.use((error, _req, res, _next) => {
  const status = error?.type === 'entity.too.large' ? 413 : 400;
  res.status(status).json({ error: status === 413 ? 'Request body is too large.' : 'Invalid request body.' });
});

async function callOpenAI(imageBase64, mimeType, instruction) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    const response = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${OPENAI_API_KEY}` },
      body: JSON.stringify({
        model: OPENAI_MODEL,
        store: false,
        instructions: 'You are a conservative visual food-ingredient recognizer. Accuracy is more important than coverage. Never guess.',
        input: [{
          role: 'user',
          content: [
            { type: 'input_text', text: instruction },
            { type: 'input_image', image_url: `data:${mimeType};base64,${imageBase64}`, detail: 'high' }
          ]
        }],
        max_output_tokens: 500,
        text: { format: { type: 'json_schema', name: 'smartchef_ingredient_analysis', strict: true, schema: responseSchema } }
      }),
      signal: controller.signal
    });

    const raw = await response.text();
    if (!response.ok) {
      const error = new Error(`OpenAI HTTP ${response.status}`);
      error.status = response.status;
      error.body = raw.slice(0, 800);
      throw error;
    }
    const data = JSON.parse(raw);
    const outputText = extractOutputText(data);
    if (!outputText) throw new Error('OpenAI response did not contain structured output text.');
    return JSON.parse(outputText);
  } finally {
    clearTimeout(timeout);
  }
}

function buildPrimaryInstruction() {
  return [
    'Identify the single main raw cooking ingredient clearly visible in the photo.',
    `Allowed keys: ${SUPPORTED_KEYS.join(', ')}.`,
    'Use one ingredient per photo for best accuracy. If multiple ingredients, packaging, a cooked dish, blur, darkness, or obstruction prevents a reliable decision, return unknown and set needs_review true.',
    'Do not infer hidden ingredients or identify a recipe.',
    'Use high certainty only when the visual identity is unmistakable; otherwise use medium or low.',
    'Return at most three ranked alternatives.'
  ].join(' ');
}

function buildVerificationInstruction() {
  return [
    'Re-check the image independently from scratch as a strict verifier.',
    `Allowed keys: ${SUPPORTED_KEYS.join(', ')}.`,
    'Do not trust the first pass. Return unknown if the object is unclear.',
    'Pay special attention to cucumber versus zucchini, tomato versus meat, egg versus cheese, pasta versus elongated vegetables, onion versus garlic, and rice versus small grains.',
    'Use high certainty only when unmistakable and set needs_review true whenever meaningful doubt remains.'
  ].join(' ');
}

export { app };

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  app.listen(PORT, () => console.log(`SmartChef OpenAI Vision Backend running on port ${PORT}`));
}
