import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';

const app = express();
const PORT = Number(process.env.PORT || 3000);
const OPENAI_API_KEY = String(process.env.OPENAI_API_KEY || '').trim();
const OPENAI_MODEL = String(process.env.OPENAI_MODEL || 'gpt-5.5').trim();
const OPENAI_FALLBACK_MODEL = String(process.env.OPENAI_FALLBACK_MODEL || 'gpt-5-mini').trim();
const REQUEST_TIMEOUT_MS = clampNumber(process.env.REQUEST_TIMEOUT_MS, 15000, 120000, 90000);
const VERIFY_RESULTS = String(process.env.VISION_VERIFY ?? 'true').toLowerCase() !== 'false';
const MAX_BASE64_CHARS = clampNumber(process.env.MAX_BASE64_CHARS, 100000, 16000000, 12000000);

const SUPPORTED_KEYS = Object.freeze([
  'rice', 'onion', 'potato', 'parsley', 'egg', 'tuna', 'garlic', 'cheese',
  'carrot', 'cucumber', 'chicken', 'yogurt', 'tomato', 'red_lentils',
  'beef', 'pasta', 'spices', 'milk', 'eggplant', 'bread', 'molokhia',
  'sumac', 'fish', 'chickpeas', 'tahini', 'spinach', 'zucchini', 'peas',
  'beans', 'lemon', 'pepper', 'banana', 'apple', 'orange', 'lettuce',
  'cabbage', 'corn', 'mushroom', 'cauliflower', 'broccoli', 'avocado',
  'unknown'
]);

const responseSchema = {
  type: 'object',
  properties: {
    food_present: { type: 'boolean' },
    image_quality: { type: 'string', enum: ['good', 'usable', 'poor'] },
    candidates: {
      type: 'array',
      minItems: 0,
      maxItems: 3,
      items: {
        type: 'object',
        properties: {
          key: { type: 'string', enum: SUPPORTED_KEYS },
          confidence: { type: 'integer', minimum: 0, maximum: 100 },
          visual_reason: { type: 'string', minLength: 1, maxLength: 240 }
        },
        required: ['key', 'confidence', 'visual_reason'],
        additionalProperties: false
      }
    },
    needs_review: { type: 'boolean' },
    overall_reason: { type: 'string', minLength: 1, maxLength: 320 }
  },
  required: ['food_present', 'image_quality', 'candidates', 'needs_review', 'overall_reason'],
  additionalProperties: false
};

app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(helmet({ crossOriginResourcePolicy: false }));
app.use(express.json({ limit: '13mb', strict: true }));
app.use(rateLimit({
  windowMs: 60_000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests. Please try again shortly.' }
}));

app.get('/', (_req, res) => {
  res.json({
    ok: true,
    service: 'SmartChef OpenAI Vision Backend',
    endpoint: '/api/v1/vision/analyze',
    health: '/health',
    verification: VERIFY_RESULTS
  });
});

app.get('/health', (_req, res) => {
  res.json({
    ok: true,
    service: 'smartchef-openai-vision-backend',
    aiConfigured: Boolean(OPENAI_API_KEY),
    model: OPENAI_MODEL,
    fallbackModel: OPENAI_FALLBACK_MODEL,
    verification: VERIFY_RESULTS
  });
});

app.post(['/api/v1/vision/analyze', '/analyze-ingredient'], async (req, res) => {
  const requestId = createRequestId();
  try {
    if (!OPENAI_API_KEY) {
      return res.status(503).json({
        error: 'OPENAI_API_KEY is not configured on the backend server.',
        requestId
      });
    }

    const imageBase64 = sanitizeBase64(req.body?.imageBase64);
    const mimeType = sanitizeMimeType(req.body?.mimeType);

    if (!imageBase64 || imageBase64.length < 100) {
      return res.status(400).json({ error: 'imageBase64 is missing or invalid.', requestId });
    }
    if (imageBase64.length > MAX_BASE64_CHARS) {
      return res.status(413).json({ error: 'Image is too large.', requestId });
    }
    if (!isLikelyBase64(imageBase64)) {
      return res.status(400).json({ error: 'Image data is not valid Base64.', requestId });
    }

    const first = await analyzeWithFallback({
      imageBase64,
      mimeType,
      instruction: buildPrimaryInstruction(),
      requestId
    });

    let finalResult = first.result;
    let verificationUsed = false;

    if (VERIFY_RESULTS && shouldVerify(first.result)) {
      verificationUsed = true;
      const second = await analyzeWithFallback({
        imageBase64,
        mimeType,
        instruction: buildVerificationInstruction(),
        requestId
      });
      finalResult = reconcileAnalyses(first.result, second.result);
    }

    const candidates = sanitizeCandidates(finalResult.candidates);
    const top = candidates[0];
    const reliable = Boolean(
      finalResult.food_present &&
      finalResult.image_quality !== 'poor' &&
      top &&
      top.key !== 'unknown' &&
      top.confidence >= 88 &&
      (!candidates[1] || top.confidence - candidates[1].confidence >= 15) &&
      !finalResult.needs_review
    );

    return res.json({
      success: true,
      requestId,
      method: `OpenAI Vision via secure backend (${first.model})${verificationUsed ? ' + verification pass' : ''}`,
      food_present: Boolean(finalResult.food_present),
      image_quality: finalResult.image_quality,
      candidates,
      visual_reason: String(finalResult.overall_reason || '').trim(),
      needs_review: !reliable,
      reliable
    });
  } catch (error) {
    const timedOut = error?.name === 'AbortError';
    const status = timedOut ? 504 : 500;
    console.error(`[${requestId}] Vision error:`, safeError(error));
    return res.status(status).json({
      error: timedOut ? 'OpenAI request timed out.' : 'Backend analysis failed.',
      requestId
    });
  }
});

app.use((error, _req, res, _next) => {
  const status = error?.type === 'entity.too.large' ? 413 : 400;
  res.status(status).json({ error: status === 413 ? 'Request body is too large.' : 'Invalid request body.' });
});

async function analyzeWithFallback({ imageBase64, mimeType, instruction, requestId }) {
  try {
    return { model: OPENAI_MODEL, result: await callOpenAI(OPENAI_MODEL, imageBase64, mimeType, instruction) };
  } catch (error) {
    if (!OPENAI_FALLBACK_MODEL || OPENAI_FALLBACK_MODEL === OPENAI_MODEL || !isModelAvailabilityError(error)) {
      throw error;
    }
    console.warn(`[${requestId}] Primary model unavailable; retrying with fallback model.`);
    return {
      model: OPENAI_FALLBACK_MODEL,
      result: await callOpenAI(OPENAI_FALLBACK_MODEL, imageBase64, mimeType, instruction)
    };
  }
}

async function callOpenAI(model, imageBase64, mimeType, instruction) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    const response = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model,
        input: [
          {
            role: 'system',
            content: 'You are a conservative visual food-ingredient recognizer. Accuracy is more important than coverage. Never guess.'
          },
          {
            role: 'user',
            content: [
              { type: 'input_text', text: instruction },
              {
                type: 'input_image',
                image_url: `data:${mimeType};base64,${imageBase64}`,
                detail: model.startsWith('gpt-5.5') || model.startsWith('gpt-5.4') ? 'original' : 'high'
              }
            ]
          }
        ],
        max_output_tokens: 700,
        text: {
          format: {
            type: 'json_schema',
            name: 'smartchef_ingredient_analysis',
            strict: true,
            schema: responseSchema
          }
        }
      }),
      signal: controller.signal
    });

    const raw = await response.text();
    if (!response.ok) {
      const error = new Error(`OpenAI HTTP ${response.status}`);
      error.status = response.status;
      error.body = raw.slice(0, 800);
      throw error;
    }

    const data = JSON.parse(raw);
    const outputText = extractOutputText(data);
    if (!outputText) throw new Error('OpenAI response did not contain structured output text.');
    return JSON.parse(outputText);
  } finally {
    clearTimeout(timeout);
  }
}

function buildPrimaryInstruction() {
  return [
    'Identify only cooking ingredients that are visibly present in the photo.',
    `Allowed keys: ${SUPPORTED_KEYS.join(', ')}.`,
    'Do not identify a recipe or infer ingredients hidden inside a cooked dish.',
    'Use unknown when the object is not a supported ingredient or is too unclear.',
    'If packaging is visible, use the visible food itself rather than text on the package.',
    'For similar-looking foods, compare shape, surface texture, color distribution, and context.',
    'Confidence is a conservative visual certainty score. Use 90+ only when the item is unmistakable.',
    'Mark needs_review true whenever lighting, blur, occlusion, mixed dishes, or ambiguity could cause an error.',
    'Return up to three ranked candidates.'
  ].join(' ');
}

function buildVerificationInstruction() {
  return [
    'Independently re-check the image from scratch as a strict verifier.',
    `Allowed keys: ${SUPPORTED_KEYS.join(', ')}.`,
    'Do not assume the first analysis was correct.',
    'Reject visually weak or ambiguous guesses and return unknown when necessary.',
    'Pay special attention to common confusions such as cucumber versus zucchini, tomato versus red meat, egg versus cheese, pasta versus elongated vegetables, and onion versus garlic.',
    'Confidence must be conservative. Use 90+ only for an unmistakable ingredient.',
    'Return up to three ranked candidates and set needs_review true if any meaningful doubt remains.'
  ].join(' ');
}

function shouldVerify(result) {
  const candidates = sanitizeCandidates(result?.candidates);
  const top = candidates[0];
  const second = candidates[1];
  return !result?.food_present ||
    result?.image_quality !== 'good' ||
    result?.needs_review ||
    !top ||
    top.key === 'unknown' ||
    top.confidence < 92 ||
    (second && top.confidence - second.confidence < 20);
}

function reconcileAnalyses(first, second) {
  const a = sanitizeCandidates(first?.candidates);
  const b = sanitizeCandidates(second?.candidates);
  const topA = a[0];
  const topB = b[0];

  if (!first?.food_present && !second?.food_present) {
    return unknownResult('No supported food ingredient was clearly visible in either verification pass.');
  }

  if (topA && topB && topA.key === topB.key && topA.key !== 'unknown') {
    const confidence = Math.min(topA.confidence, topB.confidence);
    const merged = [{
      key: topA.key,
      confidence,
      visual_reason: mergeReasons(topA.visual_reason, topB.visual_reason)
    }];

    const alternates = [...a.slice(1), ...b.slice(1)]
      .filter((item) => item.key !== topA.key && item.key !== 'unknown')
      .sort((x, y) => y.confidence - x.confidence);

    for (const item of alternates) {
      if (!merged.some((existing) => existing.key === item.key)) merged.push(item);
      if (merged.length === 3) break;
    }

    return {
      food_present: true,
      image_quality: worstQuality(first?.image_quality, second?.image_quality),
      candidates: merged,
      needs_review: Boolean(first?.needs_review || second?.needs_review || confidence < 88),
      overall_reason: mergeReasons(first?.overall_reason, second?.overall_reason)
    };
  }

  const combined = mergeDisagreeingCandidates(a, b);
  return {
    food_present: Boolean(first?.food_present || second?.food_present),
    image_quality: worstQuality(first?.image_quality, second?.image_quality),
    candidates: combined.length ? combined : [{ key: 'unknown', confidence: 0, visual_reason: 'Verification passes did not agree.' }],
    needs_review: true,
    overall_reason: 'Two independent verification passes did not agree, so the result must be confirmed manually.'
  };
}

function mergeDisagreeingCandidates(a, b) {
  const scores = new Map();
  for (const [source, multiplier] of [[a, 0.45], [b, 0.45]]) {
    for (const item of source) {
      if (item.key === 'unknown') continue;
      const current = scores.get(item.key) || { key: item.key, confidence: 0, visual_reason: item.visual_reason };
      current.confidence = Math.max(current.confidence, Math.round(item.confidence * multiplier));
      current.visual_reason = mergeReasons(current.visual_reason, item.visual_reason);
      scores.set(item.key, current);
    }
  }
  return [...scores.values()].sort((x, y) => y.confidence - x.confidence).slice(0, 3);
}

function sanitizeCandidates(items) {
  const allowed = new Set(SUPPORTED_KEYS);
  const used = new Set();
  const output = [];
  for (const item of Array.isArray(items) ? items : []) {
    const key = normalizeKey(item?.key);
    if (!key || !allowed.has(key) || used.has(key)) continue;
    const confidence = Math.max(0, Math.min(100, Math.round(Number(item?.confidence || 0))));
    used.add(key);
    output.push({
      key,
      confidence,
      visual_reason: String(item?.visual_reason || '').trim().slice(0, 240)
    });
  }
  output.sort((x, y) => y.confidence - x.confidence);
  return output.slice(0, 3);
}

function unknownResult(reason) {
  return {
    food_present: false,
    image_quality: 'poor',
    candidates: [{ key: 'unknown', confidence: 0, visual_reason: reason }],
    needs_review: true,
    overall_reason: reason
  };
}

function sanitizeBase64(value) {
  let text = String(value || '').trim();
  const comma = text.indexOf(',');
  if (text.startsWith('data:') && comma >= 0) text = text.slice(comma + 1);
  return text.replace(/\s+/g, '');
}

function sanitizeMimeType(value) {
  const mime = String(value || 'image/jpeg').toLowerCase().trim();
  return ['image/jpeg', 'image/png', 'image/webp'].includes(mime) ? mime : 'image/jpeg';
}

function isLikelyBase64(value) {
  return value.length % 4 === 0 && /^[A-Za-z0-9+/]+={0,2}$/.test(value);
}

function extractOutputText(data) {
  if (typeof data?.output_text === 'string' && data.output_text.trim()) return data.output_text.trim();
  const parts = [];
  for (const item of data?.output || []) {
    for (const content of item?.content || []) {
      if ((content?.type === 'output_text' || content?.type === 'text') && typeof content?.text === 'string') {
        parts.push(content.text);
      }
    }
  }
  return parts.join('\n').trim();
}

function normalizeKey(value) {
  const key = String(value || '').trim().toLowerCase().replace(/[\s-]+/g, '_');
  const aliases = {
    basmati_rice: 'rice', eggs: 'egg', meat: 'beef', lamb: 'beef',
    macaroni: 'pasta', spaghetti: 'pasta', red_lentil: 'red_lentils',
    lentils: 'red_lentils', bell_pepper: 'pepper', capsicum: 'pepper',
    none: 'unknown', unsupported: 'unknown'
  };
  return aliases[key] || key;
}

function worstQuality(a, b) {
  const rank = { good: 0, usable: 1, poor: 2 };
  return rank[a] >= rank[b] ? (a || 'poor') : (b || 'poor');
}

function mergeReasons(a, b) {
  const left = String(a || '').trim();
  const right = String(b || '').trim();
  if (!left) return right;
  if (!right || left === right) return left;
  return `${left} ${right}`.slice(0, 320);
}

function isModelAvailabilityError(error) {
  return [400, 404].includes(Number(error?.status || 0));
}

function clampNumber(value, min, max, fallback) {
  const number = Number(value);
  if (!Number.isFinite(number)) return fallback;
  return Math.max(min, Math.min(max, number));
}

function createRequestId() {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

function safeError(error) {
  return {
    name: error?.name,
    message: error?.message,
    status: error?.status,
    body: error?.body
  };
}

app.listen(PORT, () => {
  console.log(`SmartChef OpenAI Vision Backend running on port ${PORT}`);
});
