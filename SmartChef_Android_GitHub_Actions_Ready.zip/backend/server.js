import express from 'express';
import cors from 'cors';

const app = express();
const PORT = process.env.PORT || 3000;
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || '';
const MODEL = process.env.GEMINI_MODEL || 'gemini-2.0-flash';
const DEFAULT_SUPPORTED_KEYS = 'rice, onion, potato, parsley, egg, tuna, garlic, cheese, carrot, cucumber, chicken, yogurt, tomato, red_lentils, beef, pasta, spices, milk, eggplant, bread, molokhia, sumac, fish, chickpeas, tahini, spinach, zucchini, peas, beans';

app.use(cors());
app.use(express.json({ limit: '12mb' }));

app.get('/', (req, res) => {
  res.json({ ok: true, service: 'SmartChef Vision Backend', endpoint: '/analyze-ingredient' });
});

app.get('/health', (req, res) => {
  res.json({ ok: true, hasGeminiKey: Boolean(GEMINI_API_KEY) });
});

app.post('/analyze-ingredient', async (req, res) => {
  try {
    if (!GEMINI_API_KEY) {
      return res.status(500).json({ error: 'GEMINI_API_KEY is not configured on the backend server.' });
    }

    const imageBase64 = String(req.body?.imageBase64 || '');
    const mimeType = String(req.body?.mimeType || 'image/jpeg');
    const supportedKeys = String(req.body?.supportedKeys || DEFAULT_SUPPORTED_KEYS);

    if (!imageBase64 || imageBase64.length < 100) {
      return res.status(400).json({ error: 'imageBase64 is missing or invalid.' });
    }

    const prompt = [
      'You are the Smart Chef professional visual ingredient recognition module.',
      'Analyze the image and identify visible cooking ingredients.',
      `Choose candidates ONLY from this supported key list: ${supportedKeys}.`,
      'Return the most likely visible ingredient first. If several supported ingredients are visible, rank them.',
      'Do not guess hidden ingredients, do not identify a complete recipe, and do not choose unsupported objects.',
      'Return exactly three ranked candidates when possible.',
      'Confidence must be an integer from 0 to 100 and must be conservative.',
      'If none of the supported ingredients is clearly visible, return key unknown with low confidence.',
      'Return JSON only in this exact structure:',
      '{"candidates":[{"key":"cucumber","confidence":96},{"key":"parsley","confidence":3},{"key":"tomato","confidence":1}],"visual_reason":"short visual reason"}'
    ].join(' ');

    const body = {
      contents: [
        {
          parts: [
            { text: prompt },
            { inline_data: { mime_type: mimeType, data: imageBase64 } }
          ]
        }
      ],
      generationConfig: {
        temperature: 0.1,
        response_mime_type: 'application/json'
      }
    };

    const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent?key=${encodeURIComponent(GEMINI_API_KEY)}`;
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });

    const text = await response.text();
    if (!response.ok) {
      return res.status(response.status).json({ error: 'Gemini request failed', details: shorten(text) });
    }

    const gemini = JSON.parse(text);
    const returnedText = gemini?.candidates?.[0]?.content?.parts?.[0]?.text || '';
    const clean = stripCodeFence(returnedText);
    const parsed = JSON.parse(clean);
    const candidates = sanitizeCandidates(parsed.candidates || []);

    return res.json({
      method: `Gemini Vision via Backend (${MODEL})`,
      candidates,
      visual_reason: String(parsed.visual_reason || parsed.visualReason || '')
    });
  } catch (error) {
    return res.status(500).json({ error: 'Backend analysis failed', details: error?.message || String(error) });
  }
});

function stripCodeFence(value) {
  let text = String(value || '').trim();
  if (text.startsWith('```')) {
    const firstNewLine = text.indexOf('\n');
    const lastFence = text.lastIndexOf('```');
    if (firstNewLine >= 0 && lastFence > firstNewLine) {
      text = text.slice(firstNewLine + 1, lastFence).trim();
    }
  }
  return text;
}

function sanitizeCandidates(items) {
  const used = new Set();
  const output = [];
  for (const item of items) {
    const key = normalizeKey(item?.key);
    let confidence = Number(item?.confidence || 0);
    if (confidence >= 0 && confidence <= 1) confidence *= 100;
    confidence = Math.max(0, Math.min(100, Math.round(confidence)));
    if (!key || used.has(key)) continue;
    used.add(key);
    output.push({ key, confidence });
  }
  output.sort((a, b) => b.confidence - a.confidence);
  return output.slice(0, 3);
}

function normalizeKey(value) {
  let key = String(value || '').trim().toLowerCase().replace(/[\s-]+/g, '_');
  if (key === 'basmati_rice') key = 'rice';
  if (key === 'eggs') key = 'egg';
  if (['meat', 'lamb'].includes(key)) key = 'beef';
  if (['macaroni', 'spaghetti'].includes(key)) key = 'pasta';
  if (['red_lentil', 'lentils'].includes(key)) key = 'red_lentils';
  if (['none', 'unsupported'].includes(key)) key = 'unknown';
  return key;
}

function shorten(value) {
  const text = String(value || '');
  return text.length <= 500 ? text : text.slice(0, 500) + '...';
}

app.listen(PORT, () => {
  console.log(`SmartChef Vision Backend running on port ${PORT}`);
});
