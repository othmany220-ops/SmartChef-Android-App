import express from 'express';
import cors from 'cors';

const app = express();
const PORT = Number(process.env.PORT || 3000);
const OPENAI_API_KEY = String(process.env.OPENAI_API_KEY || '').trim();
const OPENAI_MODEL = String(process.env.OPENAI_MODEL || 'gpt-4.1-mini').trim();
const REQUEST_TIMEOUT_MS = Number(process.env.REQUEST_TIMEOUT_MS || 65000);
const DEFAULT_SUPPORTED_KEYS = 'rice, onion, potato, parsley, egg, tuna, garlic, cheese, carrot, cucumber, chicken, yogurt, tomato, red_lentils, beef, pasta, spices, milk, eggplant, bread, molokhia, sumac, fish, chickpeas, tahini, spinach, zucchini, peas, beans';

app.disable('x-powered-by');
app.use(cors());
app.use(express.json({ limit: '14mb' }));

app.get('/', (_req, res) => {
  res.json({
    ok: true,
    service: 'SmartChef OpenAI Vision Backend',
    endpoint: '/analyze-ingredient',
    health: '/health'
  });
});

app.get('/health', (_req, res) => {
  res.json({
    ok: true,
    service: 'smartchef-openai-vision-backend',
    aiConfigured: Boolean(OPENAI_API_KEY),
    model: OPENAI_MODEL
  });
});

app.post('/analyze-ingredient', async (req, res) => {
  try {
    if (!OPENAI_API_KEY) {
      return res.status(503).json({
        error: 'OPENAI_API_KEY is not configured on the backend server.'
      });
    }

    const imageBase64 = sanitizeBase64(req.body?.imageBase64);
    const mimeType = sanitizeMimeType(req.body?.mimeType);
    const supportedKeys = sanitizeSupportedKeys(req.body?.supportedKeys);

    if (!imageBase64 || imageBase64.length < 100) {
      return res.status(400).json({ error: 'imageBase64 is missing or invalid.' });
    }

    const prompt = buildPrompt(supportedKeys);
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

    let response;
    try {
      response = await fetch('https://api.openai.com/v1/responses', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${OPENAI_API_KEY}`
        },
        body: JSON.stringify({
          model: OPENAI_MODEL,
          input: [
            {
              role: 'user',
              content: [
                { type: 'input_text', text: prompt },
                {
                  type: 'input_image',
                  image_url: `data:${mimeType};base64,${imageBase64}`,
                  detail: 'high'
                }
              ]
            }
          ],
          temperature: 0.1,
          max_output_tokens: 700
        }),
        signal: controller.signal
      });
    } finally {
      clearTimeout(timeout);
    }

    const responseText = await response.text();
    if (!response.ok) {
      return res.status(response.status).json({
        error: 'OpenAI request failed',
        details: shorten(responseText)
      });
    }

    const openaiResponse = JSON.parse(responseText);
    const outputText = extractOutputText(openaiResponse);
    if (!outputText) {
      return res.status(502).json({
        error: 'OpenAI response did not contain output text.'
      });
    }

    const parsed = parseJsonObject(outputText);
    const candidates = sanitizeCandidates(parsed.candidates || [], supportedKeys);
    const visualReason = String(parsed.visual_reason || parsed.visualReason || '').trim();

    if (candidates.length === 0) {
      candidates.push({ key: 'unknown', confidence: 0 });
    }

    return res.json({
      method: `OpenAI Vision via Secure Backend (${OPENAI_MODEL})`,
      candidates,
      visual_reason: visualReason,
      needs_review: Boolean(parsed.needs_review ?? parsed.needsReview ?? true)
    });
  } catch (error) {
    const timedOut = error?.name === 'AbortError';
    return res.status(timedOut ? 504 : 500).json({
      error: timedOut ? 'OpenAI request timed out' : 'Backend analysis failed',
      details: error?.message || String(error)
    });
  }
});

function buildPrompt(supportedKeys) {
  return [
    'You are the Smart Chef visual ingredient recognition service.',
    'Analyze only what is visibly present in the image.',
    `You may choose ingredient keys only from this supported list: ${supportedKeys.join(', ')}.`,
    'Do not identify a recipe. Do not infer hidden ingredients. Do not guess from packaging text alone.',
    'If several supported ingredients are clearly visible, rank the three most relevant.',
    'If no supported ingredient is visually clear, use key "unknown".',
    'The confidence field is a conservative visual-clarity score from 0 to 100, not a guaranteed probability.',
    'Return JSON only, without markdown, in exactly this form:',
    '{"candidates":[{"key":"cucumber","confidence":95},{"key":"zucchini","confidence":20},{"key":"parsley","confidence":5}],"visual_reason":"short factual reason","needs_review":false}'
  ].join(' ');
}

function sanitizeBase64(value) {
  let text = String(value || '').trim();
  const comma = text.indexOf(',');
  if (text.startsWith('data:') && comma >= 0) text = text.slice(comma + 1);
  return text.replace(/\s+/g, '');
}

function sanitizeMimeType(value) {
  const mime = String(value || 'image/jpeg').toLowerCase().trim();
  const allowed = new Set(['image/jpeg', 'image/png', 'image/webp']);
  return allowed.has(mime) ? mime : 'image/jpeg';
}

function sanitizeSupportedKeys(value) {
  const raw = String(value || DEFAULT_SUPPORTED_KEYS);
  const keys = raw
    .split(',')
    .map(normalizeKey)
    .filter(Boolean)
    .filter((key) => key !== 'unknown');
  return Array.from(new Set(keys)).slice(0, 100);
}

function extractOutputText(data) {
  if (typeof data?.output_text === 'string' && data.output_text.trim()) {
    return data.output_text.trim();
  }
  const parts = [];
  for (const item of data?.output || []) {
    for (const content of item?.content || []) {
      if ((content?.type === 'output_text' || content?.type === 'text') && typeof content?.text === 'string') {
        parts.push(content.text);
      }
    }
  }
  return parts.join('\n').trim();
}

function parseJsonObject(value) {
  let text = stripCodeFence(String(value || '').trim());
  try {
    return JSON.parse(text);
  } catch (_firstError) {
    const start = text.indexOf('{');
    const end = text.lastIndexOf('}');
    if (start >= 0 && end > start) {
      return JSON.parse(text.slice(start, end + 1));
    }
    throw new Error('OpenAI returned invalid JSON.');
  }
}

function stripCodeFence(value) {
  let text = String(value || '').trim();
  if (text.startsWith('```')) {
    const firstNewLine = text.indexOf('\n');
    const lastFence = text.lastIndexOf('```');
    if (firstNewLine >= 0 && lastFence > firstNewLine) {
      text = text.slice(firstNewLine + 1, lastFence).trim();
    }
  }
  return text;
}

function sanitizeCandidates(items, supportedKeys) {
  const supported = new Set(supportedKeys);
  supported.add('unknown');
  const used = new Set();
  const output = [];

  for (const item of Array.isArray(items) ? items : []) {
    const key = normalizeKey(item?.key);
    if (!key || !supported.has(key) || used.has(key)) continue;

    let confidence = Number(item?.confidence || 0);
    if (confidence >= 0 && confidence <= 1) confidence *= 100;
    confidence = Math.max(0, Math.min(100, Math.round(confidence)));

    used.add(key);
    output.push({ key, confidence });
  }

  output.sort((a, b) => b.confidence - a.confidence);
  return output.slice(0, 3);
}

function normalizeKey(value) {
  let key = String(value || '').trim().toLowerCase().replace(/[\s-]+/g, '_');
  const aliases = {
    basmati_rice: 'rice',
    eggs: 'egg',
    meat: 'beef',
    lamb: 'beef',
    macaroni: 'pasta',
    spaghetti: 'pasta',
    red_lentil: 'red_lentils',
    lentils: 'red_lentils',
    none: 'unknown',
    unsupported: 'unknown'
  };
  return aliases[key] || key;
}

function shorten(value) {
  const text = String(value || '');
  return text.length <= 700 ? text : `${text.slice(0, 700)}...`;
}

app.listen(PORT, () => {
  console.log(`SmartChef OpenAI Vision Backend running on port ${PORT}`);
});
