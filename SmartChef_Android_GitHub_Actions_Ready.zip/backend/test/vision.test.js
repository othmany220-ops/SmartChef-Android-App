import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeKey, normalizeCertainty, sanitizeCandidates, reconcileAnalyses, shouldVerify } from '../vision-core.js';

test('normalizes supported aliases', () => {
  assert.equal(normalizeKey('Basmati Rice'), 'rice');
  assert.equal(normalizeKey('eggs'), 'egg');
  assert.equal(normalizeKey('lamb'), 'beef');
});

test('normalizes certainty conservatively', () => {
  assert.equal(normalizeCertainty('HIGH'), 'high');
  assert.equal(normalizeCertainty('unsupported'), 'low');
});

test('deduplicates and sorts candidates', () => {
  const result = sanitizeCandidates([
    { key: 'tomato', certainty: 'medium', visual_reason: 'red round object' },
    { key: 'tomato', certainty: 'high', visual_reason: 'duplicate' },
    { key: 'cucumber', certainty: 'high', visual_reason: 'green elongated object' }
  ]);
  assert.equal(result.length, 2);
  assert.equal(result[0].key, 'cucumber');
});

test('requires verification for medium certainty', () => {
  assert.equal(shouldVerify({ food_present: true, image_quality: 'good', needs_review: false, candidates: [{ key: 'tomato', certainty: 'medium' }] }), true);
});

test('agreement keeps the conservative certainty', () => {
  const merged = reconcileAnalyses(
    { food_present: true, image_quality: 'good', needs_review: false, candidates: [{ key: 'tomato', certainty: 'high', visual_reason: 'round red fruit' }], overall_reason: 'clear' },
    { food_present: true, image_quality: 'good', needs_review: false, candidates: [{ key: 'tomato', certainty: 'medium', visual_reason: 'red smooth skin' }], overall_reason: 'mostly clear' }
  );
  assert.equal(merged.candidates[0].key, 'tomato');
  assert.equal(merged.candidates[0].certainty, 'medium');
  assert.equal(merged.needs_review, true);
});
