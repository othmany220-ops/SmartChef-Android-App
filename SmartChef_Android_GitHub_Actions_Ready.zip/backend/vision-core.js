export const SUPPORTED_KEYS = Object.freeze([
  'rice', 'onion', 'potato', 'parsley', 'egg', 'tuna', 'garlic', 'cheese',
  'carrot', 'cucumber', 'chicken', 'yogurt', 'tomato', 'red_lentils',
  'beef', 'pasta', 'spices', 'milk', 'eggplant', 'bread', 'molokhia',
  'sumac', 'fish', 'chickpeas', 'tahini', 'spinach', 'zucchini', 'peas',
  'beans', 'lemon', 'pepper', 'banana', 'apple', 'orange', 'lettuce',
  'cabbage', 'corn', 'mushroom', 'cauliflower', 'broccoli', 'avocado',
  'unknown'
]);

export function normalizeCertainty(value) {
  const v = String(value || '').toLowerCase();
  return ['high', 'medium', 'low'].includes(v) ? v : 'low';
}

export function certaintyRank(v) {
  return v === 'high' ? 3 : v === 'medium' ? 2 : 1;
}

export function lowerCertainty(a, b) {
  return certaintyRank(a) <= certaintyRank(b) ? normalizeCertainty(a) : normalizeCertainty(b);
}

export function normalizeKey(value) {
  const key = String(value || '').trim().toLowerCase().replace(/[\s-]+/g, '_');
  const aliases = {
    basmati_rice: 'rice', eggs: 'egg', meat: 'beef', lamb: 'beef',
    macaroni: 'pasta', spaghetti: 'pasta', red_lentil: 'red_lentils',
    lentils: 'red_lentils', bell_pepper: 'pepper', capsicum: 'pepper',
    none: 'unknown', unsupported: 'unknown'
  };
  return aliases[key] || key;
}

export function sanitizeCandidates(items) {
  const allowed = new Set(SUPPORTED_KEYS);
  const used = new Set();
  const output = [];
  for (const item of Array.isArray(items) ? items : []) {
    const key = normalizeKey(item?.key);
    if (!key || !allowed.has(key) || used.has(key)) continue;
    used.add(key);
    output.push({
      key,
      certainty: normalizeCertainty(item?.certainty),
      visual_reason: String(item?.visual_reason || '').trim().slice(0, 240)
    });
  }
  output.sort((x, y) => certaintyRank(y.certainty) - certaintyRank(x.certainty));
  return output.slice(0, 3);
}

export function shouldVerify(result) {
  const candidates = sanitizeCandidates(result?.candidates);
  const top = candidates[0];
  return !result?.food_present || result?.image_quality !== 'good' || result?.needs_review || !top || top.key === 'unknown' || top.certainty !== 'high';
}

export function reconcileAnalyses(first, second) {
  const a = sanitizeCandidates(first?.candidates);
  const b = sanitizeCandidates(second?.candidates);
  const topA = a[0];
  const topB = b[0];

  if (!first?.food_present && !second?.food_present) return unknownResult('No supported ingredient was clearly visible.');

  if (topA && topB && topA.key === topB.key && topA.key !== 'unknown') {
    const certainty = lowerCertainty(topA.certainty, topB.certainty);
    return {
      food_present: true,
      image_quality: worstQuality(first?.image_quality, second?.image_quality),
      candidates: [{ key: topA.key, certainty, visual_reason: mergeReasons(topA.visual_reason, topB.visual_reason) }],
      needs_review: Boolean(first?.needs_review || second?.needs_review || certainty !== 'high'),
      overall_reason: mergeReasons(first?.overall_reason, second?.overall_reason)
    };
  }

  return {
    food_present: Boolean(first?.food_present || second?.food_present),
    image_quality: worstQuality(first?.image_quality, second?.image_quality),
    candidates: mergeDisagreeingCandidates(a, b),
    needs_review: true,
    overall_reason: 'Two independent verification passes did not agree. User confirmation is required.'
  };
}

export function sanitizeBase64(value) {
  let text = String(value || '').trim();
  const comma = text.indexOf(',');
  if (text.startsWith('data:') && comma >= 0) text = text.slice(comma + 1);
  return text.replace(/\s+/g, '');
}

export function sanitizeMimeType(value) {
  const mime = String(value || 'image/jpeg').toLowerCase().trim();
  return ['image/jpeg', 'image/png', 'image/webp'].includes(mime) ? mime : 'image/jpeg';
}

export function isLikelyBase64(value) {
  return value.length % 4 === 0 && /^[A-Za-z0-9+/]+={0,2}$/.test(value);
}

export function extractOutputText(data) {
  if (typeof data?.output_text === 'string' && data.output_text.trim()) return data.output_text.trim();
  const parts = [];
  for (const item of data?.output || []) {
    for (const content of item?.content || []) {
      if (content?.type === 'output_text' && typeof content?.text === 'string') parts.push(content.text);
    }
  }
  return parts.join('\n').trim();
}

export function worstQuality(a, b) {
  const rank = { good: 0, usable: 1, poor: 2 };
  return rank[a] >= rank[b] ? (a || 'poor') : (b || 'poor');
}

export function mergeReasons(a, b) {
  const left = String(a || '').trim();
  const right = String(b || '').trim();
  if (!left) return right;
  if (!right || left === right) return left;
  return `${left} ${right}`.slice(0, 320);
}

export function clampNumber(value, min, max, fallback) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.max(min, Math.min(max, n)) : fallback;
}

export function createRequestId() {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

export function safeError(error) {
  return { name: error?.name, message: error?.message, status: error?.status, body: error?.body };
}

function unknownResult(reason) {
  return {
    food_present: false,
    image_quality: 'poor',
    candidates: [{ key: 'unknown', certainty: 'low', visual_reason: reason }],
    needs_review: true,
    overall_reason: reason
  };
}

function mergeDisagreeingCandidates(a, b) {
  const output = [];
  for (const item of [...a, ...b]) {
    if (item.key === 'unknown' || output.some(x => x.key === item.key)) continue;
    output.push({ ...item, certainty: 'low' });
    if (output.length === 3) break;
  }
  return output.length ? output : [{ key: 'unknown', certainty: 'low', visual_reason: 'Verification passes did not agree.' }];
}
