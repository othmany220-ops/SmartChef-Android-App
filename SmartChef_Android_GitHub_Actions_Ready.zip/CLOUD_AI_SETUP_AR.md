# تشغيل OpenAI Vision في Smart Chef V19

هذه النسخة لا تضع مفتاح OpenAI داخل تطبيق Android. التطبيق يرسل الصورة إلى Backend آمن، والـBackend يتصل بـOpenAI Vision.

## المتغيرات المطلوبة

على الخادم:

```text
OPENAI_API_KEY=مفتاح_OpenAI
OPENAI_MODEL=gpt-4.1-mini
```

في GitHub Actions:

```text
VISION_BACKEND_URL=https://your-backend.example.com
```

## Render

- Root Directory: `backend`
- Build Command: `npm install`
- Start Command: `npm start`
- Health Check: `/health`

بعد النشر افتح:

```text
https://your-backend.example.com/health
```

يجب أن تكون `aiConfigured` مساوية لـ `true`.
