# تشغيل SmartChef V20 Verified OpenAI Vision

1. ارفع مشروع Backend أو المستودع إلى Render.
2. Root Directory: `backend`
3. Build Command: `npm install`
4. Start Command: `npm start`
5. أضف Environment Variable:

```text
OPENAI_API_KEY=مفتاحك
OPENAI_MODEL=gpt-5.5
OPENAI_FALLBACK_MODEL=gpt-5-mini
VISION_VERIFY=true
```

6. افتح رابط `/health` وتأكد أن `aiConfigured` تساوي `true`.
7. في GitHub أضف Secret:

```text
VISION_BACKEND_URL=https://your-render-service.onrender.com
```

8. شغّل Actions وحمّل Artifact:

```text
SmartChef-V20-verified-openai-vision-apk
```
