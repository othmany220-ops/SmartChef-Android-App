# SmartChef Android V20 — Verified OpenAI Vision

نسخة محسّنة من تطبيق Smart Chef للتعرف على مكونات الطعام واقتراح الوصفات.

## أهم التصحيحات

- التقاط صورة كاميرا كاملة الدقة بدل Thumbnail منخفض الجودة.
- تحليل الصور عبر Backend آمن؛ مفتاح OpenAI غير موجود داخل APK.
- OpenAI Responses API مع Structured Outputs.
- فحص تحقق ثانٍ عند الشك لتقليل أخطاء مثل خيار/معكرونة أو طماطم/لحم.
- عدم إضافة أي مكوّن قبل تأكيد المستخدم.
- منع التخمين المحلي الخاطئ عند تعطل الخادم.
- دعم الصور من الكاميرا والمعرض.

## بناء APK

يجب إضافة GitHub Secret:

```text
VISION_BACKEND_URL=https://your-backend.example.com
```

ثم تشغيل GitHub Actions. اسم Artifact:

```text
SmartChef-V20-verified-openai-vision-apk
```

## Backend

المجلد `backend` جاهز للنشر على Render أو Railway. أضف متغير البيئة:

```text
OPENAI_API_KEY
```

الموديل الافتراضي:

```text
gpt-5.5
```

مع fallback:

```text
gpt-5-mini
```

لا توجد دقة مضمونة 100%. استخدم صورًا واضحة بإضاءة جيدة، وراجع النتيجة قبل إضافتها.
