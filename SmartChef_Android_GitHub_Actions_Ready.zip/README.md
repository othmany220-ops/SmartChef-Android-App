# SmartChef Android V19 — OpenAI Vision Backend

Smart Chef is an Android recipe recommendation application with text, voice, camera, and gallery input.

## Image recognition architecture

```text
Android App → Secure Backend → OpenAI Responses API (Vision) → JSON → User Confirmation
```

The OpenAI API key is stored only on the backend as `OPENAI_API_KEY`. It is not embedded in the APK.

## Android build

The GitHub Actions build expects:

```text
VISION_BACKEND_URL
```

as a repository secret. The APK artifact is named:

```text
SmartChef-V19-openai-vision-apk
```

## Backend

```bash
cd backend
npm install
export OPENAI_API_KEY="sk-..."
export OPENAI_MODEL="gpt-4.1-mini"
npm start
```

Health check:

```text
GET /health
```

Image analysis:

```text
POST /analyze-ingredient
```

The app never adds an AI result automatically. The user reviews and confirms the detected ingredient.
