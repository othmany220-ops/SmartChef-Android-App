# Smart Chef — Version 21 (Final Evaluated Scope)

Smart Chef is a bilingual native Android application that recommends recipes from ingredients already available to the user. The evaluated release focuses on a stable, explainable text/voice workflow. Camera recognition remains visible in the interface as a disabled future feature and is not presented as an implemented objective.

## Implemented functions
- Arabic and English interfaces with RTL/LTR support.
- Manual text entry and voice-to-text input.
- Arabic/English ingredient normalization and synonym handling.
- Quick pantry ingredients.
- Explainable recipe ranking using available and unavailable ingredients.
- Matched and missing ingredient display.
- Detailed cooking steps and spices.
- Favorites, recent searches, recipe sharing, onboarding, haptic feedback, and dark mode.
- Fixed bottom navigation.

## Camera status
The camera button is intentionally disabled. Pressing it displays a future-feature notice. No camera permission, image upload, cloud backend, API key, or image-recognition model is used by the operational application.

Experimental SVM/CNN material is preserved only for academic comparison under:
`research-results/image-classification/`

The previous backend prototype is preserved only as future research under:
`future-camera-research/backend-prototype/`

## Recommendation formula
Ingredient weights:
- Main ingredient = 3
- Secondary ingredient = 2
- Supporting ingredient = 1

Definitions:
- `A = matched weighted value / total weighted recipe value`
- `U = missing ingredient count / total recipe ingredient count`
- `M = missing main-ingredient count / total main-ingredient count`

Final suitability:

`S = 100 × [0.75A + 0.25(1 − U)] × (1 − 0.20M)`

A recipe is excluded when it has required main ingredients but none of them match the user input. Results below the configured suitability threshold are also excluded.

## Build
```bash
chmod +x gradlew
./gradlew testDebugUnitTest
./gradlew assembleDebug
```

APK path:
`app/build/outputs/apk/debug/app-debug.apk`

GitHub Actions artifact:
`SmartChef-V21-stable-recommendation-apk`

## Documentation
- Final report: `documentation/SmartChef_Final_Report_V21.docx`
- Final PDF: `documentation/SmartChef_Final_Report_V21.pdf`
- Scope: `docs/PROJECT_SCOPE_V21.md`
- Formula: `docs/RECOMMENDATION_FORMULA.md`
- Testing: `docs/TESTING_GUIDE_AR.md`
- UML diagrams: `docs/uml/`
