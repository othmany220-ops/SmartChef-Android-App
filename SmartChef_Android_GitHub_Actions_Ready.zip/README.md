# SmartChef Android V21 — Professional Verified Vision

نسخة مصححة ومنظمة من تطبيق Smart Chef لتوصية الوصفات بناءً على المكونات المتوفرة.

## المعمارية

Android App → Secure Backend → OpenAI Responses API (Vision) → Structured JSON → User Confirmation → Recommendation Engine

## أهم التصحيحات

- لا يحتوي تطبيق Android على مفتاح OpenAI.
- تحليل الصور يتم عبر Backend آمن باستخدام Responses API وصورة عالية الدقة.
- استخدام Structured Outputs لضمان JSON منظم.
- إجراء تحقق مستقل عند الشك، وعدم التخمين إذا لم تتفق النتيجتان.
- عرض مستوى ثقة وصفي: مرتفع/متوسط/منخفض بدل نسبة رقمية غير معايرة.
- لا تتم إضافة أي مكوّن قبل تأكيد المستخدم.
- عند تعطل الخادم، ينتقل التطبيق إلى اختيار يدوي آمن بدل نتيجة خاطئة.
- تحسين خوارزمية التوصية: الوصفات الرئيسية تتطلب مكوناتها الأساسية فعلًا.
- إضافة اختبارات تلقائية للـBackend وخوارزمية التوصية.

## إعداد Backend

أضف متغير البيئة التالي في Render أو Railway:

```text
OPENAI_API_KEY
```

الموديل الافتراضي:

```text
gpt-5.5
```

## ربط تطبيق Android

أضف GitHub Secret:

```text
VISION_BACKEND_URL=https://your-backend.example.com
```

ثم شغّل GitHub Actions. اسم Artifact:

```text
SmartChef-V21-professional-apk
```

## ملاحظة مهمة

لا يوجد نظام رؤية يضمن دقة 100%. للحصول على أفضل نتيجة، التقط صورة واضحة لمكوّن خام واحد، بإضاءة جيدة وخلفية بسيطة. التطبيق يطلب تأكيد المستخدم دائمًا.
