# V10 Real AI Correction Notes

- The trained 16-class PyTorch Mobile Lite CNN remains embedded in the Android app.
- Inference now returns the top three ranked predictions.
- The UI never auto-adds an AI prediction; explicit user confirmation is required.
- Reliability threshold: top confidence >= 85% and top-vs-second margin >= 15 percentage points.
- A conservative visual sanity reweighting reduces obvious bright-red tomato versus dark-red/brown meat confusion.
- This is a reliability and safety correction. It does not replace the need for a larger, independent real-world image dataset.
