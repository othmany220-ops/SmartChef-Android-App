# Smart Chef Ingredient Recognition - Trained Model Card

## Trained outputs
- CNN TorchScript model: `models/smartchef_ingredient_cnn_torchscript.pt`
- SVM baseline: `models/smartchef_svm_color_pixels.joblib`
- CNN and SVM confusion-matrix figures and classification reports are included.

## Recorded evaluation on the provided augmented test split
- CNN test accuracy: 0.9917
- CNN weighted F1: 0.9916
- SVM test accuracy: 0.9938
- SVM weighted F1: 0.9938

## Critical scientific limitation
The dataset contains only 16 independent original seed photographs, one for each class. Training, validation, and test images are augmented variants derived from the same seed photographs. Therefore, the recorded metrics are optimistic and must not be presented as real-world production accuracy.

## Required next step for a defensible real-world model
Collect at least 100-300 independent original photographs per ingredient class. Keep all augmentations derived from one original image in one split only, and evaluate using independent photographs never used during training.
