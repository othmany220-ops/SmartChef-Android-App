# Smart Chef Android — Real AI GitHub Build

هذه النسخة تحتوي على نموذج CNN مدرّب فعليًا للتعرف على 16 فئة من المكونات داخل هاتف Android.

## الملفات المهمة
- `app/src/main/assets/smartchef_ingredient_cnn_mobile.ptl`: نموذج AI المحمول.
- `app/src/main/assets/labels.txt`: ترتيب الفئات المستخدمة أثناء التدريب.
- `app/src/main/java/com/smartchef/app/AIIngredientRecognizer.java`: كود تجهيز الصورة وتشغيل النموذج.
- `AI_RESULTS/`: نتائج التدريب، Confusion Matrices، والتقارير.

## طريقة الرفع باستخدام الهاتف والطريقة الحالية في GitHub
ارفع الملف الخارجي باسم `SmartChef_Android_GitHub_Actions_Ready.zip` إلى المستودع نفسه بدل الملف القديم. لا تفك ضغطه إذا كان ملف workflow الحالي يقوم بفك الضغط تلقائيًا.

بعد الرفع:
1. اضغط Commit changes.
2. افتح Actions.
3. افتح Build Smart Chef APK.
4. انتظر نجاح البناء.
5. حمّل `SmartChef-debug-apk` من Artifacts.

## ملاحظة علمية
النموذج حقيقي ومدرّب، لكن البيانات الأصلية المستقلة محدودة، لذلك يجب وصفه كنموذج أكاديمي أولي، وليس نموذج إنتاج بدقة مضمونة لجميع الصور الواقعية.
