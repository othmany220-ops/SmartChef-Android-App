package com.smartchef.app;

import org.junit.Test;
import java.util.Arrays;
import java.util.List;
import static org.junit.Assert.*;

public class RecommendationEngineTest {
    private Recipe recipe(String en, String ar, String... ingredients) {
        return new Recipe(en, ar, ingredients, "steps", "خطوات", "Main", "رئيسي", "30 min", "Easy", "سهل", 0);
    }

    @Test
    public void normalizesArabicVariants() {
        List<String> ingredients = RecommendationEngine.extractIngredients("لحمة، رز، لبن");
        assertTrue(ingredients.contains("beef"));
        assertTrue(ingredients.contains("rice"));
        assertTrue(ingredients.contains("yogurt"));
    }

    @Test
    public void completeMansafGetsFullSuitability() {
        Recipe mansaf = recipe("Mansaf", "منسف", "beef", "rice", "yogurt");
        List<RecommendationResult> results = RecommendationEngine.recommend("لحم أرز لبن", Arrays.asList(mansaf));
        assertEquals(1, results.size());
        assertEquals(100, results.get(0).percentage);
        assertEquals(100, results.get(0).availableWeightedPercentage);
        assertEquals(0, results.get(0).unavailablePercentage);
    }

    @Test
    public void missingMainIngredientReducesSuitability() {
        Recipe mansaf = recipe("Mansaf", "منسف", "beef", "rice", "yogurt");
        List<RecommendationResult> results = RecommendationEngine.recommend("لحم أرز", Arrays.asList(mansaf));
        assertEquals(1, results.size());
        assertTrue(results.get(0).percentage < 100);
        assertEquals(33, results.get(0).unavailablePercentage);
        assertTrue(results.get(0).missingIngredients.contains("yogurt"));
    }

    @Test
    public void cucumberDoesNotRecommendUnrelatedMeatRecipe() {
        Recipe meatStew = recipe("Meat Stew", "يخنة لحم", "beef", "potato", "onion");
        List<RecommendationResult> results = RecommendationEngine.recommend("خيار", Arrays.asList(meatStew));
        assertTrue(results.isEmpty());
    }

    @Test
    public void resultsAreSortedBySuitability() {
        Recipe omelette = recipe("Omelette", "أومليت", "egg", "cheese", "tomato");
        Recipe salad = recipe("Salad", "سلطة", "cucumber", "tomato", "parsley");
        List<RecommendationResult> results = RecommendationEngine.recommend("بيض جبن طماطم خيار", Arrays.asList(salad, omelette));
        assertFalse(results.isEmpty());
        assertEquals("Omelette", results.get(0).recipe.nameEn);
    }
}
