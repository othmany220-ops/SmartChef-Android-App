package com.smartchef.app;

import org.junit.Test;
import java.util.List;
import static org.junit.Assert.*;

public class RecommendationEngineTest {
    @Test public void normalizesArabicVariants() {
        List<String> result = RecommendationEngine.extractIngredients("رز، جاج، بندورة");
        assertTrue(result.contains("rice"));
        assertTrue(result.contains("chicken"));
        assertTrue(result.contains("tomato"));
    }

    @Test public void removesDuplicates() {
        List<String> result = RecommendationEngine.extractIngredients("طماطم، بندورة، طماطم");
        int count = 0;
        for (String item : result) if ("tomato".equals(item)) count++;
        assertEquals(1, count);
    }

    @Test public void mansafRequiresAllEssentialIngredients() {
        List<RecommendationResult> noMansaf = RecommendationEngine.recommend("لحم، رز", RecipeRepository.getRecipes());
        assertFalse(contains(noMansaf, "Jordanian Mansaf"));
        List<RecommendationResult> yesMansaf = RecommendationEngine.recommend("لحم، رز، لبن", RecipeRepository.getRecipes());
        assertTrue(contains(yesMansaf, "Jordanian Mansaf"));
    }

    @Test public void kabsaRanksForChickenRiceSpices() {
        List<RecommendationResult> results = RecommendationEngine.recommend("دجاج، رز، بهارات، بصل، طماطم", RecipeRepository.getRecipes());
        assertFalse(results.isEmpty());
        assertEquals("Chicken Kabsa", results.get(0).recipe.nameEn);
    }

    @Test public void cucumberAloneDoesNotShowMeatOrPasta() {
        List<RecommendationResult> results = RecommendationEngine.recommend("خيار", RecipeRepository.getRecipes());
        for (RecommendationResult result : results) {
            assertNotEquals("Beef Potato Stew", result.recipe.nameEn);
            assertNotEquals("Tomato Macaroni", result.recipe.nameEn);
        }
    }

    private boolean contains(List<RecommendationResult> list, String name) {
        for (RecommendationResult item : list) if (name.equals(item.recipe.nameEn)) return true;
        return false;
    }
}
