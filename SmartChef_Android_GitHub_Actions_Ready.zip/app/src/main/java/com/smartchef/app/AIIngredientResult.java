package com.smartchef.app;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Full AI inference result. The UI must always ask the user to confirm the result
 * before adding it to the ingredient list.
 */
public class AIIngredientResult {
    public final String ingredientKey;
    public final String ingredientNameEn;
    public final String ingredientNameAr;
    public final String certainty;
    public final boolean reliable;
    public final boolean needsReview;
    public final String method;
    public final String rawLabels;
    public final List<AICandidate> candidates;

    public AIIngredientResult(List<AICandidate> candidates, boolean reliable, boolean needsReview, String method, String rawLabels) {
        List<AICandidate> safe = candidates == null ? new ArrayList<>() : new ArrayList<>(candidates);
        this.candidates = Collections.unmodifiableList(safe);
        this.method = method == null ? "" : method;
        this.rawLabels = rawLabels == null ? "" : rawLabels;
        this.needsReview = needsReview;

        if (safe.isEmpty()) {
            ingredientKey = "";
            ingredientNameEn = "Unknown";
            ingredientNameAr = "غير معروف";
            certainty = "low";
            this.reliable = false;
        } else {
            AICandidate first = safe.get(0);
            ingredientKey = first.ingredientKey;
            ingredientNameEn = first.ingredientNameEn;
            ingredientNameAr = first.ingredientNameAr;
            certainty = first.certainty;
            this.reliable = reliable && !needsReview && "high".equals(first.certainty) && !"unknown".equals(first.ingredientKey);
        }
    }
}
