package com.smartchef.app;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Full AI inference result. The UI must always ask the user to confirm the result
 * before adding it to the ingredient list.
 */
public class AIIngredientResult {
    public final String ingredientKey;
    public final String ingredientNameEn;
    public final String ingredientNameAr;
    public final int confidence;
    public final int confidenceMargin;
    public final boolean reliable;
    public final String method;
    public final String rawLabels;
    public final List<AICandidate> candidates;

    public AIIngredientResult(List<AICandidate> candidates, String method, String rawLabels) {
        List<AICandidate> safe = candidates == null ? new ArrayList<>() : new ArrayList<>(candidates);
        this.candidates = Collections.unmodifiableList(safe);
        this.method = method == null ? "" : method;
        this.rawLabels = rawLabels == null ? "" : rawLabels;

        if (safe.isEmpty()) {
            ingredientKey = "";
            ingredientNameEn = "Unknown";
            ingredientNameAr = "غير معروف";
            confidence = 0;
            confidenceMargin = 0;
            reliable = false;
        } else {
            AICandidate first = safe.get(0);
            ingredientKey = first.ingredientKey;
            ingredientNameEn = first.ingredientNameEn;
            ingredientNameAr = first.ingredientNameAr;
            confidence = first.confidence;
            int second = safe.size() > 1 ? safe.get(1).confidence : 0;
            confidenceMargin = Math.max(0, confidence - second);
            reliable = confidence >= 85 && confidenceMargin >= 15;
        }
    }
}
