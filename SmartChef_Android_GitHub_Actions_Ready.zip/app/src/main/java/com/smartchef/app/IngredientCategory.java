package com.smartchef.app;

public class IngredientCategory {
    public final String key;
    public final String nameEn;
    public final String nameAr;
    public final int imageResId;

    public IngredientCategory(String key, String nameEn, String nameAr, int imageResId) {
        this.key = key;
        this.nameEn = nameEn;
        this.nameAr = nameAr;
        this.imageResId = imageResId;
    }
}
