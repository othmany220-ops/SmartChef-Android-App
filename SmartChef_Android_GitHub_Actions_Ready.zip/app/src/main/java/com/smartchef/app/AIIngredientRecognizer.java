package com.smartchef.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;

import org.pytorch.IValue;
import org.pytorch.LiteModuleLoader;
import org.pytorch.Module;
import org.pytorch.Tensor;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 * Real on-device ingredient classifier using the trained PyTorch Mobile Lite CNN.
 *
 * V10 correction:
 * - returns the top three CNN predictions;
 * - uses a limited visual sanity adjustment to reduce obvious color-confusion cases;
 * - never adds a prediction automatically (the UI always requires confirmation);
 * - considers a result reliable only if confidence >= 85% and margin >= 15%.
 */
public final class AIIngredientRecognizer {
    public interface Callback {
        void onResult(AIIngredientResult result);
    }

    private static final String MODEL_ASSET = "smartchef_ingredient_cnn_mobile.ptl";
    private static final int IMAGE_SIZE = 96;
    private static final Object MODEL_LOCK = new Object();
    private static Module module;

    // Exact training label order.
    private static final String[] INGREDIENT_KEYS = {
            "rice", "onion", "potato", "parsley", "egg", "tuna", "garlic", "cheese",
            "carrot", "cucumber", "chicken", "yogurt", "tomato", "red_lentils", "beef", "pasta"
    };

    private AIIngredientRecognizer() { }

    public static void analyze(Context context, Bitmap bitmap, Callback callback) {
        if (bitmap == null) {
            callback.onResult(new AIIngredientResult(new ArrayList<>(), "CNN model", "No image was provided"));
            return;
        }

        new Thread(() -> {
            try {
                callback.onResult(predict(context.getApplicationContext(), bitmap));
            } catch (Exception e) {
                callback.onResult(new AIIngredientResult(new ArrayList<>(), "CNN model error",
                        e.getMessage() == null ? e.toString() : e.getMessage()));
            }
        }).start();
    }

    private static AIIngredientResult predict(Context context, Bitmap source) throws IOException {
        Module localModule = getModule(context);
        Bitmap bitmap = Bitmap.createScaledBitmap(source, IMAGE_SIZE, IMAGE_SIZE, true);

        final int pixels = IMAGE_SIZE * IMAGE_SIZE;
        float[] input = new float[3 * pixels];
        int[] row = new int[IMAGE_SIZE];

        for (int y = 0; y < IMAGE_SIZE; y++) {
            bitmap.getPixels(row, 0, IMAGE_SIZE, 0, y, IMAGE_SIZE, 1);
            for (int x = 0; x < IMAGE_SIZE; x++) {
                int color = row[x];
                int index = y * IMAGE_SIZE + x;
                input[index] = (((color >> 16) & 0xFF) / 127.5f) - 1f;
                input[pixels + index] = (((color >> 8) & 0xFF) / 127.5f) - 1f;
                input[2 * pixels + index] = ((color & 0xFF) / 127.5f) - 1f;
            }
        }

        Tensor inputTensor = Tensor.fromBlob(input, new long[]{1, 3, IMAGE_SIZE, IMAGE_SIZE});
        Tensor outputTensor = localModule.forward(IValue.from(inputTensor)).toTensor();
        float[] logits = outputTensor.getDataAsFloatArray();
        if (logits.length != INGREDIENT_KEYS.length) {
            throw new IllegalStateException("Unexpected model output size: " + logits.length);
        }

        float[] rawProbabilities = softmax(logits);
        float[] adjustedProbabilities = applyVisualSanityAdjustment(source, rawProbabilities);
        List<AICandidate> topThree = topCandidates(adjustedProbabilities, 3);

        return new AIIngredientResult(topThree, "Trained CNN + visual sanity check",
                "raw=" + Arrays.toString(rawProbabilities) + "; adjusted=" + Arrays.toString(adjustedProbabilities));
    }

    /**
     * Secondary, conservative post-processing. It only reweights probabilities;
     * it does not directly decide the ingredient. This specifically reduces obvious
     * bright-red tomato versus dark-red/brown meat confusion.
     */
    private static float[] applyVisualSanityAdjustment(Bitmap source, float[] original) {
        float[] adjusted = original.clone();
        Bitmap bitmap = Bitmap.createScaledBitmap(source, 64, 64, true);
        float[] hsv = new float[3];
        int visible = 0, redBright = 0, redDark = 0, brown = 0, orange = 0, yellow = 0, green = 0, white = 0;

        for (int y = 0; y < bitmap.getHeight(); y++) {
            for (int x = 0; x < bitmap.getWidth(); x++) {
                int color = bitmap.getPixel(x, y);
                int r = Color.red(color), g = Color.green(color), b = Color.blue(color);
                Color.RGBToHSV(r, g, b, hsv);
                float h = hsv[0], s = hsv[1], v = hsv[2];
                if (v < 0.07f) continue;
                visible++;
                if (s < 0.12f && v > 0.74f) white++;
                if ((h < 18 || h > 345) && s > 0.40f && v > 0.43f) redBright++;
                if ((h < 25 || h > 340) && s > 0.24f && v <= 0.48f) redDark++;
                if (h >= 15 && h < 45 && s > 0.18f && v > 0.18f && v < 0.62f) brown++;
                if (h >= 18 && h < 48 && s > 0.38f && v > 0.42f) orange++;
                if (h >= 48 && h < 78 && s > 0.24f && v > 0.45f) yellow++;
                if (h >= 78 && h < 175 && s > 0.24f && v > 0.25f) green++;
            }
        }
        if (visible == 0) return adjusted;

        float rb = redBright / (float) visible;
        float rd = redDark / (float) visible;
        float br = brown / (float) visible;
        float or = orange / (float) visible;
        float ye = yellow / (float) visible;
        float gr = green / (float) visible;
        float wh = white / (float) visible;

        // Indices: rice 0, onion 1, potato 2, parsley 3, egg 4, tuna 5,
        // garlic 6, cheese 7, carrot 8, cucumber 9, chicken 10, yogurt 11,
        // tomato 12, red_lentils 13, beef 14, pasta 15.
        if (rb > 0.12f && rd + br < 0.22f) {
            adjusted[12] *= 1.0f + Math.min(1.8f, rb * 5f);
            adjusted[14] *= 0.55f;
        }
        if (rd + br > 0.18f) {
            adjusted[14] *= 1.0f + Math.min(1.3f, (rd + br) * 3f);
            adjusted[12] *= 0.75f;
        }
        if (or > 0.12f) {
            adjusted[8] *= 1.0f + Math.min(1.4f, or * 4f);
            adjusted[13] *= 1.0f + Math.min(0.7f, or * 2f);
        }
        if (gr > 0.12f) {
            adjusted[9] *= 1.0f + Math.min(1.0f, gr * 3f);
            adjusted[3] *= 1.0f + Math.min(1.0f, gr * 3f);
        }
        if (wh + ye > 0.32f) {
            adjusted[4] *= 1.0f + Math.min(0.8f, (wh + ye) * 1.7f);
            adjusted[7] *= 1.0f + Math.min(0.5f, ye * 1.5f);
            adjusted[0] *= 1.0f + Math.min(0.35f, wh * 0.8f);
        }

        normalize(adjusted);
        return adjusted;
    }

    private static List<AICandidate> topCandidates(float[] probabilities, int count) {
        Integer[] indices = new Integer[probabilities.length];
        for (int i = 0; i < indices.length; i++) indices[i] = i;
        Arrays.sort(indices, new Comparator<Integer>() {
            @Override public int compare(Integer a, Integer b) {
                return Float.compare(probabilities[b], probabilities[a]);
            }
        });

        List<AICandidate> result = new ArrayList<>();
        for (int i = 0; i < Math.min(count, indices.length); i++) {
            int index = indices[i];
            result.add(createCandidate(INGREDIENT_KEYS[index], Math.round(probabilities[index] * 100f)));
        }
        return result;
    }

    private static Module getModule(Context context) throws IOException {
        synchronized (MODEL_LOCK) {
            if (module == null) module = LiteModuleLoader.load(assetFilePath(context, MODEL_ASSET));
            return module;
        }
    }

    private static String assetFilePath(Context context, String assetName) throws IOException {
        File file = new File(context.getFilesDir(), assetName);
        if (file.exists() && file.length() > 0) return file.getAbsolutePath();
        try (InputStream inputStream = context.getAssets().open(assetName);
             FileOutputStream outputStream = new FileOutputStream(file)) {
            byte[] buffer = new byte[8192];
            int read;
            while ((read = inputStream.read(buffer)) != -1) outputStream.write(buffer, 0, read);
            outputStream.flush();
        }
        return file.getAbsolutePath();
    }

    private static float[] softmax(float[] logits) {
        float max = logits[0];
        for (float v : logits) if (v > max) max = v;
        float sum = 0f;
        float[] output = new float[logits.length];
        for (int i = 0; i < logits.length; i++) {
            output[i] = (float) Math.exp(logits[i] - max);
            sum += output[i];
        }
        for (int i = 0; i < output.length; i++) output[i] /= Math.max(sum, 1e-12f);
        return output;
    }

    private static void normalize(float[] values) {
        float sum = 0f;
        for (float value : values) sum += Math.max(value, 0f);
        if (sum <= 1e-12f) return;
        for (int i = 0; i < values.length; i++) values[i] = Math.max(values[i], 0f) / sum;
    }

    private static AICandidate createCandidate(String key, int confidence) {
        switch (key) {
            case "rice": return new AICandidate(key, "Basmati Rice", "أرز بسمتي", confidence);
            case "onion": return new AICandidate(key, "Onion", "بصل", confidence);
            case "potato": return new AICandidate(key, "Potato", "بطاطا", confidence);
            case "parsley": return new AICandidate(key, "Parsley", "بقدونس", confidence);
            case "egg": return new AICandidate(key, "Eggs", "بيض", confidence);
            case "tuna": return new AICandidate(key, "Tuna", "تونة", confidence);
            case "garlic": return new AICandidate(key, "Garlic", "ثوم", confidence);
            case "cheese": return new AICandidate(key, "Cheese", "جبن", confidence);
            case "carrot": return new AICandidate(key, "Carrot", "جزر", confidence);
            case "cucumber": return new AICandidate(key, "Cucumber", "خيار", confidence);
            case "chicken": return new AICandidate(key, "Chicken", "دجاج", confidence);
            case "yogurt": return new AICandidate(key, "Yogurt", "لبن / زبادي", confidence);
            case "tomato": return new AICandidate(key, "Tomato", "طماطم", confidence);
            case "red_lentils": return new AICandidate(key, "Red Lentils", "عدس أحمر", confidence);
            case "beef": return new AICandidate(key, "Meat", "لحم", confidence);
            case "pasta": return new AICandidate(key, "Pasta / Macaroni", "معكرونة", confidence);
            default: return new AICandidate("", "Unknown", "غير معروف", 0);
        }
    }
}
