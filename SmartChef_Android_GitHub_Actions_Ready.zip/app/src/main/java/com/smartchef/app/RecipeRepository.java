package com.smartchef.app;

import java.util.ArrayList;
import java.util.List;

public class RecipeRepository {
    public static List<IngredientCategory> getIngredientCategories() {
        List<IngredientCategory> items = new ArrayList<>();
        items.add(new IngredientCategory("egg", "Egg", "بيض", R.drawable.ing_egg));
        items.add(new IngredientCategory("tomato", "Tomato", "طماطم", R.drawable.ing_tomato));
        items.add(new IngredientCategory("cheese", "Cheese", "جبن", R.drawable.ing_cheese));
        items.add(new IngredientCategory("chicken", "Chicken", "دجاج", R.drawable.ing_chicken));
        items.add(new IngredientCategory("rice", "Rice", "أرز", R.drawable.ing_rice));
        items.add(new IngredientCategory("pasta", "Macaroni", "معكرونة", R.drawable.ing_pasta));
        items.add(new IngredientCategory("onion", "Onion", "بصل", R.drawable.ing_onion));
        items.add(new IngredientCategory("garlic", "Garlic", "ثوم", R.drawable.ing_garlic));
        items.add(new IngredientCategory("potato", "Potato", "بطاطا", R.drawable.ing_potato));
        items.add(new IngredientCategory("carrot", "Carrot", "جزر", R.drawable.ing_carrot));
        items.add(new IngredientCategory("cucumber", "Cucumber", "خيار", R.drawable.ing_cucumber));
        items.add(new IngredientCategory("parsley", "Parsley", "بقدونس", R.drawable.ing_parsley));
        items.add(new IngredientCategory("tuna", "Tuna", "تونة", R.drawable.ing_tuna));
        items.add(new IngredientCategory("yogurt", "Yogurt", "زبادي", R.drawable.ing_yogurt));
        items.add(new IngredientCategory("red_lentils", "Red Lentils", "عدس أحمر", R.drawable.ing_red_lentils));
        items.add(new IngredientCategory("beef", "Meat", "لحم", R.drawable.ing_beef));
        items.add(new IngredientCategory("spices", "Spices", "بهارات", R.drawable.ing_parsley));
        items.add(new IngredientCategory("milk", "Milk", "حليب", R.drawable.ing_yogurt));
        items.add(new IngredientCategory("eggplant", "Eggplant", "باذنجان", R.drawable.ing_potato));
        items.add(new IngredientCategory("bread", "Bread", "خبز", R.drawable.ing_rice));
        items.add(new IngredientCategory("molokhia", "Molokhia", "ملوخية", R.drawable.ing_parsley));
        items.add(new IngredientCategory("sumac", "Sumac", "سماق", R.drawable.ing_parsley));
        items.add(new IngredientCategory("fish", "Fish", "سمك", R.drawable.ing_chicken));
        items.add(new IngredientCategory("chickpeas", "Chickpeas", "حمص", R.drawable.ing_red_lentils));
        items.add(new IngredientCategory("tahini", "Tahini", "طحينة", R.drawable.ing_yogurt));
        items.add(new IngredientCategory("spinach", "Spinach", "سبانخ", R.drawable.ing_parsley));
        items.add(new IngredientCategory("zucchini", "Zucchini", "كوسا", R.drawable.ing_cucumber));
        items.add(new IngredientCategory("peas", "Peas", "بازيلا", R.drawable.ing_carrot));
        items.add(new IngredientCategory("beans", "Beans", "فاصوليا", R.drawable.ing_red_lentils));
        return items;
    }

    public static List<Recipe> getRecipes() {
        List<Recipe> recipes = new ArrayList<>();

        recipes.add(0, new Recipe(
                "Jordanian Mansaf", "منسف أردني",
                new String[]{"beef", "rice", "yogurt"},
                "1. Boil the meat with onion, bay leaf, cardamom, black pepper and a little salt until tender.\n2. Prepare the yogurt sauce by mixing yogurt or jameed with a little meat broth, then simmer it gently while stirring.\n3. Cook the rice with turmeric, salt and a small spoon of oil until fluffy.\n4. Add the cooked meat to the yogurt sauce for a few minutes so the flavor combines.\n5. Serve rice on a large plate, add meat and yogurt sauce, then garnish with toasted nuts and parsley if available.",
                "١. اسلق اللحم مع البصل وورق الغار والهيل والفلفل الأسود وقليل من الملح حتى ينضج.\n٢. حضّر صلصة اللبن أو الجميد بإضافة قليل من مرق اللحم، ثم اتركها على نار هادئة مع التحريك.\n٣. اطبخ الأرز مع الكركم والملح وملعقة صغيرة من الزيت حتى يصبح مفلفلًا.\n٤. أضف اللحم المطبوخ إلى صلصة اللبن عدة دقائق حتى تتجانس النكهة.\n٥. قدّم الأرز في طبق واسع، ثم ضع اللحم وصلصة اللبن فوقه، وزيّنه بالمكسرات والبقدونس إن توفرا.",
                "Main Dish", "طبق رئيسي", "70 min", "Medium", "متوسط", R.drawable.recipe_mansaf));
        recipes.add(1, new Recipe(
                "Chicken Kabsa", "كبسة دجاج",
                new String[]{"chicken", "rice", "onion", "tomato", "garlic", "spices"},
                "1. Season the chicken with kabsa spices, black pepper, turmeric, cinnamon, cardamom and salt.\n2. Sauté onion and garlic in oil, then add tomato and cook until it becomes a rich sauce.\n3. Add the chicken and brown it lightly, then add water or broth and simmer until cooked.\n4. Add washed rice to the broth, adjust salt and cook on low heat until the rice absorbs the liquid.\n5. Serve the kabsa with the chicken on top and garnish with parsley or nuts if available.",
                "١. تبّل الدجاج ببهارات الكبسة والفلفل الأسود والكركم والقرفة والهيل والملح.\n٢. شوّح البصل والثوم بالزيت، ثم أضف الطماطم حتى تتكوّن صلصة غنية.\n٣. أضف الدجاج وقلّبه قليلًا، ثم أضف الماء أو المرق واتركه حتى ينضج.\n٤. أضف الأرز المغسول إلى المرق، واضبط الملح، ثم اطهه على نار هادئة حتى يتشرب السائل.\n٥. قدّم الكبسة مع الدجاج فوق الأرز وزيّنه بالبقدونس أو المكسرات إن توفرت.",
                "Main Dish", "طبق رئيسي", "60 min", "Medium", "متوسط", R.drawable.recipe_kabsa));
        recipes.add(new Recipe(
                "Cheese Omelette", "أومليت بالجبن",
                new String[]{"egg", "cheese", "tomato", "parsley"},
                "1. Beat the eggs with a pinch of salt, black pepper and a small amount of paprika.\n2. Add chopped tomato and grated cheese.\n3. Heat a lightly oiled pan, pour the mixture and cook on low heat.\n4. Fold the omelette, garnish with parsley, and serve warm.",
                "١. اخفق البيض مع رشة ملح وفلفل أسود وقليل من البابريكا.\n٢. أضف الطماطم المفرومة والجبن المبشور.\n٣. سخّن مقلاة مع قليل من الزيت، ثم اسكب الخليط واطهه على نار هادئة.\n٤. اطوِ الأومليت، زيّنه بالبقدونس، وقدّمه ساخنًا.",
                "Breakfast", "فطور", "12 min", "Easy", "سهل", R.drawable.recipe_omelette));
        recipes.add(new Recipe(
                "Tomato Shakshuka", "شكشوكة الطماطم",
                new String[]{"egg", "tomato", "onion", "garlic"},
                "1. Sauté onion and garlic in oil until fragrant.\n2. Add chopped tomatoes, salt, black pepper, cumin and paprika.\n3. Simmer until the sauce becomes thick.\n4. Add the eggs, cover the pan and cook until the eggs set.",
                "١. شوّح البصل والثوم في قليل من الزيت حتى تظهر الرائحة.\n٢. أضف الطماطم المفرومة مع الملح والفلفل الأسود والكمون والبابريكا.\n٣. اترك الصلصة حتى تتماسك.\n٤. أضف البيض، غطِّ المقلاة، واتركه حتى ينضج.",
                "Breakfast", "فطور", "18 min", "Easy", "سهل", R.drawable.recipe_shakshuka));
        recipes.add(new Recipe(
                "Chicken Salad", "سلطة الدجاج",
                new String[]{"chicken", "cucumber", "tomato", "parsley"},
                "1. Season chicken with salt, pepper, garlic powder and lemon if available.\n2. Grill or boil the chicken, then slice it.\n3. Mix cucumber, tomato and parsley in a bowl.\n4. Add the chicken and serve with yogurt or light dressing.",
                "١. تبّل الدجاج بالملح والفلفل وبودرة الثوم، ويمكن إضافة الليمون إن توفر.\n٢. اشوِ الدجاج أو اسلقه ثم قطّعه شرائح.\n٣. اخلط الخيار والطماطم والبقدونس في وعاء.\n٤. أضف الدجاج وقدّمه مع الزبادي أو صلصة خفيفة.",
                "Healthy", "صحي", "15 min", "Easy", "سهل", R.drawable.recipe_chicken_salad));
        recipes.add(new Recipe(
                "Tomato Macaroni", "معكرونة بالطماطم",
                new String[]{"pasta", "tomato", "garlic", "cheese"},
                "1. Boil macaroni with salt until soft.\n2. Sauté garlic in oil, then add tomato and a little black pepper, basil or oregano.\n3. Mix the cooked pasta with the sauce.\n4. Add cheese on top and let it melt before serving.",
                "١. اسلق المعكرونة في ماء مملح حتى تنضج.\n٢. شوّح الثوم بالزيت، ثم أضف الطماطم مع فلفل أسود وقليل من الريحان أو الأوريغانو.\n٣. اخلط المعكرونة مع الصلصة.\n٤. أضف الجبن فوقها واتركه يذوب قبل التقديم.",
                "Lunch", "غداء", "25 min", "Medium", "متوسط", R.drawable.recipe_pasta));
        recipes.add(new Recipe(
                "Red Lentil Soup", "شوربة العدس الأحمر",
                new String[]{"red_lentils", "carrot", "onion", "garlic"},
                "1. Wash the lentils well.\n2. Cook onion, garlic and carrot with a little oil.\n3. Add lentils, water, salt, cumin and black pepper.\n4. Simmer until soft, then blend for a smooth texture.",
                "١. اغسل العدس جيدًا.\n٢. شوّح البصل والثوم والجزر مع قليل من الزيت.\n٣. أضف العدس والماء والملح والكمون والفلفل الأسود.\n٤. اتركه حتى ينضج، ثم اخلطه للحصول على قوام ناعم.",
                "Soup", "شوربة", "30 min", "Easy", "سهل", R.drawable.recipe_soup));
        recipes.add(new Recipe(
                "Chicken Rice Bowl", "أرز بالدجاج",
                new String[]{"chicken", "rice", "onion", "garlic"},
                "1. Season chicken with salt, pepper, turmeric, paprika and a little cumin.\n2. Sauté onion and garlic, then add chicken until browned.\n3. Cook rice separately or with the chicken broth.\n4. Serve chicken over rice and garnish with parsley.",
                "١. تبّل الدجاج بالملح والفلفل والكركم والبابريكا وقليل من الكمون.\n٢. شوّح البصل والثوم، ثم أضف الدجاج حتى يتحمر.\n٣. اطهِ الأرز وحده أو مع مرق الدجاج.\n٤. قدّم الدجاج فوق الأرز وزيّنه بالبقدونس.",
                "Lunch", "غداء", "35 min", "Medium", "متوسط", R.drawable.recipe_rice_chicken));
        recipes.add(new Recipe(
                "Tuna Cucumber Salad", "سلطة التونة بالخيار",
                new String[]{"tuna", "cucumber", "tomato", "parsley"},
                "1. Drain the tuna.\n2. Chop cucumber, tomato and parsley.\n3. Mix everything with salt, pepper and a little lemon or yogurt.\n4. Serve cold as a light meal.",
                "١. صفِّ التونة من الزيت أو الماء.\n٢. قطّع الخيار والطماطم والبقدونس.\n٣. اخلط المكونات مع الملح والفلفل وقليل من الليمون أو الزبادي.\n٤. قدّمها باردة كوجبة خفيفة.",
                "Snack", "وجبة خفيفة", "10 min", "Easy", "سهل", R.drawable.recipe_tuna_sandwich));
        recipes.add(new Recipe(
                "Yogurt Cucumber Salad", "سلطة الزبادي بالخيار",
                new String[]{"yogurt", "cucumber", "garlic", "parsley"},
                "1. Grate or chop cucumber.\n2. Mix yogurt with garlic, salt, mint if available and black pepper.\n3. Add cucumber and parsley.\n4. Chill for 10 minutes before serving.",
                "١. ابشر الخيار أو قطّعه ناعمًا.\n٢. اخلط الزبادي مع الثوم والملح والنعناع إن توفر والفلفل الأسود.\n٣. أضف الخيار والبقدونس.\n٤. برّد السلطة ١٠ دقائق قبل التقديم.",
                "Healthy", "صحي", "7 min", "Easy", "سهل", R.drawable.recipe_banana_smoothie));
        recipes.add(new Recipe(
                "Potato Cheese Bake", "بطاطا بالجبن",
                new String[]{"potato", "cheese", "yogurt", "parsley"},
                "1. Slice potatoes and boil them slightly.\n2. Mix yogurt with salt, pepper, garlic powder and paprika.\n3. Layer potatoes with cheese and sauce.\n4. Bake until golden and garnish with parsley.",
                "١. قطّع البطاطا واسلقها قليلًا.\n٢. اخلط الزبادي مع الملح والفلفل وبودرة الثوم والبابريكا.\n٣. رتّب البطاطا مع الجبن والصلصة.\n٤. اخبزها حتى تصبح ذهبية وزيّنها بالبقدونس.",
                "Dinner", "عشاء", "40 min", "Medium", "متوسط", R.drawable.recipe_yogurt_bowl));
        recipes.add(new Recipe(
                "Beef Potato Stew", "يخنة لحم بالبطاطا",
                new String[]{"beef", "potato", "tomato", "onion", "garlic"},
                "1. Brown the beef with onion and garlic.\n2. Add tomato, salt, pepper, allspice and a little cumin.\n3. Add potato cubes and water or broth.\n4. Simmer until the meat and potatoes are tender.",
                "١. حمّر اللحم مع البصل والثوم.\n٢. أضف الطماطم والملح والفلفل والبهار المشكل وقليلًا من الكمون.\n٣. أضف مكعبات البطاطا والماء أو المرق.\n٤. اترك اليخنة حتى ينضج اللحم والبطاطا.",
                "Dinner", "عشاء", "55 min", "Medium", "متوسط", R.drawable.recipe_beef_stew));
        recipes.add(new Recipe(
                "Garlic Chicken Plate", "طبق الدجاج بالثوم",
                new String[]{"chicken", "garlic", "yogurt", "cucumber"},
                "1. Marinate chicken with yogurt, garlic, salt, pepper and paprika.\n2. Leave it for 10 minutes if possible.\n3. Cook the chicken in a pan or grill.\n4. Serve with cucumber yogurt salad.",
                "١. تبّل الدجاج بالزبادي والثوم والملح والفلفل والبابريكا.\n٢. اتركه ١٠ دقائق إن أمكن.\n٣. اطهه في مقلاة أو على الشواية.\n٤. قدّمه مع سلطة خيار بالزبادي.",
                "Dinner", "عشاء", "25 min", "Easy", "سهل", R.drawable.recipe_wrap));
        recipes.add(new Recipe(
                "Vegetable Macaroni", "معكرونة بالخضار",
                new String[]{"pasta", "tomato", "cheese", "carrot", "onion"},
                "1. Boil pasta with salt.\n2. Sauté onion and carrot, then add tomato sauce.\n3. Season with pepper, oregano and a small pinch of paprika.\n4. Mix with pasta and finish with cheese.",
                "١. اسلق المعكرونة مع الملح.\n٢. شوّح البصل والجزر، ثم أضف صلصة الطماطم.\n٣. تبّل بالفلفل والأوريغانو ورشة بابريكا خفيفة.\n٤. اخلطها مع المعكرونة وأضف الجبن في النهاية.",
                "Dinner", "عشاء", "20 min", "Easy", "سهل", R.drawable.recipe_pizza));
        recipes.add(new Recipe(
                "Banana Milk Smoothie", "سموثي الموز بالحليب",
                new String[]{"banana", "milk", "yogurt"},
                "1. Slice the banana.\n2. Blend banana with milk and yogurt.\n3. Add a small pinch of cinnamon or honey if available.\n4. Serve cold.",
                "١. قطّع الموز إلى شرائح.\n٢. اخلط الموز مع الحليب والزبادي.\n٣. أضف رشة قرفة أو عسلًا إن توفر.\n٤. قدّمه باردًا.",
                "Drink", "مشروب", "5 min", "Easy", "سهل", R.drawable.recipe_banana_smoothie));
        recipes.add(new Recipe(
                "Fresh Garden Salad", "سلطة خضار طازجة",
                new String[]{"cucumber", "tomato", "lettuce", "parsley"},
                "1. Wash and chop all vegetables.\n2. Mix cucumber, tomato, lettuce and parsley.\n3. Season with salt, pepper, lemon and a little olive oil if available.\n4. Serve immediately for the best texture.",
                "١. اغسل الخضار وقطّعها جيدًا.\n٢. اخلط الخيار والطماطم والخس والبقدونس.\n٣. تبّل بالملح والفلفل والليمون وقليل من زيت الزيتون إن توفر.\n٤. قدّمها مباشرة للحصول على أفضل قوام.",
                "Salad", "سلطة", "8 min", "Easy", "سهل", R.drawable.recipe_chicken_salad));
        recipes.add(new Recipe(
                "Chicken Maqluba", "مقلوبة دجاج",
                new String[]{"chicken", "rice", "potato", "eggplant", "onion", "spices"},
                "1. Season the chicken with salt, black pepper, cardamom, cinnamon, turmeric and allspice.\n2. Boil the chicken with onion until nearly cooked, then keep the broth.\n3. Fry or roast potato and eggplant slices until lightly golden.\n4. Arrange chicken, vegetables and washed rice in a pot, then add the seasoned broth.\n5. Cook on low heat until the rice is done, rest for 10 minutes, then flip carefully onto a serving plate.",
                "١. تبّل الدجاج بالملح والفلفل الأسود والهيل والقرفة والكركم والبهار المشكل.\n٢. اسلق الدجاج مع البصل حتى يقترب من النضج واحتفظ بالمرق.\n٣. اقْلِ أو اشوِ شرائح البطاطا والباذنجان حتى تتحمر قليلًا.\n٤. رتّب الدجاج والخضار والأرز المغسول في القدر، ثم أضف المرق المتبل.\n٥. اطبخها على نار هادئة حتى ينضج الأرز، اتركها ١٠ دقائق ثم اقلبها بحذر في طبق التقديم.",
                "Main Dish", "طبق رئيسي", "65 min", "Medium", "متوسط", R.drawable.recipe_rice_chicken));
        recipes.add(new Recipe(
                "Chicken Molokhia", "ملوخية بالدجاج",
                new String[]{"chicken", "rice", "molokhia", "garlic", "lemon"},
                "1. Boil chicken with onion, bay leaf, cardamom, salt and black pepper until tender.\n2. Prepare rice separately with a little salt and oil.\n3. Add molokhia to the hot chicken broth and simmer gently without overboiling.\n4. Fry garlic with coriander or a pinch of cumin, then add it to the molokhia.\n5. Serve with chicken, rice and lemon juice.",
                "١. اسلق الدجاج مع البصل وورق الغار والهيل والملح والفلفل الأسود حتى ينضج.\n٢. حضّر الأرز وحده مع قليل من الملح والزيت.\n٣. أضف الملوخية إلى مرق الدجاج الساخن واتركها تغلي بهدوء دون مبالغة.\n٤. قلّب الثوم مع الكزبرة أو رشة كمون، ثم أضفه إلى الملوخية.\n٥. قدّمها مع الدجاج والأرز وعصير الليمون.",
                "Main Dish", "طبق رئيسي", "45 min", "Easy", "سهل", R.drawable.recipe_soup));
        recipes.add(new Recipe(
                "Palestinian Musakhan", "مسخن دجاج",
                new String[]{"chicken", "onion", "bread", "sumac", "oil"},
                "1. Season chicken with salt, black pepper, allspice, cinnamon and a little cardamom.\n2. Cook the chicken until tender, then roast it lightly.\n3. Slowly cook onions in olive oil until soft and sweet, then add sumac.\n4. Spread the onion mixture over bread, place chicken on top and bake briefly.\n5. Serve warm with yogurt or salad if available.",
                "١. تبّل الدجاج بالملح والفلفل الأسود والبهار المشكل والقرفة وقليل من الهيل.\n٢. اطبخ الدجاج حتى ينضج ثم حمّره قليلًا.\n٣. اطبخ البصل ببطء في زيت الزيتون حتى يطرى، ثم أضف السماق.\n٤. افرد خليط البصل على الخبز، ضع الدجاج فوقه، ثم أدخله الفرن قليلًا.\n٥. قدّمه دافئًا مع الزبادي أو السلطة إن توفرت.",
                "Main Dish", "طبق رئيسي", "55 min", "Medium", "متوسط", R.drawable.recipe_wrap));
        recipes.add(new Recipe(
                "Kofta Potato Tray", "صينية كفتة بالبطاطا",
                new String[]{"beef", "potato", "tomato", "onion", "parsley", "spices"},
                "1. Mix minced meat with onion, parsley, salt, black pepper, allspice and a pinch of cinnamon.\n2. Shape the kofta in a tray and add sliced potatoes and tomatoes.\n3. Add tomato sauce or broth with a little paprika and garlic.\n4. Bake until the potatoes are tender and the kofta is cooked.\n5. Serve with rice or bread.",
                "١. اخلط اللحم المفروم مع البصل والبقدونس والملح والفلفل والبهار المشكل ورشة قرفة.\n٢. رتّب الكفتة في صينية وأضف شرائح البطاطا والطماطم.\n٣. أضف صلصة طماطم أو مرقًا مع قليل من البابريكا والثوم.\n٤. اخبزها حتى تنضج البطاطا والكفتة.\n٥. قدّمها مع الأرز أو الخبز.",
                "Main Dish", "طبق رئيسي", "50 min", "Medium", "متوسط", R.drawable.recipe_beef_stew));
        recipes.add(new Recipe(
                "Chicken Mandi", "مندي دجاج",
                new String[]{"chicken", "rice", "onion", "spices"},
                "1. Season chicken with mandi spices, salt, black pepper, turmeric, cardamom and cinnamon.\n2. Cook onion with a little oil, then add rice and the required broth.\n3. Place chicken above the rice or roast it separately until golden.\n4. Cook until rice is fluffy and chicken is fully done.\n5. Serve with tomato sauce or salad.",
                "١. تبّل الدجاج ببهارات المندي والملح والفلفل الأسود والكركم والهيل والقرفة.\n٢. شوّح البصل بقليل من الزيت، ثم أضف الأرز والمرق المناسب.\n٣. ضع الدجاج فوق الأرز أو حمّره وحده حتى يصبح ذهبيًا.\n٤. اطبخ حتى يصبح الأرز مفلفلًا وينضج الدجاج تمامًا.\n٥. قدّمه مع صلصة الطماطم أو السلطة.",
                "Main Dish", "طبق رئيسي", "60 min", "Medium", "متوسط", R.drawable.recipe_kabsa));
        recipes.add(new Recipe(
                "Mujadara", "مجدرة العدس والأرز",
                new String[]{"red_lentils", "rice", "onion", "oil"},
                "1. Wash lentils and cook them until half tender.\n2. Add washed rice, salt, cumin and black pepper.\n3. Cook onions slowly in oil until deeply golden.\n4. Mix part of the onions into the rice and lentils.\n5. Serve with the remaining onions on top and yogurt or salad.",
                "١. اغسل العدس واطبخه حتى يقترب من النضج.\n٢. أضف الأرز المغسول والملح والكمون والفلفل الأسود.\n٣. حمّر البصل ببطء في الزيت حتى يصبح ذهبيًا.\n٤. اخلط جزءًا من البصل مع الأرز والعدس.\n٥. قدّمها مع باقي البصل على الوجه والزبادي أو السلطة.",
                "Main Dish", "طبق رئيسي", "35 min", "Easy", "سهل", R.drawable.recipe_soup));
        recipes.add(new Recipe(
                "Sayadieh Fish Rice", "صيادية السمك",
                new String[]{"fish", "rice", "onion", "spices"},
                "1. Season fish with salt, pepper, cumin, coriander and lemon.\n2. Fry or bake the fish until cooked.\n3. Caramelize onions until dark golden, then add rice and fish broth or water.\n4. Cook rice with the spices until fluffy.\n5. Serve rice with fish on top and lemon on the side.",
                "١. تبّل السمك بالملح والفلفل والكمون والكزبرة والليمون.\n٢. اقْلِ السمك أو اخبزه حتى ينضج.\n٣. حمّر البصل حتى يصبح ذهبيًا غامقًا، ثم أضف الأرز ومرق السمك أو الماء.\n٤. اطبخ الأرز مع البهارات حتى يصبح مفلفلًا.\n٥. قدّم الأرز مع السمك فوقه والليمون بجانبه.",
                "Main Dish", "طبق رئيسي", "45 min", "Medium", "متوسط", R.drawable.recipe_rice_chicken));
        recipes.add(new Recipe(
                "Fattet Hummus", "فتة حمص",
                new String[]{"chickpeas", "bread", "yogurt", "tahini", "garlic"},
                "1. Toast or fry bread pieces until crisp.\n2. Warm chickpeas with a little cumin and salt.\n3. Mix yogurt with tahini, garlic, lemon and a pinch of salt.\n4. Layer bread, chickpeas and yogurt sauce.\n5. Garnish with parsley, paprika and nuts if available.",
                "١. حمّص أو اقْلِ قطع الخبز حتى تصبح مقرمشة.\n٢. سخّن الحمص مع قليل من الكمون والملح.\n٣. اخلط الزبادي مع الطحينة والثوم والليمون ورشة ملح.\n٤. رتّب الخبز ثم الحمص ثم صلصة الزبادي.\n٥. زيّنها بالبقدونس والبابريكا والمكسرات إن توفرت.",
                "Breakfast", "فطور", "20 min", "Easy", "سهل", R.drawable.recipe_yogurt_bowl));
        recipes.add(new Recipe(
                "Stuffed Zucchini", "كوسا محشي",
                new String[]{"zucchini", "rice", "beef", "tomato", "spices"},
                "1. Hollow zucchini carefully.\n2. Mix rice with minced meat, salt, pepper, allspice, cinnamon and a little oil.\n3. Stuff the zucchini without overfilling.\n4. Cook in tomato sauce or broth until tender.\n5. Serve hot with yogurt if available.",
                "١. احفر الكوسا بحذر.\n٢. اخلط الأرز مع اللحم المفروم والملح والفلفل والبهار المشكل والقرفة وقليل من الزيت.\n٣. احشُ الكوسا دون ضغط زائد.\n٤. اطبخها في صلصة طماطم أو مرق حتى تنضج.\n٥. قدّمها ساخنة مع الزبادي إن توفر.",
                "Main Dish", "طبق رئيسي", "75 min", "Medium", "متوسط", R.drawable.recipe_beef_stew));
        recipes.add(new Recipe(
                "Chicken Shawarma Wrap", "شاورما دجاج",
                new String[]{"chicken", "yogurt", "garlic", "spices", "bread"},
                "1. Slice chicken thinly.\n2. Marinate with yogurt, garlic, lemon, salt, black pepper, paprika, cumin and a little cinnamon.\n3. Cook in a hot pan until browned.\n4. Fill bread with chicken, cucumber or salad and garlic sauce.\n5. Toast the wrap lightly before serving.",
                "١. قطّع الدجاج شرائح رفيعة.\n٢. تبّله بالزبادي والثوم والليمون والملح والفلفل والبابريكا والكمون وقليل من القرفة.\n٣. اطهه في مقلاة ساخنة حتى يتحمر.\n٤. احشُ الخبز بالدجاج والخيار أو السلطة وصلصة الثوم.\n٥. حمّص الساندويش قليلًا قبل التقديم.",
                "Sandwich", "ساندويش", "30 min", "Easy", "سهل", R.drawable.recipe_wrap));
        recipes.add(new Recipe(
                "Lasagna", "لازانيا باللحم",
                new String[]{"pasta", "beef", "cheese", "tomato", "onion"},
                "1. Cook minced meat with onion, tomato sauce, salt, pepper, oregano and a little paprika.\n2. Prepare lasagna sheets according to the package instructions.\n3. Layer sauce, pasta and cheese in a baking dish.\n4. Bake until the top is golden and the cheese melts.\n5. Rest for 10 minutes before slicing.",
                "١. اطبخ اللحم المفروم مع البصل وصلصة الطماطم والملح والفلفل والأوريغانو ورشة بابريكا.\n٢. حضّر شرائح اللازانيا حسب التعليمات.\n٣. رتّب الصلصة والمعكرونة والجبن في صينية.\n٤. اخبزها حتى يصبح الوجه ذهبيًا ويذوب الجبن.\n٥. اتركها ١٠ دقائق قبل التقطيع.",
                "Main Dish", "طبق رئيسي", "70 min", "Medium", "متوسط", R.drawable.recipe_lasagna_real));
        recipes.add(new Recipe(
                "Chicken Alfredo Pasta", "معكرونة ألفريدو بالدجاج",
                new String[]{"chicken", "pasta", "milk", "cheese", "garlic"},
                "1. Season chicken with salt, pepper and garlic powder, then cook until golden.\n2. Boil pasta in salted water.\n3. Cook garlic with a little oil or butter, add milk and cheese, then stir until creamy.\n4. Add pasta and sliced chicken to the sauce.\n5. Serve warm with parsley or black pepper.",
                "١. تبّل الدجاج بالملح والفلفل وبودرة الثوم ثم اطهه حتى يتحمر.\n٢. اسلق المعكرونة في ماء مملح.\n٣. شوّح الثوم بقليل من الزيت أو الزبدة، أضف الحليب والجبن وحرّك حتى تصبح الصلصة كريمية.\n٤. أضف المعكرونة وشرائح الدجاج إلى الصلصة.\n٥. قدّمها دافئة مع البقدونس أو الفلفل الأسود.",
                "Pasta", "معكرونة", "30 min", "Easy", "سهل", R.drawable.recipe_pasta_real));
        recipes.add(new Recipe(
                "Rice Pudding", "أرز بالحليب",
                new String[]{"rice", "milk", "sugar", "cinnamon"},
                "1. Cook rice with water until very soft.\n2. Add milk and sugar, then stir on low heat.\n3. Continue cooking until thick and creamy.\n4. Add a little cinnamon or vanilla if available.\n5. Serve warm or chilled.",
                "١. اطبخ الأرز بالماء حتى يلين جيدًا.\n٢. أضف الحليب والسكر وحرّك على نار هادئة.\n٣. استمر حتى يصبح القوام كريميًا.\n٤. أضف قليلًا من القرفة أو الفانيلا إن توفرت.\n٥. قدّمه ساخنًا أو باردًا.",
                "Dessert", "حلوى", "35 min", "Easy", "سهل", R.drawable.recipe_yogurt_bowl));
        return recipes;
    }
}
