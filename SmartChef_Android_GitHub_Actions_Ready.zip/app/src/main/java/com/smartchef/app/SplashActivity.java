package com.smartchef.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SplashActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        Button startButton = findViewById(R.id.startButton);
        Button exploreButton = findViewById(R.id.exploreButton);
        View.OnClickListener openApp = new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(SplashActivity.this, MainActivity.class));
                finish();
            }
        };
        startButton.setOnClickListener(openApp);
        exploreButton.setOnClickListener(openApp);
    }
}
