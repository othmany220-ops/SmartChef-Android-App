package com.smartchef.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;


public class MainActivity extends Activity {
    private static final int REQUEST_SPEECH = 101;
    private static final int REQUEST_RECORD_AUDIO_PERMISSION = 103;

    private LinearLayout rootLayout, topBar, heroCard, inputCard, quickIngredientsContainer, recentSearchContainer, resultsContainer, bottomBar;
    private TextView logoTitle, menuIcon, darkButton, appTitle, appSubtitle, inputTitle, quickTitle, recentTitle, resultsTitle, imagePrototypeNote;
    private EditText ingredientsInput;
    private Button languageButton, aboutButton, welcomeButton, recommendButton, voiceButton, imageButton, favoritesButton, homeNavButton;

    private boolean isArabic;
    private boolean darkMode;
    private final List<Recipe> recipes = RecipeRepository.getRecipes();
    private final List<IngredientCategory> ingredientCategories = RecipeRepository.getIngredientCategories();
    private final String PREFS = "smart_chef_v3";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bindViews();
        isArabic = LanguageManager.isArabic(this);
        darkMode = getPrefs().getBoolean("dark_mode", false);
        setupActions();
        applyLanguage();
        applyTheme();
        buildQuickIngredients();
        buildRecentSearches();
        showFeaturedRecipes();
        showWelcomeIfNeeded();
    }


    private SharedPreferences getPrefs() {
        return getSharedPreferences(PREFS, MODE_PRIVATE);
    }

    private void bindViews() {
        rootLayout = findViewById(R.id.rootLayout);
        topBar = findViewById(R.id.topBar);
        heroCard = findViewById(R.id.heroCard);
        inputCard = findViewById(R.id.inputCard);
        quickIngredientsContainer = findViewById(R.id.quickIngredientsContainer);
        recentSearchContainer = findViewById(R.id.recentSearchContainer);
        resultsContainer = findViewById(R.id.resultsContainer);
        bottomBar = findViewById(R.id.bottomBar);
        logoTitle = findViewById(R.id.logoTitle);
        menuIcon = findViewById(R.id.menuIcon);
        darkButton = findViewById(R.id.darkButton);
        appTitle = findViewById(R.id.appTitle);
        appSubtitle = findViewById(R.id.appSubtitle);
        inputTitle = findViewById(R.id.inputTitle);
        quickTitle = findViewById(R.id.quickTitle);
        recentTitle = findViewById(R.id.recentTitle);
        resultsTitle = findViewById(R.id.resultsTitle);
        imagePrototypeNote = findViewById(R.id.imagePrototypeNote);
        ingredientsInput = findViewById(R.id.ingredientsInput);
        languageButton = findViewById(R.id.languageButton);
        aboutButton = findViewById(R.id.aboutButton);
        welcomeButton = findViewById(R.id.welcomeButton);
        recommendButton = findViewById(R.id.recommendButton);
        voiceButton = findViewById(R.id.voiceButton);
        imageButton = findViewById(R.id.imageButton);
        favoritesButton = findViewById(R.id.favoritesButton);
        homeNavButton = findViewById(R.id.homeNavButton);
    }

    private void setupActions() {
        languageButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                vibrate(v);
                isArabic = !isArabic;
                LanguageManager.setArabic(MainActivity.this, isArabic);
                applyLanguage();
                buildQuickIngredients();
                buildRecentSearches();
                showFeaturedRecipes();
            }
        });
        darkButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                vibrate(v);
                darkMode = !darkMode;
                getPrefs().edit().putBoolean("dark_mode", darkMode).apply();
                applyTheme();
            }
        });
        recommendButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { vibrate(v); recommendRecipes(); }
        });
        voiceButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { vibrate(v); requestVoiceInput(); }
        });
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { vibrate(v); showCameraFutureDialog(); }
        });
        aboutButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { vibrate(v); showAboutDialog(); }
        });
        welcomeButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { vibrate(v); showWelcomeDialog(); }
        });
        menuIcon.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { vibrate(v); showWelcomeDialog(); }
        });
        favoritesButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { vibrate(v); showFavorites(); }
        });
        homeNavButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { vibrate(v); showFeaturedRecipes(); }
        });
    }

    private void vibrate(View v) {
        if (v != null) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
    }


    private void applyLanguage() {
        int direction = isArabic ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR;
        rootLayout.setLayoutDirection(direction);
        ingredientsInput.setTextDirection(isArabic ? View.TEXT_DIRECTION_RTL : View.TEXT_DIRECTION_LTR);
        ingredientsInput.setGravity(isArabic ? Gravity.RIGHT | Gravity.TOP : Gravity.LEFT | Gravity.TOP);

        if (isArabic) {
            logoTitle.setText("Smart Chef");
            appTitle.setText("مرحبًا بك في\nSmart Chef");
            appSubtitle.setText("أضف مكوناتك إلى مخزن Smart Chef وستظهر لك الوصفات التي تناسب ما لديك.");
            welcomeButton.setText("ابدأ إضافة المكونات");
            languageButton.setText("EN");
            aboutButton.setText("حول");
            favoritesButton.setText("المفضلة");
            homeNavButton.setText("مخزني");
            inputTitle.setText("مخزن المكونات لديك");
            ingredientsInput.setHint("مثال: لحم، أرز، لبن أو دجاج، أرز، بهارات...");
            quickTitle.setText("أضف مكوناتك بسرعة");
            recentTitle.setText("بحثك الأخير");
            recommendButton.setText("اعرض الوصفات المتاحة");
            voiceButton.setText("إدخال صوتي");
            imageButton.setText("الكاميرا (ميزة مستقبلية)");
            imagePrototypeNote.setText("الكاميرا معروضة كميزة مستقبلية فقط وليست جزءًا من وظائف الإصدار الحالي. استخدم الإدخال النصي أو الصوتي.");
            resultsTitle.setText("قائمة الوصفات المتاحة الآن");
            darkButton.setText(darkMode ? "☀" : "🌙");
        } else {
            logoTitle.setText("Smart Chef");
            appTitle.setText("Welcome to\nSmart Chef");
            appSubtitle.setText("Build your Smart Chef pantry and get recipes that match what you already have.");
            welcomeButton.setText("Start Adding Ingredients");
            languageButton.setText("AR");
            aboutButton.setText("About");
            favoritesButton.setText("Favorites");
            homeNavButton.setText("Pantry");
            inputTitle.setText("Your Ingredient Pantry");
            ingredientsInput.setHint("Example: meat, rice, yogurt or chicken, rice, spices...");
            quickTitle.setText("Quick Pantry Items");
            recentTitle.setText("Recent Pantry Search");
            recommendButton.setText("Show Available Recipes");
            voiceButton.setText("Voice Input");
            imageButton.setText("Camera (Future Feature)");
            imagePrototypeNote.setText("Camera-based ingredient recognition is not enabled in the current release. It is planned for future development after training and testing on a larger image dataset.");
            resultsTitle.setText("Recipes You Can Make Now");
            darkButton.setText(darkMode ? "☀" : "🌙");
        }

        imagePrototypeNote.setVisibility(View.VISIBLE);
        imageButton.setAlpha(0.82f);
    }

    private void applyTheme() {
        int bg = darkMode ? Color.rgb(18,18,18) : getResources().getColor(R.color.cream_bg);
        int cardText = darkMode ? Color.WHITE : getResources().getColor(R.color.text_dark);
        int muted = darkMode ? Color.rgb(200,200,200) : getResources().getColor(R.color.text_muted);
        rootLayout.setBackgroundColor(bg);
        inputCard.setBackgroundResource(darkMode ? R.drawable.bg_dark_panel : R.drawable.bg_card);
        bottomBar.setBackgroundResource(darkMode ? R.drawable.bg_bottom_bar_dark : R.drawable.bg_bottom_bar);
        logoTitle.setTextColor(darkMode ? Color.WHITE : Color.rgb(59,31,13));
        menuIcon.setTextColor(darkMode ? Color.WHITE : getResources().getColor(R.color.text_dark));
        appTitle.setTextColor(cardText);
        appSubtitle.setTextColor(muted);
        inputTitle.setTextColor(cardText);
        quickTitle.setTextColor(cardText);
        recentTitle.setTextColor(cardText);
        resultsTitle.setTextColor(cardText);
        ingredientsInput.setTextColor(cardText);
        ingredientsInput.setHintTextColor(muted);
        darkButton.setText(darkMode ? "☀" : "🌙");
    }

    private void showWelcomeIfNeeded() {
        if (!getPrefs().getBoolean("welcome_seen", false)) {
            getPrefs().edit().putBoolean("welcome_seen", true).apply();
            showWelcomeDialog();
        }
    }

    private void showWelcomeDialog() {
        String text = isArabic ?
                "مرحبًا بك في Smart Chef.\n\nطريقة الاستخدام:\n1. اكتب المكونات الموجودة لديك أو أضفها من الاختصارات السريعة.\n2. يمكنك استخدام الإدخال الصوتي لتحويل كلامك إلى مكونات مكتوبة.\n3. اضغط على عرض الوصفات المتاحة لتظهر النتائج مرتبة حسب نسبة الملاءمة.\n4. راجع المكونات المتوفرة والناقصة ثم افتح تفاصيل التحضير.\n5. يمكنك حفظ الوصفة في المفضلة أو مشاركتها.\n\nملاحظة: زر الكاميرا موجود لتوضيح التطوير المستقبلي، لكنه غير مفعّل في الإصدار الحالي." :
                "Welcome to Smart Chef.\n\nHow to use:\n1. Type your available ingredients or add quick pantry items.\n2. Use voice input to convert spoken ingredients into text.\n3. Press Show Available Recipes to rank recipes by suitability.\n4. Review available and missing ingredients, then open preparation details.\n5. Save recipes to favorites or share them.\n\nNote: the camera button represents planned future development and is not enabled in the current release.";
        new AlertDialog.Builder(this)
                .setTitle(isArabic ? "كيف تستخدم التطبيق؟" : "How to Use the App")
                .setMessage(text)
                .setPositiveButton(isArabic ? "ابدأ" : "Start", null)
                .show();
    }

    private void buildQuickIngredients() {
        quickIngredientsContainer.removeAllViews();
        int limit = Math.min(10, ingredientCategories.size());
        for (int i = 0; i < limit; i++) {
            final IngredientCategory ingredient = ingredientCategories.get(i);
            Button chip = chipButton((isArabic ? ingredient.nameAr : ingredient.nameEn) + " +");
            chip.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { vibrate(v); appendIngredient(ingredient.key); }
            });
            quickIngredientsContainer.addView(chip, chipParams());
        }
    }

    private Button chipButton(String text) {
        Button chip = new Button(this);
        chip.setText(text);
        chip.setTextColor(getResources().getColor(R.color.green_dark));
        chip.setTextSize(13);
        chip.setAllCaps(false);
        chip.setBackgroundResource(R.drawable.bg_chip);
        chip.setPadding(dp(10), 0, dp(10), 0);
        return chip;
    }

    private LinearLayout.LayoutParams chipParams() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(42));
        params.setMargins(0, 0, dp(8), 0);
        return params;
    }

    private void buildRecentSearches() {
        recentSearchContainer.removeAllViews();
        List<String> recent = getRecentSearches();
        if (recent.isEmpty()) {
            Button empty = chipButton(isArabic ? "لا يوجد بحث بعد" : "No recent searches");
            empty.setEnabled(false);
            recentSearchContainer.addView(empty, chipParams());
            return;
        }
        for (final String item : recent) {
            Button chip = chipButton(item);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { vibrate(v); ingredientsInput.setText(item); ingredientsInput.setSelection(ingredientsInput.getText().length()); recommendRecipes(); }
            });
            recentSearchContainer.addView(chip, chipParams());
        }
    }

    private void appendIngredient(String key) {
        String current = ingredientsInput.getText().toString().trim();
        String value = getIngredientLabel(key);
        if (!current.isEmpty() && !current.endsWith("،") && !current.endsWith(",")) current += isArabic ? "، " : ", ";
        ingredientsInput.setText(current + value);
        ingredientsInput.setSelection(ingredientsInput.getText().length());
    }


    private void recommendRecipes() {
        String input = ingredientsInput.getText().toString().trim();
        resultsContainer.removeAllViews();
        if (input.isEmpty()) {
            addMessageCard(isArabic ? "اكتب مكوّنًا واحدًا على الأقل أو استخدم الإدخال الصوتي، ثم اضغط على عرض الوصفات المتاحة." : "Enter at least one ingredient or use voice input, then press Show Available Recipes.");
            return;
        }
        saveRecentSearch(input);
        buildRecentSearches();
        List<RecommendationResult> results = RecommendationEngine.recommend(input, recipes);
        if (results.isEmpty()) {
            addMessageCard(isArabic ? "لم يتم العثور على تطابق واضح. جرّب مثلًا: بيض، طماطم، جبن أو دجاج، أرز، بصل." : "No clear match was found. Try: egg, tomato, cheese or chicken, rice, onion.");
            return;
        }
        for (RecommendationResult result : results) addRecipeCard(result, true);
    }

    private void showFeaturedRecipes() {
        resultsContainer.removeAllViews();
        addMessageCard(isArabic ? "ابدأ بكتابة المكونات أو استخدم الإدخال الصوتي. ستظهر الوصفات مرتبة حسب نسبة الملاءمة، مع توضيح المكونات المتوفرة والناقصة." : "Add your ingredients by text or voice. Recipes will be ranked by suitability with available and missing ingredients clearly shown.");
        int limit = Math.min(5, recipes.size());
        for (int i = 0; i < limit; i++) addRecipeCard(new RecommendationResult(recipes.get(i), new ArrayList<String>()), false);
    }

    private void addMessageCard(String message) {
        TextView card = new TextView(this);
        card.setBackgroundResource(darkMode ? R.drawable.bg_dark_panel : R.drawable.bg_card);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setText(message);
        card.setTextColor(darkMode ? Color.rgb(220,220,220) : getResources().getColor(R.color.text_muted));
        card.setTextSize(15);
        card.setLineSpacing(0, 1.18f);
        card.setTextDirection(isArabic ? View.TEXT_DIRECTION_RTL : View.TEXT_DIRECTION_LTR);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 0, 0, dp(12));
        resultsContainer.addView(card, params);
    }

    private void addRecipeCard(final RecommendationResult result, boolean recommendationMode) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(darkMode ? R.drawable.bg_dark_panel : R.drawable.bg_card);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        card.setLayoutDirection(isArabic ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cardParams.setMargins(0, 0, 0, dp(12));

        TextView availableTag = new TextView(this);
        availableTag.setText(recommendationMode ? (isArabic ? "مناسب لمخزنك" : "Pantry match") : (isArabic ? "اقتراح مميز" : "Featured"));
        availableTag.setTextColor(getResources().getColor(R.color.orange));
        availableTag.setTextSize(12);
        availableTag.setTypeface(null, android.graphics.Typeface.BOLD);
        availableTag.setGravity(isArabic ? Gravity.RIGHT : Gravity.LEFT);
        card.addView(availableTag);

        TextView title = new TextView(this);
        title.setText(isArabic ? result.recipe.nameAr : result.recipe.nameEn);
        title.setTextColor(darkMode ? Color.WHITE : getResources().getColor(R.color.text_dark));
        title.setTextSize(21);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setPadding(0, dp(8), 0, 0);
        title.setTextDirection(isArabic ? View.TEXT_DIRECTION_RTL : View.TEXT_DIRECTION_LTR);
        card.addView(title);

        TextView info = new TextView(this);
        info.setText(isArabic ? result.recipe.categoryAr + "  |  " + result.recipe.time + "  |  " + result.recipe.difficultyAr : result.recipe.categoryEn + "  |  " + result.recipe.time + "  |  " + result.recipe.difficultyEn);
        info.setTextColor(darkMode ? Color.rgb(200,200,200) : getResources().getColor(R.color.text_muted));
        info.setTextSize(13);
        info.setPadding(0, dp(6), 0, 0);
        card.addView(info);

        if (recommendationMode) {
            TextView score = new TextView(this);
            score.setText(isArabic
                    ? "نسبة ملاءمة الوصفة: " + result.percentage + "%\nالمتوفر الموزون: " + result.availableWeightedPercentage + "%  |  غير المتوفر: " + result.unavailablePercentage + "%"
                    : "Recipe suitability: " + result.percentage + "%\nWeighted availability: " + result.availableWeightedPercentage + "%  |  Unavailable: " + result.unavailablePercentage + "%");
            score.setTextColor(getResources().getColor(R.color.green_dark));
            score.setTextSize(14);
            score.setTypeface(null, android.graphics.Typeface.BOLD);
            score.setPadding(dp(10), dp(8), dp(10), dp(8));
            score.setBackgroundResource(R.drawable.bg_score);
            LinearLayout.LayoutParams scoreParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            scoreParams.setMargins(0, dp(10), 0, 0);
            card.addView(score, scoreParams);

            TextView matched = new TextView(this);
            matched.setText(isArabic ? "الموجود عندك: " + displayIngredients(result.matchedIngredients) : "Available in your pantry: " + displayIngredients(result.matchedIngredients));
            matched.setTextColor(darkMode ? Color.WHITE : getResources().getColor(R.color.text_dark));
            matched.setTextSize(14);
            matched.setPadding(0, dp(8), 0, 0);
            card.addView(matched);

            List<String> missingList = result.missingIngredients;
            TextView missing = new TextView(this);
            if (missingList.isEmpty()) {
                missing.setText(isArabic ? "يمكنك تحضير هذه الوصفة الآن من مكوناتك." : "You can make this recipe now with your pantry.");
            } else {
                missing.setText(isArabic ? "المكونات غير المتوفرة: " + displayIngredients(missingList) : "Unavailable ingredients: " + displayIngredients(missingList));
            }
            missing.setTextColor(darkMode ? Color.rgb(210,210,210) : getResources().getColor(R.color.text_muted));
            missing.setTextSize(13);
            missing.setPadding(0, dp(6), 0, 0);
            card.addView(missing);

            TextView rule = new TextView(this);
            rule.setText(isArabic
                    ? "المعيار: 75% من نسبة المكونات المتوفرة الموزونة + 25% من اكتمال المكونات، مع خصم للمكونات الرئيسية غير المتوفرة."
                    : "Formula: 75% weighted availability + 25% ingredient completeness, with a penalty for missing main ingredients.");
            rule.setTextColor(darkMode ? Color.rgb(180,180,180) : getResources().getColor(R.color.text_muted));
            rule.setTextSize(12);
            rule.setPadding(0, dp(6), 0, 0);
            card.addView(rule);
        }

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER);
        actions.setPadding(0, dp(12), 0, 0);

        Button detailsButton = smallActionButton(isArabic ? "التفاصيل" : "Details");
        detailsButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { vibrate(v); showRecipeDetails(result); }
        });
        actions.addView(detailsButton, actionParams());

        Button favButton = smallActionButton(isFavorite(result.recipe) ? (isArabic ? "★ محفوظ" : "★ Saved") : (isArabic ? "☆ حفظ" : "☆ Save"));
        favButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { vibrate(v); toggleFavorite(result.recipe); Toast.makeText(MainActivity.this, isArabic ? "تم تحديث المفضلة" : "Favorites updated", Toast.LENGTH_SHORT).show(); }
        });
        actions.addView(favButton, actionParams());

        Button shareButton = smallActionButton(isArabic ? "مشاركة" : "Share");
        shareButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { vibrate(v); shareRecipe(result.recipe); }
        });
        actions.addView(shareButton, actionParams());

        card.addView(actions);
        resultsContainer.addView(card, cardParams);
    }

    private List<String> getMissingIngredients(Recipe recipe, List<String> matchedIngredients) {
        List<String> missing = new ArrayList<>();
        for (String ingredient : recipe.ingredients) {
            if (!matchedIngredients.contains(ingredient)) missing.add(ingredient);
        }
        return missing;
    }

    private Button smallActionButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setTextColor(getResources().getColor(R.color.green_primary));
        b.setBackgroundResource(R.drawable.bg_button_outline);
        return b;
    }

    private LinearLayout.LayoutParams actionParams() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(46), 1);
        params.setMargins(dp(3), 0, dp(3), 0);
        return params;
    }

    private void showRecipeDetails(final RecommendationResult result) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(12), dp(12), dp(4));
        box.setLayoutDirection(isArabic ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);

        TextView details = new TextView(this);
        details.setTextColor(darkMode ? Color.WHITE : getResources().getColor(R.color.text_dark));
        details.setTextSize(15);
        details.setLineSpacing(0, 1.18f);
        details.setPadding(0, dp(10), 0, 0);
        details.setTextDirection(isArabic ? View.TEXT_DIRECTION_RTL : View.TEXT_DIRECTION_LTR);
        List<String> missingList = result.missingIngredients;
        if (isArabic) {
            details.setText("الوقت: " + result.recipe.time + "\n" +
                    "الصعوبة: " + result.recipe.difficultyAr + "\n" +
                    "نسبة ملاءمة الوصفة: " + result.percentage + "%\n" +
                    "نسبة المتوفر الموزونة: " + result.availableWeightedPercentage + "%\n" +
                    "نسبة غير المتوفر: " + result.unavailablePercentage + "%\n" +
                    "المكونات المتوفرة: " + displayIngredients(result.matchedIngredients) + "\n" +
                    "المكونات الناقصة: " + (missingList.isEmpty() ? "لا يوجد" : displayIngredients(missingList)) + "\n\n" +
                    "المكونات المطلوبة:\n" + displayIngredients(result.recipe.ingredients) + "\n\n" +
                    "طريقة التحضير المفصلة:\n" + result.recipe.stepsAr);
        } else {
            details.setText("Time: " + result.recipe.time + "\n" +
                    "Difficulty: " + result.recipe.difficultyEn + "\n" +
                    "Recipe suitability: " + result.percentage + "%\n" +
                    "Weighted availability: " + result.availableWeightedPercentage + "%\n" +
                    "Unavailable ratio: " + result.unavailablePercentage + "%\n" +
                    "Available ingredients: " + displayIngredients(result.matchedIngredients) + "\n" +
                    "Missing ingredients: " + (missingList.isEmpty() ? "None" : displayIngredients(missingList)) + "\n\n" +
                    "Required Ingredients:\n" + displayIngredients(result.recipe.ingredients) + "\n\n" +
                    "Detailed Preparation:\n" + result.recipe.stepsEn);
        }
        box.addView(details);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(box);
        new AlertDialog.Builder(this)
                .setTitle(isArabic ? result.recipe.nameAr : result.recipe.nameEn)
                .setView(scroll)
                .setPositiveButton(isArabic ? "إغلاق" : "Close", null)
                .setNeutralButton(isArabic ? "مشاركة" : "Share", (dialog, which) -> shareRecipe(result.recipe))
                .show();
    }

    private void requestVoiceInput() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_RECORD_AUDIO_PERMISSION);
        } else launchVoiceRecognition();
    }

    private void launchVoiceRecognition() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, isArabic ? "ar-SA" : "en-US");
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, isArabic ? "اذكر المكونات المتوفرة لديك" : "Say your available ingredients");
        try { startActivityForResult(intent, REQUEST_SPEECH); }
        catch (ActivityNotFoundException e) { Toast.makeText(this, isArabic ? "ميزة التعرف الصوتي غير متاحة على هذا الجهاز." : "Speech recognition is not available on this device.", Toast.LENGTH_LONG).show(); }
    }

    private void showCameraFutureDialog() {
        new AlertDialog.Builder(this)
                .setTitle(isArabic ? "ميزة مستقبلية" : "Future Feature")
                .setMessage(isArabic
                        ? "التعرف على المكونات بالكاميرا غير مفعّل في النسخة الحالية. تم الإبقاء على الزر لعرض خطة التطوير المستقبلية، وسيتم تفعيل الميزة بعد جمع Dataset صور أكبر واختبار الدقة على صور حقيقية مستقلة. استخدم حاليًا الإدخال النصي أو الصوتي."
                        : "Camera-based ingredient recognition is not enabled in the current release. The button is retained to represent planned future development. The feature will be enabled after collecting a larger image dataset and validating accuracy on independent real-world images. Please use text or voice input for now.")
                .setPositiveButton(isArabic ? "حسنًا" : "OK", null)
                .show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_RECORD_AUDIO_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                launchVoiceRecognition();
            } else {
                Toast.makeText(this,
                        isArabic ? "لا يمكن استخدام الإدخال الصوتي دون السماح بالميكروفون."
                                : "Voice input requires microphone permission.",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> matches = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (matches != null && !matches.isEmpty()) {
                ingredientsInput.setText(matches.get(0));
                ingredientsInput.setSelection(ingredientsInput.getText().length());
                recommendRecipes();
            }
        }
    }

    private void showAboutDialog() {
        String text = isArabic ? getAboutTextAr() : getAboutTextEn();
        new AlertDialog.Builder(this)
                .setTitle(isArabic ? "عن Smart Chef" : "About Smart Chef")
                .setMessage(text)
                .setPositiveButton(isArabic ? "إغلاق" : "Close", null)
                .show();
    }

    private String getAboutTextAr() {
        return "Smart Chef هو تطبيق أندرويد لتوصية الوصفات اعتمادًا على المكونات المتوفرة لدى المستخدم. يدعم الإدخال النصي والإدخال الصوتي، ويعرض الوصفات مرتبة باستخدام معادلة ملاءمة تجمع بين نسبة المكونات المتوفرة الموزونة ونسبة المكونات غير المتوفرة، مع إعطاء المكونات الرئيسية أهمية أكبر. يوضّح التطبيق سبب كل توصية، والمكونات المتوفرة والناقصة، كما يدعم المفضلة والبحث الأخير والمشاركة والوضع الداكن واللغتين العربية والإنجليزية. زر الكاميرا موجود في الواجهة بوصفه ميزة مستقبلية فقط، وهو غير مفعّل في الإصدار الحالي إلى أن تتوفر بيانات صور أكبر واختبارات دقة مستقلة.\n\nالإصدار: 21.0 Stable Recommendation System.";
    }

    private String getAboutTextEn() {
        return "Smart Chef is an Android recipe-recommendation application based on the ingredients available to the user. It supports text and voice input and ranks recipes using a suitability formula that combines weighted ingredient availability with the unavailable-ingredient ratio, while assigning greater importance to main ingredients. The application explains each recommendation, shows available and missing ingredients, and supports favorites, recent searches, sharing, dark mode, Arabic, and English. The camera button remains visible as a future feature only and is not enabled in the current release until a larger image dataset and independent accuracy tests are available.\n\nVersion: 21.0 Stable Recommendation System.";
    }

    private void shareRecipe(Recipe recipe) {
        String text = (isArabic ? recipe.nameAr : recipe.nameEn) + "\n\n" +
                (isArabic ? "المكونات: " : "Ingredients: ") + displayIngredients(recipe.ingredients) + "\n\n" +
                (isArabic ? "طريقة التحضير:\n" + recipe.stepsAr : "Preparation:\n" + recipe.stepsEn);
        Intent sendIntent = new Intent(Intent.ACTION_SEND);
        sendIntent.setType("text/plain");
        sendIntent.putExtra(Intent.EXTRA_TEXT, text);
        startActivity(Intent.createChooser(sendIntent, isArabic ? "مشاركة الوصفة" : "Share recipe"));
    }

    private void toggleFavorite(Recipe recipe) {
        Set<String> fav = new LinkedHashSet<>(getFavorites());
        if (fav.contains(recipe.nameEn)) fav.remove(recipe.nameEn); else fav.add(recipe.nameEn);
        getPrefs().edit().putString("favorites", join(fav)).apply();
        showFavorites();
    }

    private boolean isFavorite(Recipe recipe) {
        return getFavorites().contains(recipe.nameEn);
    }

    private List<String> getFavorites() {
        return splitStored(getPrefs().getString("favorites", ""));
    }

    private void showFavorites() {
        resultsContainer.removeAllViews();
        resultsTitle.setText(isArabic ? "الوصفات المفضلة" : "Favorite Recipes");
        List<String> fav = getFavorites();
        if (fav.isEmpty()) {
            addMessageCard(isArabic ? "لا توجد وصفات في المفضلة حتى الآن. افتح أي وصفة واضغط المفضلة." : "No favorite recipes yet. Add recipes using the Favorite button.");
            return;
        }
        for (Recipe recipe : recipes) if (fav.contains(recipe.nameEn)) addRecipeCard(new RecommendationResult(recipe, new ArrayList<String>()), false);
    }

    private void saveRecentSearch(String input) {
        List<String> recent = getRecentSearches();
        recent.remove(input);
        recent.add(0, input);
        while (recent.size() > 5) recent.remove(recent.size() - 1);
        getPrefs().edit().putString("recent", join(recent)).apply();
    }

    private List<String> getRecentSearches() {
        return splitStored(getPrefs().getString("recent", ""));
    }

    private List<String> splitStored(String raw) {
        List<String> list = new ArrayList<>();
        if (raw == null || raw.trim().isEmpty()) return list;
        String[] parts = raw.split("\\|\\|", -1);
        for (String p : parts) if (!p.trim().isEmpty()) list.add(p.trim());
        return list;
    }

    private String join(Iterable<String> values) {
        StringBuilder b = new StringBuilder();
        for (String v : values) {
            if (b.length() > 0) b.append("||");
            b.append(v);
        }
        return b.toString();
    }

    private String displayIngredients(List<String> ingredients) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < ingredients.size(); i++) {
            if (i > 0) builder.append(isArabic ? "، " : ", ");
            builder.append(getIngredientLabel(ingredients.get(i)));
        }
        return builder.toString();
    }

    private String displayIngredients(String[] ingredients) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < ingredients.length; i++) {
            if (i > 0) builder.append(isArabic ? "، " : ", ");
            builder.append(getIngredientLabel(ingredients[i]));
        }
        return builder.toString();
    }

    private String getIngredientLabel(String key) {
        for (IngredientCategory item : ingredientCategories) if (item.key.equals(key)) return isArabic ? item.nameAr : item.nameEn;
        if (key.equals("banana")) return isArabic ? "موز" : "Banana";
        if (key.equals("milk")) return isArabic ? "حليب" : "Milk";
        if (key.equals("lettuce")) return isArabic ? "خس" : "Lettuce";
        if (key.equals("lemon")) return isArabic ? "ليمون" : "Lemon";
        if (key.equals("oil")) return isArabic ? "زيت" : "Oil";
        if (key.equals("salt")) return isArabic ? "ملح" : "Salt";
        if (key.equals("pepper")) return isArabic ? "فلفل" : "Pepper";
        if (key.equals("water")) return isArabic ? "ماء" : "Water";
        if (key.equals("spices")) return isArabic ? "بهارات" : "Spices";
        if (key.equals("eggplant")) return isArabic ? "باذنجان" : "Eggplant";
        if (key.equals("molokhia")) return isArabic ? "ملوخية" : "Molokhia";
        if (key.equals("bread")) return isArabic ? "خبز" : "Bread";
        if (key.equals("sumac")) return isArabic ? "سماق" : "Sumac";
        if (key.equals("fish")) return isArabic ? "سمك" : "Fish";
        if (key.equals("chickpeas")) return isArabic ? "حمص" : "Chickpeas";
        if (key.equals("tahini")) return isArabic ? "طحينة" : "Tahini";
        if (key.equals("zucchini")) return isArabic ? "كوسا" : "Zucchini";
        if (key.equals("sugar")) return isArabic ? "سكر" : "Sugar";
        if (key.equals("cinnamon")) return isArabic ? "قرفة" : "Cinnamon";
        return key;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
