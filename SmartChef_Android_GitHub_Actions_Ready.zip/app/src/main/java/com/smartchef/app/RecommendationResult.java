package com.smartchef.app;

import java.util.ArrayList;
import java.util.List;

/**
 * Immutable recommendation output used by the UI.
 *
 * percentage: final suitability score after combining available and unavailable ratios.
 * availableWeightedPercentage: weighted coverage of recipe ingredients available to the user.
 * unavailablePercentage: count-based percentage of recipe ingredients still missing.
 */
public class RecommendationResult {
    public final Recipe recipe;
    public final List<String> matchedIngredients;
    public final List<String> missingIngredients;
    public final int score;
    public final int percentage;
    public final int availableWeightedPercentage;
    public final int unavailablePercentage;

    public RecommendationResult(Recipe recipe, List<String> matchedIngredients) {
        this(recipe, matchedIngredients, findMissing(recipe, matchedIngredients), 0, 0, 0, 0);
    }

    public RecommendationResult(
            Recipe recipe,
            List<String> matchedIngredients,
            List<String> missingIngredients,
            int score,
            int percentage,
            int availableWeightedPercentage,
            int unavailablePercentage
    ) {
        this.recipe = recipe;
        this.matchedIngredients = new ArrayList<>(matchedIngredients);
        this.missingIngredients = new ArrayList<>(missingIngredients);
        this.score = score;
        this.percentage = percentage;
        this.availableWeightedPercentage = availableWeightedPercentage;
        this.unavailablePercentage = unavailablePercentage;
    }

    private static List<String> findMissing(Recipe recipe, List<String> matchedIngredients) {
        List<String> missing = new ArrayList<>();
        for (String ingredient : recipe.ingredients) {
            if (!matchedIngredients.contains(ingredient)) missing.add(ingredient);
        }
        return missing;
    }
}
