package com.smartchef.app;

import java.util.List;

public class RecommendationResult {
    public final Recipe recipe;
    public final List<String> matchedIngredients;
    public final int score;
    public final int percentage;

    public RecommendationResult(Recipe recipe, List<String> matchedIngredients) {
        this(recipe, matchedIngredients, matchedIngredients.size(), Math.round((matchedIngredients.size() * 100f) / recipe.ingredients.length));
    }

    public RecommendationResult(Recipe recipe, List<String> matchedIngredients, int score, int percentage) {
        this.recipe = recipe;
        this.matchedIngredients = matchedIngredients;
        this.score = score;
        this.percentage = percentage;
    }
}
