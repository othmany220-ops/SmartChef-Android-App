package com.smartchef.app;

/** One ranked ingredient suggestion returned by the secure vision backend. */
public class AICandidate {
    public final String ingredientKey;
    public final String ingredientNameEn;
    public final String ingredientNameAr;
    public final String certainty;

    public AICandidate(String ingredientKey, String ingredientNameEn, String ingredientNameAr, String certainty) {
        this.ingredientKey = ingredientKey == null ? "" : ingredientKey;
        this.ingredientNameEn = ingredientNameEn == null ? "Unknown" : ingredientNameEn;
        this.ingredientNameAr = ingredientNameAr == null ? "غير معروف" : ingredientNameAr;
        this.certainty = normalizeCertainty(certainty);
    }

    private static String normalizeCertainty(String value) {
        String v = value == null ? "low" : value.trim().toLowerCase();
        if ("high".equals(v) || "medium".equals(v) || "low".equals(v)) return v;
        return "low";
    }
}
