package com.smartchef.app;

/** One ranked ingredient suggestion returned by the secure vision backend. */
public class AICandidate {
    public final String ingredientKey;
    public final String ingredientNameEn;
    public final String ingredientNameAr;
    public final int confidence;

    public AICandidate(String ingredientKey, String ingredientNameEn, String ingredientNameAr, int confidence) {
        this.ingredientKey = ingredientKey;
        this.ingredientNameEn = ingredientNameEn;
        this.ingredientNameAr = ingredientNameAr;
        this.confidence = confidence;
    }
}
