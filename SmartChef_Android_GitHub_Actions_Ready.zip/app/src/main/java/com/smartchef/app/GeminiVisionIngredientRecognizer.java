package com.smartchef.app;

import android.graphics.Bitmap;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Cloud multimodal ingredient recognition using the Gemini REST API.
 *
 * This recognizer is designed for the academic demo version of Smart Chef:
 * - it asks Gemini to select only from the ingredient classes supported by the app;
 * - it returns ranked candidates with confidence scores;
 * - the UI still requires user confirmation before adding an ingredient.
 *
 * The recommended production path is BackendVisionIngredientRecognizer, where the API key
 * stays on the backend. This class is kept only as an optional GitHub-Secret fallback.
 */
public final class GeminiVisionIngredientRecognizer {
    public interface Callback {
        void onResult(AIIngredientResult result);
        void onError(String message);
    }

    private static final String[] MODEL_CANDIDATES = {
            "gemini-2.5-flash",
            "gemini-2.0-flash"
    };

    private static final String SUPPORTED_KEYS =
            "rice, onion, potato, parsley, egg, tuna, garlic, cheese, carrot, cucumber, " +
            "chicken, yogurt, tomato, red_lentils, beef, pasta";

    private GeminiVisionIngredientRecognizer() { }

    public static void analyze(Bitmap bitmap, String apiKey, Callback callback) {
        if (bitmap == null) {
            callback.onError("No image was provided");
            return;
        }
        if (apiKey == null || apiKey.trim().isEmpty()) {
            callback.onError("Gemini API key is missing");
            return;
        }

        new Thread(() -> {
            String lastError = "Cloud AI request failed";
            for (String model : MODEL_CANDIDATES) {
                try {
                    AIIngredientResult result = requestModel(bitmap, apiKey.trim(), model);
                    callback.onResult(result);
                    return;
                } catch (Exception e) {
                    lastError = e.getMessage() == null ? e.toString() : e.getMessage();
                }
            }
            callback.onError(lastError);
        }).start();
    }

    private static AIIngredientResult requestModel(Bitmap source, String apiKey, String model) throws Exception {
        Bitmap image = scaleDown(source, 1024);
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        image.compress(Bitmap.CompressFormat.JPEG, 84, stream);
        String encodedImage = Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP);

        String prompt =
                "You are the Smart Chef visual ingredient recognition module. " +
                "Analyze the image and identify visible cooking ingredients. " +
                "Choose candidates ONLY from this supported key list: " + SUPPORTED_KEYS + ". " +
                "Return the most likely visible ingredient first. If several supported ingredients are visible, rank them. " +
                "Do not guess hidden ingredients, do not identify the recipe, and do not choose unsupported items. " +
                "Return exactly three ranked candidates when possible. " +
                "Confidence must be an integer from 0 to 100 and should be conservative. " +
                "If none of the supported ingredients is clearly visible, use key unknown with low confidence. " +
                "Return JSON only in this exact structure: " +
                "{\"candidates\":[{\"key\":\"cucumber\",\"confidence\":96}," +
                "{\"key\":\"parsley\",\"confidence\":3},{\"key\":\"tomato\",\"confidence\":1}]," +
                "\"visual_reason\":\"short reason\"}.";

        JSONObject inlineData = new JSONObject();
        inlineData.put("mime_type", "image/jpeg");
        inlineData.put("data", encodedImage);

        JSONArray parts = new JSONArray();
        parts.put(new JSONObject().put("text", prompt));
        parts.put(new JSONObject().put("inline_data", inlineData));

        JSONArray contents = new JSONArray();
        contents.put(new JSONObject().put("parts", parts));

        JSONObject generationConfig = new JSONObject();
        generationConfig.put("temperature", 0.1);
        generationConfig.put("response_mime_type", "application/json");

        JSONObject body = new JSONObject();
        body.put("contents", contents);
        body.put("generationConfig", generationConfig);

        String endpoint = "https://generativelanguage.googleapis.com/v1beta/models/" + model +
                ":generateContent?key=" + URLEncoder.encode(apiKey, "UTF-8");
        HttpURLConnection connection = (HttpURLConnection) new URL(endpoint).openConnection();
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(20000);
        connection.setReadTimeout(45000);
        connection.setDoOutput(true);
        connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        connection.setRequestProperty("Accept", "application/json");

        try (OutputStream output = connection.getOutputStream()) {
            output.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }

        int status = connection.getResponseCode();
        String response = readStream(status >= 200 && status < 300
                ? connection.getInputStream() : connection.getErrorStream());
        connection.disconnect();

        if (status < 200 || status >= 300) {
            throw new IllegalStateException("Gemini " + model + " returned HTTP " + status + ": " + shorten(response));
        }

        return parseResponse(response, model);
    }

    private static AIIngredientResult parseResponse(String response, String model) throws JSONException {
        JSONObject root = new JSONObject(response);
        JSONArray candidates = root.optJSONArray("candidates");
        if (candidates == null || candidates.length() == 0) {
            throw new JSONException("Gemini response did not contain candidates");
        }

        JSONObject content = candidates.getJSONObject(0).optJSONObject("content");
        JSONArray parts = content == null ? null : content.optJSONArray("parts");
        if (parts == null || parts.length() == 0) {
            throw new JSONException("Gemini response did not contain text");
        }

        String text = parts.getJSONObject(0).optString("text", "").trim();
        text = stripCodeFence(text);
        JSONObject prediction = new JSONObject(text);
        JSONArray ranked = prediction.optJSONArray("candidates");
        if (ranked == null) throw new JSONException("Gemini JSON did not contain ranked candidates");

        List<AICandidate> output = new ArrayList<>();
        Set<String> used = new LinkedHashSet<>();
        for (int i = 0; i < ranked.length(); i++) {
            JSONObject item = ranked.optJSONObject(i);
            if (item == null) continue;
            String key = normalizeKey(item.optString("key", ""));
            int confidence = normalizeConfidence(item.optDouble("confidence", 0));
            if (key.isEmpty() || used.contains(key)) continue;
            used.add(key);
            output.add(createCandidate(key, confidence));
        }

        Collections.sort(output, new Comparator<AICandidate>() {
            @Override public int compare(AICandidate a, AICandidate b) {
                return Integer.compare(b.confidence, a.confidence);
            }
        });
        if (output.size() > 3) output = new ArrayList<>(output.subList(0, 3));

        String reason = prediction.optString("visual_reason", "");
        return new AIIngredientResult(output, "Gemini Vision Cloud (" + model + ")", reason);
    }

    private static Bitmap scaleDown(Bitmap bitmap, int maxSide) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int largest = Math.max(width, height);
        if (largest <= maxSide) return bitmap;
        float ratio = maxSide / (float) largest;
        return Bitmap.createScaledBitmap(bitmap, Math.max(1, Math.round(width * ratio)),
                Math.max(1, Math.round(height * ratio)), true);
    }

    private static String readStream(InputStream input) throws Exception {
        if (input == null) return "";
        StringBuilder builder = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) builder.append(line);
        }
        return builder.toString();
    }

    private static String stripCodeFence(String text) {
        String cleaned = text.trim();
        if (cleaned.startsWith("```")) {
            int firstNewLine = cleaned.indexOf('\n');
            int lastFence = cleaned.lastIndexOf("```");
            if (firstNewLine >= 0 && lastFence > firstNewLine) {
                cleaned = cleaned.substring(firstNewLine + 1, lastFence).trim();
            }
        }
        return cleaned;
    }

    private static int normalizeConfidence(double value) {
        if (value >= 0 && value <= 1.0) value *= 100.0;
        return (int) Math.max(0, Math.min(100, Math.round(value)));
    }

    private static String normalizeKey(String input) {
        String key = input == null ? "" : input.trim().toLowerCase();
        key = key.replace('-', '_').replace(' ', '_');
        if (key.equals("basmati_rice") || key.equals("rice")) return "rice";
        if (key.equals("eggs")) return "egg";
        if (key.equals("meat") || key.equals("lamb") || key.equals("beef")) return "beef";
        if (key.equals("macaroni") || key.equals("spaghetti") || key.equals("pasta")) return "pasta";
        if (key.equals("red_lentil") || key.equals("lentils") || key.equals("red_lentils")) return "red_lentils";
        if (key.equals("unknown") || key.equals("none") || key.equals("unsupported")) return "unknown";
        if (SUPPORTED_KEYS.contains(key)) return key;
        return key;
    }

    private static AICandidate createCandidate(String key, int confidence) {
        switch (key) {
            case "rice": return new AICandidate(key, "Basmati Rice", "أرز بسمتي", confidence);
            case "onion": return new AICandidate(key, "Onion", "بصل", confidence);
            case "potato": return new AICandidate(key, "Potato", "بطاطا", confidence);
            case "parsley": return new AICandidate(key, "Parsley", "بقدونس", confidence);
            case "egg": return new AICandidate(key, "Eggs", "بيض", confidence);
            case "tuna": return new AICandidate(key, "Tuna", "تونة", confidence);
            case "garlic": return new AICandidate(key, "Garlic", "ثوم", confidence);
            case "cheese": return new AICandidate(key, "Cheese", "جبن", confidence);
            case "carrot": return new AICandidate(key, "Carrot", "جزر", confidence);
            case "cucumber": return new AICandidate(key, "Cucumber", "خيار", confidence);
            case "chicken": return new AICandidate(key, "Chicken", "دجاج", confidence);
            case "yogurt": return new AICandidate(key, "Yogurt", "لبن / زبادي", confidence);
            case "tomato": return new AICandidate(key, "Tomato", "طماطم", confidence);
            case "red_lentils": return new AICandidate(key, "Red Lentils", "عدس أحمر", confidence);
            case "beef": return new AICandidate(key, "Meat", "لحم", confidence);
            case "pasta": return new AICandidate(key, "Pasta / Macaroni", "معكرونة", confidence);
            default: return new AICandidate("unknown", "Unknown / Unsupported", "غير معروف / غير مدعوم", confidence);
        }
    }

    private static String shorten(String value) {
        if (value == null) return "";
        return value.length() <= 350 ? value : value.substring(0, 350) + "...";
    }
}
