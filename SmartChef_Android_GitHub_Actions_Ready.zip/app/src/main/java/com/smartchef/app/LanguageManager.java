package com.smartchef.app;

import android.content.Context;
import android.content.SharedPreferences;

public class LanguageManager {
    private static final String PREF_NAME = "smart_chef_language";
    private static final String KEY_ARABIC = "arabic";

    public static boolean isArabic(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return prefs.getBoolean(KEY_ARABIC, true);
    }

    public static void setArabic(Context context, boolean arabic) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_ARABIC, arabic)
                .apply();
    }
}
