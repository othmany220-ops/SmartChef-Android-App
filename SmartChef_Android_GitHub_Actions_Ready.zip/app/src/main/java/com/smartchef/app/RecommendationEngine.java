package com.smartchef.app;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class RecommendationEngine {
    private static final Map<String, List<String>> SYNONYMS = new LinkedHashMap<>();
    private static final Set<String> MAIN_INGREDIENTS = new HashSet<>();

    static {
        SYNONYMS.put("egg", java.util.Arrays.asList("egg", "eggs", "بيض", "بيضة", "البيض"));
        SYNONYMS.put("tomato", java.util.Arrays.asList("tomato", "tomatoes", "طماطم", "بندورة", "بندوره", "طماطة"));
        SYNONYMS.put("cheese", java.util.Arrays.asList("cheese", "جبن", "جبنة", "جبنه"));
        SYNONYMS.put("chicken", java.util.Arrays.asList("chicken", "دجاج", "جاج", "فراخ", "فرخة", "لحم دجاج"));
        SYNONYMS.put("rice", java.util.Arrays.asList("rice", "basmati", "أرز", "ارز", "رز"));
        SYNONYMS.put("pasta", java.util.Arrays.asList("pasta", "macaroni", "معكرونة", "مكرونة", "باستا"));
        SYNONYMS.put("onion", java.util.Arrays.asList("onion", "onions", "بصل", "بصلة"));
        SYNONYMS.put("garlic", java.util.Arrays.asList("garlic", "ثوم", "توم"));
        SYNONYMS.put("potato", java.util.Arrays.asList("potato", "potatoes", "بطاطا", "بطاطس"));
        SYNONYMS.put("carrot", java.util.Arrays.asList("carrot", "carrots", "جزر"));
        SYNONYMS.put("cucumber", java.util.Arrays.asList("cucumber", "cucumbers", "خيار"));
        SYNONYMS.put("parsley", java.util.Arrays.asList("parsley", "بقدونس", "معدنوس"));
        SYNONYMS.put("tuna", java.util.Arrays.asList("tuna", "تونة", "تونه"));
        SYNONYMS.put("yogurt", java.util.Arrays.asList("yogurt", "yoghurt", "زبادي", "لبن", "جميد", "لبن جميد", "لبن رايب"));
        SYNONYMS.put("red_lentils", java.util.Arrays.asList("red lentils", "lentils", "عدس", "عدس احمر", "عدس أحمر"));
        SYNONYMS.put("beef", java.util.Arrays.asList("beef", "meat", "لحم", "لحمة", "لحمه", "لحم غنم", "لحم بقري"));
        SYNONYMS.put("oil", java.util.Arrays.asList("oil", "زيت", "زيت زيتون"));
        SYNONYMS.put("salt", java.util.Arrays.asList("salt", "ملح"));
        SYNONYMS.put("pepper", java.util.Arrays.asList("pepper", "فلفل", "فلفل اسود", "فلفل أسود"));
        SYNONYMS.put("water", java.util.Arrays.asList("water", "ماء", "مي"));
        SYNONYMS.put("banana", java.util.Arrays.asList("banana", "bananas", "موز", "الموز"));
        SYNONYMS.put("milk", java.util.Arrays.asList("milk", "حليب", "لبن حليب"));
        SYNONYMS.put("lettuce", java.util.Arrays.asList("lettuce", "خس"));
        SYNONYMS.put("lemon", java.util.Arrays.asList("lemon", "ليمون", "حامض"));
        SYNONYMS.put("spices", java.util.Arrays.asList("spices", "بهارات", "بهار", "بهارات كبسة", "بهار مشكل", "كركم", "هيل", "قرفة", "كبسة"));
        SYNONYMS.put("eggplant", java.util.Arrays.asList("eggplant", "باذنجان", "باذنجانه"));
        SYNONYMS.put("molokhia", java.util.Arrays.asList("molokhia", "ملوخية", "ملوخيه"));
        SYNONYMS.put("bread", java.util.Arrays.asList("bread", "خبز", "شراك", "خبز شراك", "رقاق"));
        SYNONYMS.put("sumac", java.util.Arrays.asList("sumac", "سماق"));
        SYNONYMS.put("fish", java.util.Arrays.asList("fish", "سمك", "سمكة"));
        SYNONYMS.put("chickpeas", java.util.Arrays.asList("chickpeas", "حمص", "حب حمص"));
        SYNONYMS.put("tahini", java.util.Arrays.asList("tahini", "طحينة", "طحينيه"));
        SYNONYMS.put("zucchini", java.util.Arrays.asList("zucchini", "كوسا", "كوسه"));
        SYNONYMS.put("sugar", java.util.Arrays.asList("sugar", "سكر"));
        SYNONYMS.put("cinnamon", java.util.Arrays.asList("cinnamon", "قرفة", "قرفه"));

        MAIN_INGREDIENTS.add("beef");
        MAIN_INGREDIENTS.add("chicken");
        MAIN_INGREDIENTS.add("rice");
        MAIN_INGREDIENTS.add("pasta");
        MAIN_INGREDIENTS.add("fish");
        MAIN_INGREDIENTS.add("egg");
        MAIN_INGREDIENTS.add("potato");
        MAIN_INGREDIENTS.add("red_lentils");
        MAIN_INGREDIENTS.add("tuna");
        MAIN_INGREDIENTS.add("yogurt");
        MAIN_INGREDIENTS.add("chickpeas");
        MAIN_INGREDIENTS.add("zucchini");
        MAIN_INGREDIENTS.add("milk");
    }

    public static List<RecommendationResult> recommend(String rawInput, List<Recipe> recipes) {
        List<String> userIngredients = extractIngredients(rawInput);
        List<RecommendationResult> results = new ArrayList<>();

        for (Recipe recipe : recipes) {
            List<String> matched = new ArrayList<>();
            int totalWeight = 0;
            int matchedWeight = 0;
            boolean recipeHasMain = false;
            boolean matchedMain = false;

            for (String ingredient : recipe.ingredients) {
                int weight = weightOf(ingredient);
                totalWeight += weight;
                if (isMain(ingredient)) recipeHasMain = true;
                if (userIngredients.contains(ingredient)) {
                    matched.add(ingredient);
                    matchedWeight += weight;
                    if (isMain(ingredient)) matchedMain = true;
                }
            }

            if (matched.isEmpty()) continue;
            if (recipeHasMain && !matchedMain) continue;

            int percentage = Math.round((matchedWeight * 100f) / Math.max(totalWeight, 1));
            if (percentage < 50 && matched.size() < 3) continue;
            int score = matchedWeight * 10 + matched.size();
            results.add(new RecommendationResult(recipe, matched, score, percentage));
        }

        Collections.sort(results, new Comparator<RecommendationResult>() {
            @Override
            public int compare(RecommendationResult a, RecommendationResult b) {
                if (b.percentage != a.percentage) return b.percentage - a.percentage;
                return b.score - a.score;
            }
        });
        return results;
    }

    private static int weightOf(String ingredient) {
        if (isMain(ingredient)) return 3;
        if (ingredient.equals("spices") || ingredient.equals("salt") || ingredient.equals("pepper") || ingredient.equals("oil") || ingredient.equals("water")) return 1;
        return 2;
    }

    private static boolean isMain(String ingredient) {
        return MAIN_INGREDIENTS.contains(ingredient);
    }

    public static List<String> extractIngredients(String rawInput) {
        String input = normalize(rawInput);
        List<String> found = new ArrayList<>();
        for (Map.Entry<String, List<String>> entry : SYNONYMS.entrySet()) {
            for (String synonym : entry.getValue()) {
                if (containsIngredient(input, normalize(synonym))) {
                    found.add(entry.getKey());
                    break;
                }
            }
        }
        return found;
    }

    private static boolean containsIngredient(String input, String ingredient) {
        if (input == null || input.trim().isEmpty()) return false;
        String paddedInput = " " + input + " ";
        String paddedIngredient = " " + ingredient + " ";
        if (paddedInput.contains(paddedIngredient)) return true;
        if (ingredient.matches(".*[\\u0600-\\u06FF].*")) return input.contains(ingredient);
        return false;
    }

    public static String normalize(String text) {
        if (text == null) return "";
        String value = text.toLowerCase(Locale.ROOT)
                .replace("،", " ")
                .replace(",", " ")
                .replace(".", " ")
                .replace(";", " ")
                .replace(":", " ")
                .replace("/", " ")
                .replace(" and ", " ")
                .replace(" with ", " ")
                .replace(" و", " ")
                .trim();
        value = Normalizer.normalize(value, Normalizer.Form.NFKD).replaceAll("\\p{M}", "");
        return value.replaceAll("\\s+", " ");
    }
}
