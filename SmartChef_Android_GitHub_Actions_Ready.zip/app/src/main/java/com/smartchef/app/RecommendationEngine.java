package com.smartchef.app;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Content-based recipe recommendation using a documented weighted ingredient score. */
public class RecommendationEngine {
    private static final Map<String, List<String>> SYNONYMS = new LinkedHashMap<>();
    private static final Set<String> MAIN_INGREDIENTS = new HashSet<>();
    private static final Map<String, Set<String>> ESSENTIALS = new LinkedHashMap<>();
    private static final Map<String, Set<String>> SIGNATURES = new LinkedHashMap<>();

    static {
        SYNONYMS.put("egg", Arrays.asList("egg", "eggs", "بيض", "بيضة", "البيض"));
        SYNONYMS.put("tomato", Arrays.asList("tomato", "tomatoes", "طماطم", "بندورة", "بندوره", "طماطة"));
        SYNONYMS.put("cheese", Arrays.asList("cheese", "جبن", "جبنة", "جبنه"));
        SYNONYMS.put("chicken", Arrays.asList("chicken", "دجاج", "جاج", "فراخ", "فرخة", "لحم دجاج"));
        SYNONYMS.put("rice", Arrays.asList("rice", "basmati", "أرز", "ارز", "رز"));
        SYNONYMS.put("pasta", Arrays.asList("pasta", "macaroni", "معكرونة", "مكرونة", "باستا", "لازانيا"));
        SYNONYMS.put("onion", Arrays.asList("onion", "onions", "بصل", "بصلة"));
        SYNONYMS.put("garlic", Arrays.asList("garlic", "ثوم", "توم"));
        SYNONYMS.put("potato", Arrays.asList("potato", "potatoes", "بطاطا", "بطاطس"));
        SYNONYMS.put("carrot", Arrays.asList("carrot", "carrots", "جزر"));
        SYNONYMS.put("cucumber", Arrays.asList("cucumber", "cucumbers", "خيار"));
        SYNONYMS.put("parsley", Arrays.asList("parsley", "بقدونس", "معدنوس"));
        SYNONYMS.put("tuna", Arrays.asList("tuna", "تونة", "تونه"));
        SYNONYMS.put("yogurt", Arrays.asList("yogurt", "yoghurt", "زبادي", "لبن", "جميد", "لبن جميد", "لبن رايب"));
        SYNONYMS.put("red_lentils", Arrays.asList("red lentils", "lentils", "عدس", "عدس احمر", "عدس أحمر"));
        SYNONYMS.put("beef", Arrays.asList("beef", "meat", "lamb", "لحم", "لحمة", "لحمه", "لحم غنم", "لحم بقري"));
        SYNONYMS.put("oil", Arrays.asList("oil", "زيت", "زيت زيتون"));
        SYNONYMS.put("salt", Arrays.asList("salt", "ملح"));
        SYNONYMS.put("pepper", Arrays.asList("pepper", "فلفل", "فلفل اسود", "فلفل أسود"));
        SYNONYMS.put("water", Arrays.asList("water", "ماء", "مي"));
        SYNONYMS.put("banana", Arrays.asList("banana", "bananas", "موز", "الموز"));
        SYNONYMS.put("milk", Arrays.asList("milk", "حليب", "لبن حليب"));
        SYNONYMS.put("lettuce", Arrays.asList("lettuce", "خس"));
        SYNONYMS.put("lemon", Arrays.asList("lemon", "ليمون", "حامض"));
        SYNONYMS.put("spices", Arrays.asList("spices", "بهارات", "بهار", "بهارات كبسة", "بهار مشكل", "كركم", "هيل", "كبسة"));
        SYNONYMS.put("eggplant", Arrays.asList("eggplant", "باذنجان", "باذنجانه"));
        SYNONYMS.put("molokhia", Arrays.asList("molokhia", "ملوخية", "ملوخيه"));
        SYNONYMS.put("bread", Arrays.asList("bread", "خبز", "شراك", "خبز شراك", "رقاق"));
        SYNONYMS.put("sumac", Arrays.asList("sumac", "سماق"));
        SYNONYMS.put("fish", Arrays.asList("fish", "سمك", "سمكة"));
        SYNONYMS.put("chickpeas", Arrays.asList("chickpeas", "حمص", "حب حمص"));
        SYNONYMS.put("tahini", Arrays.asList("tahini", "طحينة", "طحينيه"));
        SYNONYMS.put("zucchini", Arrays.asList("zucchini", "كوسا", "كوسه"));
        SYNONYMS.put("sugar", Arrays.asList("sugar", "سكر"));
        SYNONYMS.put("cinnamon", Arrays.asList("cinnamon", "قرفة", "قرفه"));

        MAIN_INGREDIENTS.addAll(Arrays.asList("beef", "chicken", "rice", "pasta", "fish", "egg", "potato",
                "red_lentils", "tuna", "yogurt", "chickpeas", "zucchini", "milk"));

        essential("Jordanian Mansaf", "beef", "rice", "yogurt");
        essential("Chicken Kabsa", "chicken", "rice");
        essential("Cheese Omelette", "egg");
        essential("Tomato Shakshuka", "egg", "tomato");
        essential("Chicken Salad", "chicken");
        essential("Tomato Macaroni", "pasta", "tomato");
        essential("Red Lentil Soup", "red_lentils");
        essential("Chicken Rice Bowl", "chicken", "rice");
        essential("Tuna Cucumber Salad", "tuna", "cucumber");
        essential("Yogurt Cucumber Salad", "yogurt", "cucumber");
        essential("Potato Cheese Bake", "potato", "cheese");
        essential("Beef Potato Stew", "beef", "potato");
        essential("Garlic Chicken Plate", "chicken");
        essential("Vegetable Macaroni", "pasta");
        essential("Banana Milk Smoothie", "banana", "milk");
        essential("Fresh Garden Salad", "cucumber", "tomato");
        essential("Chicken Maqluba", "chicken", "rice", "eggplant");
        essential("Chicken Molokhia", "chicken", "molokhia");
        essential("Palestinian Musakhan", "chicken", "onion", "bread", "sumac");
        essential("Kofta Potato Tray", "beef", "potato");
        essential("Chicken Mandi", "chicken", "rice");
        essential("Mujadara", "red_lentils", "rice");
        essential("Sayadieh Fish Rice", "fish", "rice");
        essential("Fattet Hummus", "chickpeas", "bread", "yogurt");
        essential("Stuffed Zucchini", "zucchini", "rice", "beef");
        essential("Chicken Shawarma Wrap", "chicken", "bread");
        essential("Lasagna", "pasta", "beef", "cheese");
        essential("Chicken Alfredo Pasta", "chicken", "pasta");
        essential("Rice Pudding", "rice", "milk");

        signature("Jordanian Mansaf", "yogurt");
        signature("Chicken Kabsa", "tomato", "spices");
        signature("Chicken Maqluba", "eggplant");
        signature("Chicken Molokhia", "molokhia");
        signature("Palestinian Musakhan", "sumac", "bread");
        signature("Chicken Mandi", "spices");
        signature("Sayadieh Fish Rice", "fish", "onion");
        signature("Fattet Hummus", "chickpeas", "tahini");
        signature("Chicken Shawarma Wrap", "yogurt", "spices");
        signature("Lasagna", "beef", "cheese", "tomato");
        signature("Chicken Alfredo Pasta", "milk", "cheese", "garlic");
        signature("Rice Pudding", "milk", "sugar", "cinnamon");
    }

    private static void essential(String recipeName, String... ingredients) {
        ESSENTIALS.put(recipeName, new LinkedHashSet<>(Arrays.asList(ingredients)));
    }

    private static void signature(String recipeName, String... ingredients) {
        SIGNATURES.put(recipeName, new LinkedHashSet<>(Arrays.asList(ingredients)));
    }

    public static List<RecommendationResult> recommend(String rawInput, List<Recipe> recipes) {
        List<String> userIngredients = extractIngredients(rawInput);
        Set<String> userSet = new LinkedHashSet<>(userIngredients);
        List<RecommendationResult> results = new ArrayList<>();

        for (Recipe recipe : recipes) {
            Set<String> essentials = ESSENTIALS.get(recipe.nameEn);
            if (essentials != null && !userSet.containsAll(essentials)) continue;

            List<String> matched = new ArrayList<>();
            int totalWeight = 0;
            int matchedWeight = 0;

            for (String ingredient : recipe.ingredients) {
                int weight = weightOf(ingredient);
                totalWeight += weight;
                if (userSet.contains(ingredient)) {
                    matched.add(ingredient);
                    matchedWeight += weight;
                }
            }

            if (matched.isEmpty()) continue;
            int percentage = Math.round((matchedWeight * 100f) / Math.max(totalWeight, 1));
            if (percentage < 45) continue;
            int signatureBonus = 0;
            Set<String> signatures = SIGNATURES.get(recipe.nameEn);
            if (signatures != null) {
                for (String signature : signatures) if (userSet.contains(signature)) signatureBonus += 180;
            }
            int score = matchedWeight * 100 + matched.size() * 10 + signatureBonus - (recipe.ingredients.length - matched.size());
            results.add(new RecommendationResult(recipe, matched, score, percentage));
        }

        Collections.sort(results, new Comparator<RecommendationResult>() {
            @Override public int compare(RecommendationResult a, RecommendationResult b) {
                if (b.score != a.score) return b.score - a.score;
                return b.percentage - a.percentage;
            }
        });
        return results;
    }

    private static int weightOf(String ingredient) {
        if (MAIN_INGREDIENTS.contains(ingredient)) return 5;
        if (ingredient.equals("spices") || ingredient.equals("salt") || ingredient.equals("pepper") ||
                ingredient.equals("oil") || ingredient.equals("water")) return 1;
        return 2;
    }

    public static List<String> extractIngredients(String rawInput) {
        String input = normalize(rawInput);
        LinkedHashSet<String> found = new LinkedHashSet<>();
        for (Map.Entry<String, List<String>> entry : SYNONYMS.entrySet()) {
            for (String synonym : entry.getValue()) {
                if (containsIngredient(input, normalize(synonym))) {
                    found.add(entry.getKey());
                    break;
                }
            }
        }
        return new ArrayList<>(found);
    }

    private static boolean containsIngredient(String input, String ingredient) {
        if (input == null || input.trim().isEmpty() || ingredient.isEmpty()) return false;
        String paddedInput = " " + input + " ";
        String paddedIngredient = " " + ingredient + " ";
        return paddedInput.contains(paddedIngredient);
    }

    public static String normalize(String text) {
        if (text == null) return "";
        String value = text.toLowerCase(Locale.ROOT)
                .replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")
                .replace("ة", "ه").replace("ى", "ي")
                .replace("ؤ", "و").replace("ئ", "ي")
                .replace("،", " ").replace(",", " ").replace(".", " ")
                .replace(";", " ").replace(":", " ").replace("/", " ")
                .replace("-", " ").replace("_", " ")
                .replace(" and ", " ").replace(" with ", " ")
                .replaceAll("(^|\\s)و(?=\\S)", "$1")
                .trim();
        value = Normalizer.normalize(value, Normalizer.Form.NFKD).replaceAll("\\p{M}", "");
        return value.replaceAll("[^\\p{L}\\p{N}]+", " ").replaceAll("\\s+", " ").trim();
    }
}
