package com.smartchef.app;

import android.graphics.Bitmap;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Sends a clear image to the secure SmartChef backend.
 * The OpenAI API key is stored only on the backend and is never embedded in the APK.
 */
public final class BackendVisionIngredientRecognizer {
    public interface Callback {
        void onResult(AIIngredientResult result);
        void onError(String message);
    }

    private BackendVisionIngredientRecognizer() { }

    public static void analyze(Bitmap bitmap, String backendUrl, Callback callback) {
        if (callback == null) return;
        if (bitmap == null) {
            callback.onError("No image was provided");
            return;
        }
        if (backendUrl == null || backendUrl.trim().isEmpty()) {
            callback.onError("Vision backend URL is not configured");
            return;
        }

        new Thread(() -> {
            try {
                callback.onResult(requestBackend(bitmap, backendUrl.trim()));
            } catch (Exception e) {
                callback.onError(e.getMessage() == null ? e.toString() : e.getMessage());
            }
        }, "smartchef-vision-request").start();
    }

    private static AIIngredientResult requestBackend(Bitmap source, String backendUrl) throws Exception {
        Bitmap image = scaleDown(source, 2048);
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        if (!image.compress(Bitmap.CompressFormat.JPEG, 88, stream)) {
            throw new IllegalStateException("Could not compress the image");
        }
        byte[] bytes = stream.toByteArray();
        if (bytes.length < 100) throw new IllegalStateException("Image data is empty");
        if (bytes.length > 8_500_000) throw new IllegalStateException("Image is too large after compression");

        String encodedImage = Base64.encodeToString(bytes, Base64.NO_WRAP);
        JSONObject body = new JSONObject();
        body.put("imageBase64", encodedImage);
        body.put("mimeType", "image/jpeg");

        HttpURLConnection connection = (HttpURLConnection) new URL(normalizeEndpoint(backendUrl)).openConnection();
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(25_000);
        connection.setReadTimeout(110_000);
        connection.setDoOutput(true);
        connection.setUseCaches(false);
        connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        connection.setRequestProperty("Accept", "application/json");
        connection.setRequestProperty("X-SmartChef-Client", "android-v21");

        try {
            try (OutputStream output = connection.getOutputStream()) {
                output.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }

            int status = connection.getResponseCode();
            String response = readStream(status >= 200 && status < 300
                    ? connection.getInputStream() : connection.getErrorStream());

            if (status < 200 || status >= 300) {
                throw new IllegalStateException("Vision backend returned HTTP " + status + ": " + extractServerError(response));
            }
            return parseBackendJson(response);
        } finally {
            connection.disconnect();
        }
    }

    private static String normalizeEndpoint(String url) {
        String trimmed = url.trim();
        while (trimmed.endsWith("/")) trimmed = trimmed.substring(0, trimmed.length() - 1);
        if (trimmed.endsWith("/api/v1/vision/analyze") || trimmed.endsWith("/analyze-ingredient")) return trimmed;
        return trimmed + "/api/v1/vision/analyze";
    }

    static AIIngredientResult parseBackendJson(String response) throws JSONException {
        JSONObject root = new JSONObject(response);
        if (!root.optBoolean("success", false)) {
            throw new JSONException(root.optString("error", "Vision analysis failed"));
        }

        JSONArray ranked = root.optJSONArray("candidates");
        if (ranked == null) throw new JSONException("Backend JSON did not contain candidates");

        List<AICandidate> output = new ArrayList<>();
        Set<String> used = new LinkedHashSet<>();
        for (int i = 0; i < ranked.length(); i++) {
            JSONObject item = ranked.optJSONObject(i);
            if (item == null) continue;
            String key = normalizeKey(item.optString("key", ""));
            String certainty = normalizeCertainty(item.optString("certainty", "low"));
            if (key.isEmpty() || "unknown".equals(key) || used.contains(key)) continue;
            used.add(key);
            output.add(createCandidate(key, certainty));
        }

        Collections.sort(output, new Comparator<AICandidate>() {
            @Override public int compare(AICandidate a, AICandidate b) {
                return Integer.compare(certaintyRank(b.certainty), certaintyRank(a.certainty));
            }
        });
        if (output.size() > 3) output = new ArrayList<>(output.subList(0, 3));

        String reason = root.optString("visual_reason", "");
        String quality = root.optString("image_quality", "");
        if (!quality.isEmpty()) reason = reason + (reason.isEmpty() ? "" : " | ") + "Image quality: " + quality;
        String method = root.optString("method", "OpenAI Vision via secure backend");
        boolean reliable = root.optBoolean("reliable", false);
        boolean needsReview = root.optBoolean("needs_review", true);
        return new AIIngredientResult(output, reliable, needsReview, method, reason);
    }

    private static Bitmap scaleDown(Bitmap bitmap, int maxSide) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int largest = Math.max(width, height);
        if (largest <= maxSide) return bitmap;
        float ratio = maxSide / (float) largest;
        return Bitmap.createScaledBitmap(bitmap,
                Math.max(1, Math.round(width * ratio)),
                Math.max(1, Math.round(height * ratio)), true);
    }

    private static String readStream(InputStream input) throws Exception {
        if (input == null) return "";
        StringBuilder builder = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) builder.append(line);
        }
        return builder.toString();
    }

    private static String extractServerError(String response) {
        try {
            JSONObject json = new JSONObject(response);
            String error = json.optString("error", "");
            String requestId = json.optString("requestId", "");
            if (!requestId.isEmpty()) error += " [" + requestId + "]";
            return shorten(error.isEmpty() ? response : error);
        } catch (Exception ignored) {
            return shorten(response);
        }
    }

    private static String normalizeCertainty(String value) {
        String v = value == null ? "low" : value.trim().toLowerCase();
        if ("high".equals(v) || "medium".equals(v) || "low".equals(v)) return v;
        return "low";
    }

    private static int certaintyRank(String value) {
        if ("high".equals(value)) return 3;
        if ("medium".equals(value)) return 2;
        return 1;
    }

    private static String normalizeKey(String input) {
        String key = input == null ? "" : input.trim().toLowerCase();
        key = key.replace('-', '_').replace(' ', '_');
        if (key.equals("basmati_rice")) return "rice";
        if (key.equals("eggs")) return "egg";
        if (key.equals("meat") || key.equals("lamb")) return "beef";
        if (key.equals("macaroni") || key.equals("spaghetti")) return "pasta";
        if (key.equals("red_lentil") || key.equals("lentils")) return "red_lentils";
        if (key.equals("bell_pepper") || key.equals("capsicum")) return "pepper";
        if (key.equals("none") || key.equals("unsupported")) return "unknown";
        return key;
    }

    private static AICandidate createCandidate(String key, String certainty) {
        switch (key) {
            case "rice": return new AICandidate(key, "Rice", "أرز", certainty);
            case "onion": return new AICandidate(key, "Onion", "بصل", certainty);
            case "potato": return new AICandidate(key, "Potato", "بطاطا", certainty);
            case "parsley": return new AICandidate(key, "Parsley", "بقدونس", certainty);
            case "egg": return new AICandidate(key, "Egg", "بيض", certainty);
            case "tuna": return new AICandidate(key, "Tuna", "تونة", certainty);
            case "garlic": return new AICandidate(key, "Garlic", "ثوم", certainty);
            case "cheese": return new AICandidate(key, "Cheese", "جبن", certainty);
            case "carrot": return new AICandidate(key, "Carrot", "جزر", certainty);
            case "cucumber": return new AICandidate(key, "Cucumber", "خيار", certainty);
            case "chicken": return new AICandidate(key, "Chicken", "دجاج", certainty);
            case "yogurt": return new AICandidate(key, "Yogurt", "لبن / زبادي", certainty);
            case "tomato": return new AICandidate(key, "Tomato", "طماطم", certainty);
            case "red_lentils": return new AICandidate(key, "Red Lentils", "عدس أحمر", certainty);
            case "beef": return new AICandidate(key, "Meat", "لحم", certainty);
            case "pasta": return new AICandidate(key, "Pasta / Macaroni", "معكرونة", certainty);
            case "spices": return new AICandidate(key, "Spices", "بهارات", certainty);
            case "milk": return new AICandidate(key, "Milk", "حليب", certainty);
            case "eggplant": return new AICandidate(key, "Eggplant", "باذنجان", certainty);
            case "bread": return new AICandidate(key, "Bread", "خبز", certainty);
            case "molokhia": return new AICandidate(key, "Molokhia", "ملوخية", certainty);
            case "sumac": return new AICandidate(key, "Sumac", "سماق", certainty);
            case "fish": return new AICandidate(key, "Fish", "سمك", certainty);
            case "chickpeas": return new AICandidate(key, "Chickpeas", "حمص", certainty);
            case "tahini": return new AICandidate(key, "Tahini", "طحينة", certainty);
            case "spinach": return new AICandidate(key, "Spinach", "سبانخ", certainty);
            case "zucchini": return new AICandidate(key, "Zucchini", "كوسا", certainty);
            case "peas": return new AICandidate(key, "Peas", "بازيلا", certainty);
            case "beans": return new AICandidate(key, "Beans", "فاصوليا", certainty);
            case "lemon": return new AICandidate(key, "Lemon", "ليمون", certainty);
            case "pepper": return new AICandidate(key, "Pepper", "فلفل", certainty);
            case "banana": return new AICandidate(key, "Banana", "موز", certainty);
            case "apple": return new AICandidate(key, "Apple", "تفاح", certainty);
            case "orange": return new AICandidate(key, "Orange", "برتقال", certainty);
            case "lettuce": return new AICandidate(key, "Lettuce", "خس", certainty);
            case "cabbage": return new AICandidate(key, "Cabbage", "ملفوف", certainty);
            case "corn": return new AICandidate(key, "Corn", "ذرة", certainty);
            case "mushroom": return new AICandidate(key, "Mushroom", "فطر", certainty);
            case "cauliflower": return new AICandidate(key, "Cauliflower", "قرنبيط", certainty);
            case "broccoli": return new AICandidate(key, "Broccoli", "بروكلي", certainty);
            case "avocado": return new AICandidate(key, "Avocado", "أفوكادو", certainty);
            default: return new AICandidate("unknown", "Unknown", "غير معروف", "low");
        }
    }

    private static String shorten(String text) {
        String value = text == null ? "" : text.trim();
        return value.length() > 260 ? value.substring(0, 260) : value;
    }
}
