package com.smartchef.app;

import android.graphics.Bitmap;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Sends a high-quality image to the secure SmartChef backend.
 * The API key is never stored in the Android application.
 */
public final class BackendVisionIngredientRecognizer {
    public interface Callback {
        void onResult(AIIngredientResult result);
        void onError(String message);
    }

    private BackendVisionIngredientRecognizer() { }

    public static void analyze(Bitmap bitmap, String backendUrl, Callback callback) {
        if (bitmap == null) {
            callback.onError("No image was provided");
            return;
        }
        if (backendUrl == null || backendUrl.trim().isEmpty()) {
            callback.onError("Vision backend URL is not configured");
            return;
        }

        new Thread(() -> {
            try {
                callback.onResult(requestBackend(bitmap, backendUrl.trim()));
            } catch (Exception e) {
                callback.onError(e.getMessage() == null ? e.toString() : e.getMessage());
            }
        }).start();
    }

    private static AIIngredientResult requestBackend(Bitmap source, String backendUrl) throws Exception {
        Bitmap image = scaleDown(source, 2048);
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        if (!image.compress(Bitmap.CompressFormat.JPEG, 90, stream)) {
            throw new IllegalStateException("Could not compress the image");
        }
        byte[] bytes = stream.toByteArray();
        if (bytes.length < 100) throw new IllegalStateException("Image data is empty");
        if (bytes.length > 9_000_000) throw new IllegalStateException("Image is too large after compression");

        String encodedImage = Base64.encodeToString(bytes, Base64.NO_WRAP);
        JSONObject body = new JSONObject();
        body.put("imageBase64", encodedImage);
        body.put("mimeType", "image/jpeg");

        HttpURLConnection connection = (HttpURLConnection) new URL(normalizeEndpoint(backendUrl)).openConnection();
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(25_000);
        connection.setReadTimeout(100_000);
        connection.setDoOutput(true);
        connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        connection.setRequestProperty("Accept", "application/json");

        try {
            try (OutputStream output = connection.getOutputStream()) {
                output.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }

            int status = connection.getResponseCode();
            String response = readStream(status >= 200 && status < 300
                    ? connection.getInputStream() : connection.getErrorStream());

            if (status < 200 || status >= 300) {
                throw new IllegalStateException("Vision backend returned HTTP " + status + ": " + extractServerError(response));
            }
            return parseBackendJson(response);
        } finally {
            connection.disconnect();
        }
    }

    private static String normalizeEndpoint(String url) {
        String trimmed = url.trim();
        while (trimmed.endsWith("/")) trimmed = trimmed.substring(0, trimmed.length() - 1);
        if (trimmed.endsWith("/api/v1/vision/analyze") || trimmed.endsWith("/analyze-ingredient")) return trimmed;
        return trimmed + "/api/v1/vision/analyze";
    }

    private static AIIngredientResult parseBackendJson(String response) throws JSONException {
        JSONObject root = new JSONObject(response);
        if (!root.optBoolean("success", true)) {
            throw new JSONException(root.optString("error", "Vision analysis failed"));
        }

        JSONArray ranked = root.optJSONArray("candidates");
        if (ranked == null) throw new JSONException("Backend JSON did not contain candidates");

        List<AICandidate> output = new ArrayList<>();
        Set<String> used = new LinkedHashSet<>();
        for (int i = 0; i < ranked.length(); i++) {
            JSONObject item = ranked.optJSONObject(i);
            if (item == null) continue;
            String key = normalizeKey(item.optString("key", ""));
            int confidence = normalizeConfidence(item.optDouble("confidence", 0));
            if (key.isEmpty() || used.contains(key)) continue;
            used.add(key);
            output.add(createCandidate(key, confidence));
        }

        Collections.sort(output, new Comparator<AICandidate>() {
            @Override public int compare(AICandidate a, AICandidate b) {
                return Integer.compare(b.confidence, a.confidence);
            }
        });
        if (output.size() > 3) output = new ArrayList<>(output.subList(0, 3));

        String reason = root.optString("visual_reason", "");
        String quality = root.optString("image_quality", "");
        if (!quality.isEmpty()) reason = reason + (reason.isEmpty() ? "" : " | ") + "Image quality: " + quality;
        String method = root.optString("method", "OpenAI Vision via secure backend");
        return new AIIngredientResult(output, method, reason);
    }

    private static Bitmap scaleDown(Bitmap bitmap, int maxSide) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int largest = Math.max(width, height);
        if (largest <= maxSide) return bitmap;
        float ratio = maxSide / (float) largest;
        return Bitmap.createScaledBitmap(bitmap,
                Math.max(1, Math.round(width * ratio)),
                Math.max(1, Math.round(height * ratio)), true);
    }

    private static String readStream(InputStream input) throws Exception {
        if (input == null) return "";
        StringBuilder builder = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) builder.append(line);
        }
        return builder.toString();
    }

    private static String extractServerError(String response) {
        try {
            JSONObject json = new JSONObject(response);
            String error = json.optString("error", "");
            String requestId = json.optString("requestId", "");
            if (!requestId.isEmpty()) error += " [" + requestId + "]";
            return shorten(error.isEmpty() ? response : error);
        } catch (Exception ignored) {
            return shorten(response);
        }
    }

    private static int normalizeConfidence(double value) {
        if (value >= 0 && value <= 1.0) value *= 100.0;
        return (int) Math.max(0, Math.min(100, Math.round(value)));
    }

    private static String normalizeKey(String input) {
        String key = input == null ? "" : input.trim().toLowerCase();
        key = key.replace('-', '_').replace(' ', '_');
        if (key.equals("basmati_rice")) return "rice";
        if (key.equals("eggs")) return "egg";
        if (key.equals("meat") || key.equals("lamb")) return "beef";
        if (key.equals("macaroni") || key.equals("spaghetti")) return "pasta";
        if (key.equals("red_lentil") || key.equals("lentils")) return "red_lentils";
        if (key.equals("bell_pepper") || key.equals("capsicum")) return "pepper";
        if (key.equals("none") || key.equals("unsupported")) return "unknown";
        return key;
    }

    private static AICandidate createCandidate(String key, int confidence) {
        switch (key) {
            case "rice": return new AICandidate(key, "Rice", "أرز", confidence);
            case "onion": return new AICandidate(key, "Onion", "بصل", confidence);
            case "potato": return new AICandidate(key, "Potato", "بطاطا", confidence);
            case "parsley": return new AICandidate(key, "Parsley", "بقدونس", confidence);
            case "egg": return new AICandidate(key, "Egg", "بيض", confidence);
            case "tuna": return new AICandidate(key, "Tuna", "تونة", confidence);
            case "garlic": return new AICandidate(key, "Garlic", "ثوم", confidence);
            case "cheese": return new AICandidate(key, "Cheese", "جبن", confidence);
            case "carrot": return new AICandidate(key, "Carrot", "جزر", confidence);
            case "cucumber": return new AICandidate(key, "Cucumber", "خيار", confidence);
            case "chicken": return new AICandidate(key, "Chicken", "دجاج", confidence);
            case "yogurt": return new AICandidate(key, "Yogurt", "لبن / زبادي", confidence);
            case "tomato": return new AICandidate(key, "Tomato", "طماطم", confidence);
            case "red_lentils": return new AICandidate(key, "Red Lentils", "عدس أحمر", confidence);
            case "beef": return new AICandidate(key, "Meat", "لحم", confidence);
            case "pasta": return new AICandidate(key, "Pasta / Macaroni", "معكرونة", confidence);
            case "spices": return new AICandidate(key, "Spices", "بهارات", confidence);
            case "milk": return new AICandidate(key, "Milk", "حليب", confidence);
            case "eggplant": return new AICandidate(key, "Eggplant", "باذنجان", confidence);
            case "bread": return new AICandidate(key, "Bread", "خبز", confidence);
            case "molokhia": return new AICandidate(key, "Molokhia", "ملوخية", confidence);
            case "sumac": return new AICandidate(key, "Sumac", "سماق", confidence);
            case "fish": return new AICandidate(key, "Fish", "سمك", confidence);
            case "chickpeas": return new AICandidate(key, "Chickpeas", "حمص", confidence);
            case "tahini": return new AICandidate(key, "Tahini", "طحينة", confidence);
            case "spinach": return new AICandidate(key, "Spinach", "سبانخ", confidence);
            case "zucchini": return new AICandidate(key, "Zucchini", "كوسا", confidence);
            case "peas": return new AICandidate(key, "Peas", "بازيلا", confidence);
            case "beans": return new AICandidate(key, "Beans", "فاصوليا", confidence);
            case "lemon": return new AICandidate(key, "Lemon", "ليمون", confidence);
            case "pepper": return new AICandidate(key, "Pepper", "فلفل", confidence);
            case "banana": return new AICandidate(key, "Banana", "موز", confidence);
            case "apple": return new AICandidate(key, "Apple", "تفاح", confidence);
            case "orange": return new AICandidate(key, "Orange", "برتقال", confidence);
            case "lettuce": return new AICandidate(key, "Lettuce", "خس", confidence);
            case "cabbage": return new AICandidate(key, "Cabbage", "ملفوف", confidence);
            case "corn": return new AICandidate(key, "Corn", "ذرة", confidence);
            case "mushroom": return new AICandidate(key, "Mushroom", "فطر", confidence);
            case "cauliflower": return new AICandidate(key, "Cauliflower", "قرنبيط", confidence);
            case "broccoli": return new AICandidate(key, "Broccoli", "بروكلي", confidence);
            case "avocado": return new AICandidate(key, "Avocado", "أفوكادو", confidence);
            default: return new AICandidate("unknown", "Unknown / Unsupported", "غير معروف / غير مدعوم", confidence);
        }
    }

    private static String shorten(String value) {
        if (value == null) return "";
        return value.length() <= 350 ? value : value.substring(0, 350) + "...";
    }
}
