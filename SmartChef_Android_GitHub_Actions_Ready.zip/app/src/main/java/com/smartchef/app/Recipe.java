package com.smartchef.app;

public class Recipe {
    public final String nameEn;
    public final String nameAr;
    public final String[] ingredients;
    public final String stepsEn;
    public final String stepsAr;
    public final String categoryEn;
    public final String categoryAr;
    public final String time;
    public final String difficultyEn;
    public final String difficultyAr;
    public final int imageResId;

    public Recipe(String nameEn, String nameAr, String[] ingredients, String stepsEn, String stepsAr,
                  String categoryEn, String categoryAr, String time, String difficultyEn, String difficultyAr, int imageResId) {
        this.nameEn = nameEn;
        this.nameAr = nameAr;
        this.ingredients = ingredients;
        this.stepsEn = stepsEn;
        this.stepsAr = stepsAr;
        this.categoryEn = categoryEn;
        this.categoryAr = categoryAr;
        this.time = time;
        this.difficultyEn = difficultyEn;
        this.difficultyAr = difficultyAr;
        this.imageResId = imageResId;
    }
}
