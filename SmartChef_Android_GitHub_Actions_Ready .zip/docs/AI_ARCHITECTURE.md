# AI Architecture

Android App -> Secure Backend -> OpenAI Vision -> Structured JSON -> User Confirmation -> Recommendation Engine

The API key remains on the server. The mobile app receives ranked candidates and never accepts an uncertain prediction automatically.
