# دليل نشر Smart Chef V21

## 1. نشر Backend
- ارفع مجلد `backend` إلى Render أو Railway.
- Build Command: `npm install`
- Start Command: `npm start`
- أضف Environment Variable: `OPENAI_API_KEY`
- اختبر `/health` وتأكد أن `aiConfigured` تساوي `true`.

## 2. ربط التطبيق
- في GitHub افتح Settings > Secrets and variables > Actions.
- أضف Secret باسم `VISION_BACKEND_URL` وقيمته رابط الخادم بدون شرطة مائلة أخيرة.
- شغّل Workflow: Build Smart Chef Android APK.

## 3. التنزيل
- بعد ظهور العلامة الخضراء، افتح Artifacts.
- حمّل `SmartChef-V21-professional-apk`.
- فك الضغط وثبّت `app-debug.apk`.
