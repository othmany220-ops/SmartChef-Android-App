(() => {
  'use strict';

  const data = window.SMART_CHEF_DATA;
  if (!data) {
    document.body.innerHTML = '<p style="padding:2rem">تعذر تحميل بيانات Smart Chef.</p>';
    return;
  }

  const state = {
    view: 'home',
    selectedIngredients: new Set(),
    favorites: new Set(readLocalArray('smartChefFavorites')),
    recommendationResults: [],
    modalRecipeId: null,
    lastFocused: null
  };

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

  const els = {
    header: $('#siteHeader'),
    menuButton: $('#menuButton'),
    mobileNav: $('#mobileNav'),
    themeToggle: $('#themeToggle'),
    homeIngredientShowcase: $('#homeIngredientShowcase'),
    featuredRecipes: $('#featuredRecipes'),
    ingredientSearch: $('#ingredientSearch'),
    clearIngredientSearch: $('#clearIngredientSearch'),
    ingredientSuggestions: $('#ingredientSuggestions'),
    selectedIngredients: $('#selectedIngredients'),
    selectedCount: $('#selectedCount'),
    quickIngredientButtons: $('#quickIngredientButtons'),
    clearSelection: $('#clearSelection'),
    findRecipes: $('#findRecipes'),
    recommendCategory: $('#recommendCategory'),
    recommendDifficulty: $('#recommendDifficulty'),
    recommendTime: $('#recommendTime'),
    recommendationGrid: $('#recommendationGrid'),
    recommendationEmpty: $('#recommendationEmpty'),
    recommendationSummary: $('#recommendationSummary'),
    recipeSearch: $('#recipeSearch'),
    recipeCategory: $('#recipeCategory'),
    recipeDifficulty: $('#recipeDifficulty'),
    recipeSort: $('#recipeSort'),
    allRecipesGrid: $('#allRecipesGrid'),
    catalogCount: $('#catalogCount'),
    catalogEmpty: $('#catalogEmpty'),
    visionGrid: $('#visionGrid'),
    chooseImage: $('#chooseImage'),
    imageUpload: $('#imageUpload'),
    uploadCard: $('#uploadCard'),
    uploadPlaceholder: $('#uploadPlaceholder'),
    uploadPreview: $('#uploadPreview'),
    previewImage: $('#previewImage'),
    removeImage: $('#removeImage'),
    favoritesGrid: $('#favoritesGrid'),
    favoritesEmpty: $('#favoritesEmpty'),
    modal: $('#recipeModal'),
    modalContent: $('#modalContent'),
    modalClose: $('#modalClose'),
    toast: $('#toast'),
    backToTop: $('#backToTop')
  };

  function safeStorageGet(key) {
    try { return localStorage.getItem(key); } catch { return null; }
  }

  function safeStorageSet(key, value) {
    try { localStorage.setItem(key, value); } catch { /* Storage can be unavailable in restricted previews. */ }
  }

  function readLocalArray(key) {
    try {
      const value = JSON.parse(safeStorageGet(key) || '[]');
      return Array.isArray(value) ? value.map(Number).filter(Number.isFinite) : [];
    } catch {
      return [];
    }
  }

  function saveFavorites() {
    safeStorageSet('smartChefFavorites', JSON.stringify([...state.favorites]));
  }

  function normalizeArabic(value = '') {
    return String(value)
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u064B-\u065F\u0670]/g, '')
      .replace(/[إأآٱ]/g, 'ا')
      .replace(/ى/g, 'ي')
      .replace(/ؤ/g, 'و')
      .replace(/ئ/g, 'ي')
      .replace(/ة/g, 'ه')
      .replace(/ـ/g, '')
      .replace(/[^\u0600-\u06FFa-z0-9\s]/gi, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function escapeHtml(value = '') {
    return String(value).replace(/[&<>'"]/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[char]));
  }

  function placeholderDataUri(label = 'Smart Chef') {
    const safe = escapeHtml(label).slice(0, 22);
    return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 420"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#d9eee5"/><stop offset="1" stop-color="#f7e4c4"/></linearGradient></defs><rect width="600" height="420" fill="url(#g)"/><circle cx="300" cy="180" r="75" fill="#126b4b" opacity=".15"/><text x="300" y="310" text-anchor="middle" font-family="Arial" font-size="28" fill="#126b4b">${safe}</text></svg>`)}`;
  }

  function imageForRecipe(recipe) {
    return recipe.image || placeholderDataUri(recipe.nameAr);
  }

  function populateStats() {
    const map = {
      heroRecipesCount: data.meta.recipesCount,
      heroIngredientsCount: data.meta.ingredientsCount,
      heroVisualCount: data.meta.visualClassesCount,
      visionClassesCount: data.meta.visualClassesCount,
      aboutRecipesCount: data.meta.recipesCount,
      aboutIngredientsCount: data.meta.ingredientsCount,
      aboutVisualCount: data.meta.visualClassesCount
    };
    Object.entries(map).forEach(([id, value]) => { const el = document.getElementById(id); if (el) el.textContent = value; });
    const relationCount = data.recipes.reduce((sum, recipe) => sum + recipe.ingredients.length, 0);
    const relationEl = $('#aboutRelationsCount');
    if (relationEl) relationEl.textContent = relationCount;
    $('#currentYear').textContent = new Date().getFullYear();
  }

  function fillSelect(select, values, labelPrefix = '') {
    values.forEach(value => {
      const option = document.createElement('option');
      option.value = value;
      option.textContent = labelPrefix ? `${labelPrefix}: ${value}` : value;
      select.appendChild(option);
    });
  }

  function initializeSelects() {
    [els.recommendCategory, els.recipeCategory].forEach(select => fillSelect(select, data.categories));
    [els.recommendDifficulty, els.recipeDifficulty].forEach(select => fillSelect(select, data.difficulties));
  }

  function showView(viewName, pushHash = true) {
    const allowed = ['home','recommend','recipes','vision','favorites','about'];
    const target = allowed.includes(viewName) ? viewName : 'home';
    state.view = target;
    $$('.app-view').forEach(view => view.classList.toggle('active', view.dataset.viewName === target));
    $$('.nav-link[data-view]').forEach(link => link.classList.toggle('active', link.dataset.view === target));
    els.mobileNav.classList.remove('open');
    els.menuButton.setAttribute('aria-expanded','false');
    window.scrollTo({top: 0, behavior: 'smooth'});
    if (pushHash && location.hash !== `#${target}`) history.pushState(null, '', `#${target}`);
    if (target === 'favorites') renderFavorites();
    if (target === 'recipes') renderCatalog();
    requestAnimationFrame(observeReveals);
  }

  function ingredientImageHtml(ingredient, className = '') {
    return ingredient.image
      ? `<img class="${className}" src="${ingredient.image}" alt="${escapeHtml(ingredient.nameAr)}" loading="lazy">`
      : `<span class="${className || 'ingredient-dot'}" aria-hidden="true">•</span>`;
  }

  function recipeCard(recipe, match = null) {
    const favorite = state.favorites.has(recipe.id);
    const ingredientImages = recipe.ingredients.filter(i => i.image).slice(0, 3);
    const remaining = Math.max(0, recipe.ingredients.length - ingredientImages.length);
    const matchBlock = match ? `
      <div class="match-details">
        <div class="match-bar"><span style="width:${match.score}%"></span></div>
        <div class="match-labels"><span>${match.matchedCount} من ${recipe.ingredients.length} مكوّنات الوصفة متوفرة</span><b>${match.score}%</b></div>
      </div>
      <p class="missing-note">${match.missing.length ? `ينقصك: ${match.missing.slice(0,3).map(i => escapeHtml(i.nameAr)).join('، ')}${match.missing.length > 3 ? '…' : ''}` : 'جميع مكوّنات الوصفة المختارة متوفرة لديك.'}</p>` : '';
    return `
      <article class="recipe-card" data-recipe-id="${recipe.id}">
        <div class="recipe-card-image">
          <img src="${imageForRecipe(recipe)}" alt="${escapeHtml(recipe.nameAr)}" loading="lazy">
          <span class="category-badge">${escapeHtml(recipe.categoryAr)}</span>
          ${match ? `<span class="match-score">${match.score}% تطابق</span>` : ''}
          <button class="favorite-button ${favorite ? 'active' : ''}" type="button" data-action="favorite" data-id="${recipe.id}" aria-label="${favorite ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة'}">${favorite ? '♥' : '♡'}</button>
        </div>
        <div class="recipe-card-body">
          <div class="recipe-title-row"><div><h3>${escapeHtml(recipe.nameAr)}</h3><small>${escapeHtml(recipe.nameEn)}</small></div></div>
          <div class="recipe-meta"><span>⏱ ${recipe.totalMinutes} دقيقة</span><span>◉ ${escapeHtml(recipe.difficultyAr)}</span><span>♨ ${recipe.servings} حصص</span></div>
          ${matchBlock}
          <div class="recipe-card-footer">
            <div class="ingredient-preview">${ingredientImages.map(i => ingredientImageHtml(i)).join('')}${remaining ? `<span class="more-ingredients">+${remaining}</span>` : ''}</div>
            <button class="view-recipe" type="button" data-action="details" data-id="${recipe.id}">عرض الوصفة</button>
          </div>
        </div>
      </article>`;
  }

  function attachRecipeGridEvents(container) {
    container.onclick = event => {
      const actionButton = event.target.closest('[data-action]');
      if (!actionButton) return;
      const id = Number(actionButton.dataset.id);
      if (actionButton.dataset.action === 'favorite') toggleFavorite(id);
      if (actionButton.dataset.action === 'details') openRecipe(id, actionButton);
    };
  }

  function renderHome() {
    const quickIds = [22,33,7,12,56,35,21,48];
    const quick = quickIds.map(id => data.ingredients.find(i => i.id === id)).filter(Boolean);
    els.homeIngredientShowcase.innerHTML = quick.map(ingredient => `
      <button class="ingredient-tile ${state.selectedIngredients.has(ingredient.id) ? 'selected' : ''}" type="button" data-id="${ingredient.id}">
        ${ingredientImageHtml(ingredient)}<span>${escapeHtml(ingredient.nameAr)}</span>
      </button>`).join('');
    els.homeIngredientShowcase.onclick = event => {
      const tile = event.target.closest('.ingredient-tile');
      if (!tile) return;
      addIngredient(Number(tile.dataset.id));
      showView('recommend');
      setTimeout(() => els.ingredientSearch.focus(), 350);
    };

    const featuredIds = [1,3,6,12,13,20];
    els.featuredRecipes.innerHTML = featuredIds.map(id => recipeCard(data.recipes.find(r => r.id === id))).join('');
    attachRecipeGridEvents(els.featuredRecipes);
  }

  function renderQuickIngredients() {
    const ids = [22,33,7,12,56,35,21,6,14,2];
    const list = ids.map(id => data.ingredients.find(i => i.id === id)).filter(Boolean);
    els.quickIngredientButtons.innerHTML = list.map(i => `<button class="quick-select-button ${state.selectedIngredients.has(i.id) ? 'selected' : ''}" type="button" data-id="${i.id}">${escapeHtml(i.nameAr)}</button>`).join('');
    els.quickIngredientButtons.onclick = event => {
      const button = event.target.closest('[data-id]');
      if (!button) return;
      const id = Number(button.dataset.id);
      state.selectedIngredients.has(id) ? removeIngredient(id) : addIngredient(id);
    };
  }

  function renderSelectedIngredients() {
    const selected = data.ingredients.filter(i => state.selectedIngredients.has(i.id));
    els.selectedCount.textContent = selected.length;
    els.selectedIngredients.classList.toggle('empty', selected.length === 0);
    els.selectedIngredients.innerHTML = selected.length ? selected.map(i => `
      <span class="selected-chip">${i.image ? `<img src="${i.image}" alt="">` : ''}<span>${escapeHtml(i.nameAr)}</span><button type="button" data-id="${i.id}" aria-label="إزالة ${escapeHtml(i.nameAr)}">×</button></span>`).join('') : '<p>لم يتم اختيار مكوّنات بعد.</p>';
    els.selectedIngredients.onclick = event => {
      const button = event.target.closest('button[data-id]');
      if (button) removeIngredient(Number(button.dataset.id));
    };
    renderQuickIngredients();
    renderHome();
  }

  function addIngredient(id) {
    if (!data.ingredients.some(i => i.id === id)) return;
    state.selectedIngredients.add(id);
    els.ingredientSearch.value = '';
    closeSuggestions();
    renderSelectedIngredients();
  }

  function removeIngredient(id) {
    state.selectedIngredients.delete(id);
    renderSelectedIngredients();
    if (state.recommendationResults.length) calculateRecommendations();
  }

  function renderSuggestions(query = '') {
    const normalized = normalizeArabic(query);
    let matches = data.ingredients.filter(i => !state.selectedIngredients.has(i.id));
    if (normalized) {
      matches = matches.filter(i => [i.nameAr,i.normalizedAr,i.nameEn].some(v => normalizeArabic(v).includes(normalized)));
    } else {
      matches = matches.filter(i => i.visual);
    }
    matches = matches.slice(0, 10);
    if (!matches.length) {
      els.ingredientSuggestions.innerHTML = '<div class="suggestion-item"><div><strong>لا توجد نتائج</strong><small>جرّب كلمة أخرى</small></div></div>';
    } else {
      els.ingredientSuggestions.innerHTML = matches.map(i => `
        <button class="suggestion-item" type="button" role="option" data-id="${i.id}">
          ${i.image ? `<img src="${i.image}" alt="">` : '<span class="suggestion-placeholder">•</span>'}
          <div><strong>${escapeHtml(i.nameAr)}</strong><small>${escapeHtml(i.nameEn)} · ${escapeHtml(i.groupAr)}</small></div>
        </button>`).join('');
    }
    els.ingredientSuggestions.classList.add('open');
  }

  function closeSuggestions() {
    els.ingredientSuggestions.classList.remove('open');
  }

  function calculateRecommendations() {
    const selectedIds = [...state.selectedIngredients];
    if (!selectedIds.length) {
      state.recommendationResults = [];
      renderRecommendations();
      showToast('اختر مكوّنًا واحدًا على الأقل.');
      return;
    }
    state.recommendationResults = data.recipes.map(recipe => {
      const recipeIds = recipe.ingredients.map(i => i.id);
      const matchedIds = selectedIds.filter(id => recipeIds.includes(id));
      const matchedCount = matchedIds.length;
      const selectedCoverage = matchedCount / selectedIds.length;
      const recipeCoverage = matchedCount / recipeIds.length;
      const score = Math.round((selectedCoverage * .72 + recipeCoverage * .28) * 100);
      const missing = recipe.ingredients.filter(i => !selectedIds.includes(i.id));
      return { recipe, score, matchedCount, selectedCoverage, recipeCoverage, missing };
    }).filter(item => item.matchedCount > 0).sort((a,b) => b.score - a.score || b.matchedCount - a.matchedCount || a.recipe.totalMinutes - b.recipe.totalMinutes);
    renderRecommendations();
    els.recommendationGrid.scrollIntoView({behavior:'smooth',block:'start'});
  }

  function renderRecommendations() {
    const category = els.recommendCategory.value;
    const difficulty = els.recommendDifficulty.value;
    const maxTime = els.recommendTime.value === 'all' ? Infinity : Number(els.recommendTime.value);
    const filtered = state.recommendationResults.filter(item =>
      (category === 'all' || item.recipe.categoryAr === category) &&
      (difficulty === 'all' || item.recipe.difficultyAr === difficulty) &&
      item.recipe.totalMinutes <= maxTime
    );
    els.recommendationEmpty.classList.toggle('hidden', filtered.length > 0);
    els.recommendationGrid.classList.toggle('hidden', filtered.length === 0);
    els.recommendationGrid.innerHTML = filtered.map(item => recipeCard(item.recipe,item)).join('');
    attachRecipeGridEvents(els.recommendationGrid);
    if (state.selectedIngredients.size && state.recommendationResults.length) {
      els.recommendationSummary.textContent = `وجدنا ${filtered.length} وصفة بعد التصفية من أصل ${state.recommendationResults.length} وصفة مطابقة.`;
      if (!filtered.length) {
        els.recommendationEmpty.innerHTML = '<div class="empty-illustration">🧩</div><h3>لا توجد وصفات ضمن عوامل التصفية</h3><p>وسّع الوقت أو اختر تصنيفًا مختلفًا.</p>';
      }
    } else {
      els.recommendationSummary.textContent = 'اختر المكوّنات ليبدأ حساب التطابق.';
      els.recommendationEmpty.innerHTML = '<div class="empty-illustration">🥣</div><h3>بانتظار مكوّناتك</h3><p>اختر بعض المكوّنات من الأعلى، وسنعرض الوصفات الأقرب لما يتوفر لديك.</p>';
    }
  }

  function renderCatalog() {
    const query = normalizeArabic(els.recipeSearch.value);
    const category = els.recipeCategory.value;
    const difficulty = els.recipeDifficulty.value;
    let list = data.recipes.filter(recipe => {
      const haystack = normalizeArabic([recipe.nameAr,recipe.nameEn,recipe.cuisineAr,recipe.categoryAr,...recipe.ingredients.map(i => i.nameAr),...recipe.ingredients.map(i => i.nameEn)].join(' '));
      return (!query || haystack.includes(query)) &&
        (category === 'all' || recipe.categoryAr === category) &&
        (difficulty === 'all' || recipe.difficultyAr === difficulty);
    });
    if (els.recipeSort.value === 'time-asc') list.sort((a,b) => a.totalMinutes - b.totalMinutes);
    if (els.recipeSort.value === 'name') list.sort((a,b) => a.nameAr.localeCompare(b.nameAr,'ar'));
    els.catalogCount.textContent = list.length;
    els.allRecipesGrid.innerHTML = list.map(recipe => recipeCard(recipe)).join('');
    els.catalogEmpty.classList.toggle('hidden', list.length > 0);
    els.allRecipesGrid.classList.toggle('hidden', list.length === 0);
    attachRecipeGridEvents(els.allRecipesGrid);
  }

  function renderVision() {
    els.visionGrid.innerHTML = data.visualClasses.map(item => `
      <article class="vision-card">
        <img src="${item.image}" alt="${escapeHtml(item.nameAr)}" loading="lazy">
        <div class="vision-card-body"><h3>${escapeHtml(item.nameAr)}</h3><small>${escapeHtml(item.nameEn)}</small><span>${escapeHtml(item.groupAr)}</span></div>
      </article>`).join('');
  }

  function renderFavorites() {
    const recipes = data.recipes.filter(recipe => state.favorites.has(recipe.id));
    els.favoritesGrid.innerHTML = recipes.map(recipe => recipeCard(recipe)).join('');
    els.favoritesGrid.classList.toggle('hidden', recipes.length === 0);
    els.favoritesEmpty.classList.toggle('hidden', recipes.length > 0);
    attachRecipeGridEvents(els.favoritesGrid);
  }

  function toggleFavorite(id) {
    if (state.favorites.has(id)) {
      state.favorites.delete(id);
      showToast('تمت إزالة الوصفة من المفضلة.');
    } else {
      state.favorites.add(id);
      showToast('تمت إضافة الوصفة إلى المفضلة.');
    }
    saveFavorites();
    renderHome();
    renderCatalog();
    renderRecommendations();
    renderFavorites();
    if (state.modalRecipeId === id) renderModalContent(data.recipes.find(r => r.id === id));
  }

  function renderModalContent(recipe) {
    if (!recipe) return;
    const favorite = state.favorites.has(recipe.id);
    els.modalContent.innerHTML = `
      <div class="modal-hero"><img src="${imageForRecipe(recipe)}" alt="${escapeHtml(recipe.nameAr)}"><div class="modal-heading"><span>${escapeHtml(recipe.categoryAr)} · ${escapeHtml(recipe.cuisineAr)}</span><h2 id="modalRecipeTitle">${escapeHtml(recipe.nameAr)}</h2><small>${escapeHtml(recipe.nameEn)}</small></div></div>
      <div class="modal-body">
        <div class="modal-stats"><div><strong>${recipe.prepMinutes}</strong><span>دقيقة تحضير</span></div><div><strong>${recipe.cookMinutes}</strong><span>دقيقة طهي</span></div><div><strong>${recipe.servings}</strong><span>حصص</span></div><div><strong>${escapeHtml(recipe.difficultyAr)}</strong><span>الصعوبة</span></div></div>
        <p>${escapeHtml(recipe.descriptionAr)}</p>
        <section class="modal-section"><h3>المكوّنات</h3><div class="ingredients-list">${recipe.ingredients.map(i => `<div class="ingredient-list-item">${i.image ? `<img src="${i.image}" alt="">` : '<span class="ingredient-list-placeholder">•</span>'}<div><strong>${escapeHtml(i.nameAr)}</strong><small>${escapeHtml(i.quantityAr)} · ${escapeHtml(i.groupAr)}</small></div></div>`).join('')}</div></section>
        <section class="modal-section"><h3>خطوات التحضير</h3><div class="steps-list">${recipe.steps.map(step => `<div class="step-item"><b>${step.number}</b><p>${escapeHtml(step.instructionAr)}</p></div>`).join('')}</div></section>
        <div class="modal-actions"><button class="button ${favorite ? 'button-secondary' : 'button-primary'}" type="button" id="modalFavorite" data-id="${recipe.id}">${favorite ? '♥ إزالة من المفضلة' : '♡ إضافة إلى المفضلة'}</button></div>
      </div>`;
    $('#modalFavorite').onclick = () => toggleFavorite(recipe.id);
  }

  function openRecipe(id, trigger) {
    const recipe = data.recipes.find(r => r.id === id);
    if (!recipe) return;
    state.modalRecipeId = id;
    state.lastFocused = trigger || document.activeElement;
    renderModalContent(recipe);
    els.modal.classList.add('open');
    els.modal.setAttribute('aria-hidden','false');
    document.body.style.overflow = 'hidden';
    setTimeout(() => els.modalClose.focus(), 20);
  }

  function closeModal() {
    els.modal.classList.remove('open');
    els.modal.setAttribute('aria-hidden','true');
    document.body.style.overflow = '';
    state.modalRecipeId = null;
    state.lastFocused?.focus?.();
  }

  let toastTimer;
  function showToast(message) {
    clearTimeout(toastTimer);
    els.toast.textContent = message;
    els.toast.classList.add('show');
    toastTimer = setTimeout(() => els.toast.classList.remove('show'), 2600);
  }

  function setTheme(theme) {
    document.documentElement.dataset.theme = theme;
    safeStorageSet('smartChefTheme',theme);
    els.themeToggle.setAttribute('aria-label', theme === 'dark' ? 'تفعيل المظهر الفاتح' : 'تفعيل المظهر الداكن');
  }

  function initializeTheme() {
    const saved = safeStorageGet('smartChefTheme');
    const preferredDark = window.matchMedia?.('(prefers-color-scheme: dark)').matches;
    setTheme(saved || (preferredDark ? 'dark' : 'light'));
  }

  function showImage(file) {
    if (!file || !file.type.startsWith('image/')) {
      showToast('يرجى اختيار ملف صورة صالح.');
      return;
    }
    const reader = new FileReader();
    reader.onload = event => {
      els.previewImage.src = event.target.result;
      els.uploadPlaceholder.classList.add('hidden');
      els.uploadPreview.classList.remove('hidden');
    };
    reader.readAsDataURL(file);
  }

  function clearUploadedImage() {
    els.imageUpload.value = '';
    els.previewImage.removeAttribute('src');
    els.uploadPreview.classList.add('hidden');
    els.uploadPlaceholder.classList.remove('hidden');
  }

  function observeReveals() {
    const activeView = $('.app-view.active');
    if (!activeView) return;
    const items = $$('.reveal:not(.visible)',activeView);
    if (!('IntersectionObserver' in window)) { items.forEach(item => item.classList.add('visible')); return; }
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) { entry.target.classList.add('visible'); observer.unobserve(entry.target); }
      });
    },{threshold:.09});
    items.forEach(item => observer.observe(item));
  }

  function bindEvents() {
    document.addEventListener('click', event => {
      const nav = event.target.closest('.nav-link[data-view]');
      if (nav) showView(nav.dataset.view);
      if (!event.target.closest('.ingredient-search-wrap')) closeSuggestions();
    });
    els.menuButton.addEventListener('click', () => {
      const open = els.mobileNav.classList.toggle('open');
      els.menuButton.setAttribute('aria-expanded',String(open));
    });
    els.themeToggle.addEventListener('click', () => setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'));
    els.ingredientSearch.addEventListener('focus', () => renderSuggestions(els.ingredientSearch.value));
    els.ingredientSearch.addEventListener('input', () => renderSuggestions(els.ingredientSearch.value));
    els.ingredientSuggestions.addEventListener('click', event => {
      const item = event.target.closest('[data-id]');
      if (item) addIngredient(Number(item.dataset.id));
    });
    els.ingredientSearch.addEventListener('keydown', event => {
      if (event.key === 'Enter') {
        const first = $('.suggestion-item[data-id]',els.ingredientSuggestions);
        if (first) { event.preventDefault(); addIngredient(Number(first.dataset.id)); }
      }
      if (event.key === 'Escape') closeSuggestions();
    });
    els.clearIngredientSearch.addEventListener('click', () => { els.ingredientSearch.value=''; renderSuggestions(''); els.ingredientSearch.focus(); });
    els.clearSelection.addEventListener('click', () => { state.selectedIngredients.clear(); state.recommendationResults=[]; renderSelectedIngredients(); renderRecommendations(); });
    els.findRecipes.addEventListener('click', calculateRecommendations);
    [els.recommendCategory,els.recommendDifficulty,els.recommendTime].forEach(el => el.addEventListener('change',renderRecommendations));
    [els.recipeSearch,els.recipeCategory,els.recipeDifficulty,els.recipeSort].forEach(el => el.addEventListener(el.tagName === 'INPUT' ? 'input' : 'change',renderCatalog));
    els.modalClose.addEventListener('click',closeModal);
    els.modal.addEventListener('click',event => { if (event.target === els.modal) closeModal(); });
    document.addEventListener('keydown',event => { if (event.key === 'Escape' && els.modal.classList.contains('open')) closeModal(); });
    els.chooseImage.addEventListener('click',() => els.imageUpload.click());
    els.imageUpload.addEventListener('change',() => showImage(els.imageUpload.files[0]));
    els.removeImage.addEventListener('click',clearUploadedImage);
    ['dragenter','dragover'].forEach(name => els.uploadCard.addEventListener(name,event => { event.preventDefault(); els.uploadCard.classList.add('dragover'); }));
    ['dragleave','drop'].forEach(name => els.uploadCard.addEventListener(name,event => { event.preventDefault(); els.uploadCard.classList.remove('dragover'); }));
    els.uploadCard.addEventListener('drop',event => showImage(event.dataTransfer.files[0]));
    window.addEventListener('scroll',() => {
      els.header.classList.toggle('scrolled',window.scrollY > 8);
      els.backToTop.classList.toggle('show',window.scrollY > 500);
    },{passive:true});
    els.backToTop.addEventListener('click',() => window.scrollTo({top:0,behavior:'smooth'}));
    window.addEventListener('popstate',() => showView(location.hash.slice(1) || 'home',false));
  }

  function registerServiceWorker() {
    if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
      window.addEventListener('load',() => navigator.serviceWorker.register('./service-worker.js').catch(() => {}));
    }
  }

  function init() {
    initializeTheme();
    populateStats();
    initializeSelects();
    renderHome();
    renderQuickIngredients();
    renderSelectedIngredients();
    renderCatalog();
    renderVision();
    renderFavorites();
    renderRecommendations();
    attachRecipeGridEvents(els.allRecipesGrid);
    bindEvents();
    showView(location.hash.slice(1) || 'home',false);
    observeReveals();
    registerServiceWorker();
  }

  init();
})();
