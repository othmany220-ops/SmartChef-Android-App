#!/usr/bin/env sh
cd "$(dirname "$0")" || exit 1
echo "Smart Chef is running at http://localhost:8000"
echo "Press Ctrl+C to stop the server."
python3 -m http.server 8000
