@echo off
cd /d "%~dp0"
echo Smart Chef is running at http://localhost:8000
echo Press Ctrl+C to stop the server.
python -m http.server 8000
pause
